# 来源、依赖与版权注意

## 本包许可

- 本发布包的代码、文档和自造示例采用 **MIT License**。
- 版权：**Copyright (c) 2026 GAOLI1208**。
- 完整许可文本见根目录 `LICENSE`。

MIT 许可仅适用于本发布包中由版权持有人有权许可的文件；不改变第三方依赖、字体、图片来源、上游材料或真实试卷各自的权利与许可。分发时请保留 `LICENSE` 和本 NOTICE。

## 本包来源

本发布包整理自 DSH 项目内的 `xuean-gaoli` 实验候选技能及其 Python/Typst 代码。原始项目中的历史材料、真实试卷、题库页面和第三方内容不随本包分发；本包只带手写自造示例。

## 第三方依赖

`requirements.lock.txt` 锁定的 Python 包各自遵循上游许可证，包括但不限于 BeautifulSoup、pdfplumber/pdfminer.six、pypdf、pypdfium2、Pillow、Typst Python 包、SymPy 及其传递依赖。安装/分发时应保留各包自带的许可证与元数据；不要用本包 MIT 许可或 NOTICE 替代上游许可证。

## 字体与 OCR

- 不随包分发中文字体；macOS 验证使用系统 `Songti SC`。字体版权和使用范围由使用者/系统提供方决定，不适用本包 MIT 许可。
- OCR 通过 macOS Vision 调用，源文件 `scripts/vision_ocr.swift` 随包；不随包分发 Swift/Xcode 工具链。其它平台未验证。

## 真实材料

本包不包含真实试卷、题库页面、学生/教师个人信息、账号配置、Cookie、`runs/` 或缓存。示例 `examples/minimal/` 为手写自造，明确标注非真实试题。

使用真实材料时，请自行确认来源网站的条款、版权、引用范围和答案使用权限；不要用本包绕过登录、付费或访问控制。
