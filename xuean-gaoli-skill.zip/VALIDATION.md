# 验证记录

日期：2026-11-02（Asia/Shanghai）  
环境：macOS 27.0.1 arm64；系统 `/usr/bin/python3` 为 3.9.6（低于要求，未用于运行）。  
原则：不修改原项目、旧仓库或冻结；不安装用户级；不执行 Git 上传。

## 1. 安装（隔离临时项目）

实际命令（临时路径已用 `<TMP>` 表示）：

```sh
PYTHON=<签名的测试 CPython 3.12.14> ./install.sh <TMP>/project
```

结果：`exit 0`。安装到：

```text
<TMP>/project/.dsh/skills/xuean-gaoli/
```

- 复制了技能源码、模板、schema、references、自造示例、安装/卸载脚本；
- 创建隔离 `.venv`；
- 从 `requirements.lock.txt` 安装 15 个锁定包：beautifulsoup4、soupsieve、cffi、charset-normalizer、cryptography、mpmath、pdfminer.six、pdfplumber、pillow、pycparser、pypdf、pypdfium2、sympy、typst、typing_extensions；
- 没有使用原工程的 `.venv`、`rt/python` 或模板。

发现并修正：示例最初缺 `problem.figure_expected`，`validate` 报 `KeyError`；补为 `false` 后继续。该字段是当前 schema/校验实际需要的字段，示例已修正。

## 2. 发现路径与 frontmatter

检查：

```text
<TMP>/project/.dsh/skills/xuean-gaoli/SKILL.md  存在
frontmatter name: xuean-gaoli
```

结论：项目范围安装路径正确；未启动新的 DSH 会话，**新会话实际扫描未验证**。README/SKILL 已说明从工作区根、新会话检查。

## 3. help / doctor

```sh
<TMP>/project/.dsh/skills/xuean-gaoli/bin/xuean --help
<TMP>/project/.dsh/skills/xuean-gaoli/bin/xuean doctor
```

- `--help`：`exit 0`，列出 `doctor/extract/crop/ocr/fetch/validate/preview/build/audit/record-review/visual/deliver/import/report/task/promote`。
- `doctor`：`exit 0`，`环境可用`；Typst 样页 `ok`；字体 `Songti SC` 存在；`typst/pypdf/pypdfium2/pdfplumber/PIL/sympy` 全部 OK；`Songti` 字体嵌入。
- `doctor` 显示 DSH 应用 `unknown`、host/node 未配置，这是独立运行预期；不影响 CLI/PDF。

### 平台签名问题（实际遇到）

第一次用 DSH 自带的 hardened Python 3.12 创建 venv 时，`doctor` 失败：

```text
typst/pypdfium2/pdfplumber FAIL
dlopen(.../_typst.abi3.so): code signature ... different Team IDs
```

这不是包代码问题，而是该测试解释器的 hardened runtime 与 PyPI arm64 扩展 Team ID 不一致。发布包按用户澄清**不打包解释器/二进制**；第二次用测试专用的已签名 CPython 3.12.14 复制件（仅测试，**不在发布包**）安装，`doctor` 通过 `exit 0`。安装器的版本门槛是 Python >= 3.10, < 3.14，但当前只实际验证 3.12；其他版本未逐版验证。若遇到同类签名错误，换官方 Python 或按平台安全策略处理，不要把 DSH 运行时复制进包。

## 4. 最小自造流程

示例：`examples/minimal/`，题目、来源、答案均为手写自造，明确标注非真实试题。

实际命令：

```sh
bin/xuean validate examples/minimal/record.json          # 初始 exit 1（source 待核实/审核未做，预期）
bin/xuean record-review ... --check source ...
bin/xuean record-review ... --check text ...
bin/xuean promote examples/minimal/record.json           # exit 0
bin/xuean validate examples/minimal/record.json          # exit 0，阻断 0
bin/xuean build examples/minimal/record.json --run examples/minimal/out
bin/xuean audit runs/examples/minimal/out/demo-uniform-motion.build.pdf --run examples/minimal/out
bin/xuean visual runs/examples/minimal/out/demo-uniform-motion.build.pdf --run examples/minimal/out --page 1
bin/xuean deliver runs/examples/minimal/out/demo-uniform-motion.build.pdf --dest <TMP>/example-delivered
```

结果：

- `promote`、`validate`（通过）、`build`：`exit 0`；
- PDF `runs/examples/minimal/out/demo-uniform-motion.build.pdf`，1 页，55,514 bytes；
- `audit`：`exit 0`，A4 合格、字体嵌入、正文 mode 11.5pt；
- `visual`：`exit 0`，覆盖 1/1 页；
- `deliver`：`exit 0`，哈希一致，PDF sha256 前缀 `8d0e3273a1195019…`。
- 自造示例没有真实图片/真实答案，因此只验证安装、校验、排版、审计、目视、交付链路，不证明真实找题/答案能力。

## 5. 安装/卸载

- 项目内卸载：`./uninstall.sh <TMP>/project` → `exit 0`，技能目录被删除；无安装标记时拒绝删除。
- 不存在的项目根：`./install.sh <TMP>/new-project` → `exit 0`，安装器创建项目根后安装；补测 `doctor` → `exit 0`。
- 本包目录模式：复制包到临时目录，`PYTHON=... ./install.sh ./` → `exit 0`，`bin/xuean --help` `exit 0`；`./uninstall.sh ./` 只删除 `.venv`，保留源码。
- 未做用户级安装。

## 6. 未验证项

- **版本验证范围**：仅实际验证 Python 3.12.14。3.10/3.11/3.13 只是安装器门槛内的预期兼容范围，未逐版验证；不声称“支持 3.10–3.13”。
- 未启动新的 DSH 会话验证实际技能发现；只验证安装路径/frontmatter。
- 未在 Linux/Windows 验证；未在非 macOS 字体环境验证 Typst 中文。
- 未运行 OCR；macOS Vision/Swift 仅检查了可执行路径，没有跑识别。
- 未重新做真实找题/真实网站提取/真实答案映射；不把本次最小示例当成功案例。
- 未验证任意网站/任意版式、登录/付费/反爬、账号配置或大规模并发。
- 未上传 Git；发布包采用 MIT License（Copyright 2026 GAOLI1208），第三方依赖各自许可。

## 7. 复现测试时注意

- `doctor` 只在安装后的 `.venv` 或本包目录模式 `.venv` 下运行，避免误用系统 3.9。
- 示例的 `build` 输出在 `runs/examples/minimal/out/`，不是 `examples/minimal/out/`；README/示例命令已按实际路径修正。
- 测试产生的 PDF、`.venv`、日志均不在发布包内；发布包只保留源码/文档/自造记录。
