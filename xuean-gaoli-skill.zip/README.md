# xuean-gaoli（实验候选）

把真实初高中物理题整理成可讲解、可追溯的 A4 教学学案：按条件找候选、从 HTML/PDF/扫描页提取某题、逐空映射来源答案、审核后生成题目版或来源答案版 PDF。

这是一个**实验候选**，不是成熟的任意网站全自动系统。当前主要验证初高中物理；提取、OCR、图文关系与来源核验可能需要模型辅助，人工审核和逐页目视仍必需。

## 适合什么

- 老师给出知识点/题型条件，需要找真实题并保留来源、答案、图片定位。
- 已有原题 HTML/PDF/扫描页，需要提取成统一记录并生成学案。
- 需要题目版与来源答案版分开；多空题需要逐空映射。
- 需要在项目范围内用 DSH 技能发现，或独立命令行运行。

不适合：任意网站全自动抓取、自动证明原卷真实性、自动代替教师审核、保证找题成功率、把模型摘录当原件。

## 包结构

```text
SKILL.md                     DSH 技能说明（frontmatter + 流程）
README.md                    本文件
LICENSE                      MIT 许可证（Copyright 2026 GAOLI1208）
references/                  按需加载的提取、答案、交付、限制说明
xuean.py                     CLI 入口
xueanlib/                    提取、校验、映射、Typst 排版、审计
templates/question.schema.json
templates/xuean_base.typ     Typst 版式（不随包复制字体）
scripts/vision_ocr.swift     macOS Vision OCR 源文件
examples/minimal/            自造 smoke test（非真实试题）
install.sh / uninstall.sh    项目范围安装/卸载
bin/xuean                    使用本包隔离 .venv 的启动器
requirements.lock.txt        锁定 Python 依赖；不打包解释器/二进制
VALIDATION.md                本次实际验证命令、结果、未验证项
NOTICE.md                    来源、第三方依赖、版权注意
```

没有 `runs/`、真实试卷、个人数据、账号配置、`.venv`、缓存或第三方运行时二进制。

## 环境要求

- 版本门槛：**Python >= 3.10, < 3.14**。当前发布**仅实际验证 Python 3.12**；3.10/3.11/3.13 是预期兼容范围，未逐版验证。安装器用系统/官方 Python 建隔离 `.venv`；不复制 DSH 自带 Python。安装脚本是 POSIX shell，Windows 需 WSL/Git Bash，当前未验证。
- 首次安装需要能访问 PyPI（或自备 wheel 源）。依赖版本见 `requirements.lock.txt`。
- Typst 排版通过 `typst` Python 包完成；不要求系统 `typst` CLI。
- 中文字体：macOS 已验证 `Songti SC`（系统 `Songti.ttc`）。其它系统需要提供兼容中文字体/字体路径，未充分验证。
- 扫描 OCR：macOS `xcrun`/Swift + Xcode Command Line Tools；Linux/Windows 未验证 OCR 路径。
- DSH 集成可选：只需 DSH 从工作区 `.dsh/skills` 发现技能；`web_search`/`web_fetch` 由 DSH 环境提供，包内 CLI 不实现搜索引擎。

## 安装

> GitHub 网页上传通常不保留 Unix 可执行位。首次运行前先执行：
> `chmod +x install.sh uninstall.sh bin/xuean`。
> 也可以不依赖执行位，改用 `sh install.sh ...`。

### 在项目内安装（推荐；不做用户级安装）

```sh
cd /path/to/xuean-gaoli-release
chmod +x install.sh uninstall.sh bin/xuean
./install.sh /path/to/your-project
```

安装器会：

1. 把技能复制到 `/path/to/your-project/.dsh/skills/xuean-gaoli/`；
2. 在该目录创建隔离 `.venv`；
3. 安装 `requirements.lock.txt` 的锁定依赖；
4. 写入 `.xuean-installed` 标记。

若目标已存在且非空，安装器拒绝覆盖。可指定 Python：

```sh
PYTHON=/path/to/python3.12 ./install.sh /path/to/your-project
```

### 只在本包目录使用

```sh
cd /path/to/xuean-gaoli-release
chmod +x install.sh uninstall.sh bin/xuean
PYTHON=/path/to/python3.12 ./install.sh ./
./bin/xuean doctor
```

### 卸载

```sh
./uninstall.sh /path/to/your-project
```

只删除带 `.xuean-installed` 标记的项目技能目录；不会删除用户级目录，也不会删除源码 checkout。

### DSH 发现

安装后从项目的**工作区根**启动 DSH，新会话检查 `.dsh/skills/xuean-gaoli/SKILL.md` 是否可见。若 DSH 从错误 projectRoot 启动，可能发现不到；不要用用户级安装绕过。技能内命令使用 `bin/xuean`，与当前工作目录解耦。

## 快速开始

```sh
SKILL_DIR="/path/to/your-project/.dsh/skills/xuean-gaoli"
"$SKILL_DIR/bin/xuean" --help
"$SKILL_DIR/bin/xuean" doctor

# 自造最小示例（不是真实试题）
"$SKILL_DIR/bin/xuean" validate "$SKILL_DIR/examples/minimal/record.json"
"$SKILL_DIR/bin/xuean" record-review "$SKILL_DIR/examples/minimal/record.json" \
  --check source --note "自造示例来源审核" --evidence "$SKILL_DIR/examples/minimal/source.txt"
"$SKILL_DIR/bin/xuean" record-review "$SKILL_DIR/examples/minimal/record.json" \
  --check text --note "自造示例文字/空位审核" --evidence "$SKILL_DIR/examples/minimal/source.txt"
"$SKILL_DIR/bin/xuean" promote "$SKILL_DIR/examples/minimal/record.json"
"$SKILL_DIR/bin/xuean" build "$SKILL_DIR/examples/minimal/record.json" --run demo-run
"$SKILL_DIR/bin/xuean" audit "$SKILL_DIR/runs/demo-run/demo-uniform-motion.build.pdf" --run demo-run
```

示例题、来源和答案均为手写自造，不对应任何真实试卷/学校/题库；只证明安装与最小流程，不证明真实找题成功率。

## 工作流（简述）

1. **找题**：需求 JSON → 搜索预占/回填 → 详细打开候选 → 逐条件证据（多空/多关系必须有 `coverage`）→ 只选硬条件全满足的第一个候选。
2. **提取**：HTML/PDF/扫描 manifest → 唯一题块 selector → 原图/懒加载图 → fetch meta/URL/hash 链 → 首次记录。
3. **映射**：来源答案原件 → 逐空 `answer.mapping`；占位/作图未列文字阻断。
4. **审核**：source/text/answer/redraw/physics 实际检查；不能改 PASS 字段绕过。
5. **生成**：`promote` → `build` → `audit` → 全页 `visual` → `deliver`；只认同一 PDF 哈希 + audit + 全页目视。

详细命令见 `SKILL.md` 和 `references/`。

## 依赖与平台

| 项目 | 用途 | 说明 |
|---|---|---|
| Python >=3.10, <3.14 | 运行 CLI | 不随包打包；安装器创建隔离 `.venv`；**仅实际验证 3.12**，其他版本未逐版验证 |
| beautifulsoup4 / soupsieve | HTML 解析 | 随 lock 安装 |
| pdfplumber / pdfminer.six / pypdf / pypdfium2 | PDF 提取/渲染 | 随 lock 安装 |
| Pillow | 图片处理 | 随 lock 安装 |
| typst | Typst 排版 | Python 包，不要求系统 Typst CLI |
| sympy | 部分物理/代数检查 | 随 lock 安装 |
| Songti SC / 系统中文字体 | 中文 PDF | 字体不随包；macOS 已用系统字体验证 |
| macOS Vision + Swift | 扫描 OCR | 需要 Xcode CLT；其它平台未验证 |
| DSH | 技能发现、web_search/web_fetch | 可选；包内不实现搜索引擎 |

## 故障排查

**`bin/xuean` 报找不到 .venv**
先运行 `install.sh`；若只在本包目录运行，执行 `PYTHON=... ./install.sh ./`。

**Python 版本过低**
版本门槛是 3.10+（且 <3.14），但当前只实际验证了 Python 3.12；macOS 自带 `/usr/bin/python3` 可能是 3.9，请安装官方 Python 3.12（其他 3.10–3.13 版本未逐版验证）。

**DSH 看不到技能**
确认从工作区根启动、技能位于 `.dsh/skills/xuean-gaoli/SKILL.md`；开新会话；不要在子目录误当 projectRoot。不要用用户级安装绕过。

**Typst/PDF 中文缺字或失败**
检查系统是否有 `Songti SC` 或兼容中文字体；`doctor` 会报告字体。其它平台需自行提供字体并确认 Typst 可发现。

**OCR 失败**
macOS 需要 `xcrun --find swift` 和 Xcode Command Line Tools；Linux/Windows 当前不走 Vision OCR。不要把它当作通用 OCR。

**图片缺失/来源校验失败**
看 `problem.figure_failures`、`source.dom`、`source.fetch` 和 `SRC_FETCH_*`/`SRC_DOM_*`/`FIG_CLAIMED_MISSING`。不要用 `expected=false` 或改 PASS 字段绕过。

**搜索预算/429**
预占不等于实际调用；每次实际搜索后必须回填。预算满或 429 停止继续搜索，但已读合格候选仍可处理；超预算且无候选仍记失败。

**安装依赖失败**
确认网络/PyPI 可用；离线环境请自备 wheel 源并修改安装命令，不要复制原工程的 `.venv` 或 DSH 运行时。

## 来源与版权

- 本发布包的代码、文档和自造示例采用 **MIT License**，版权持有人为 **GAOLI1208**，年份 **2026**；完整文本见根目录 `LICENSE`。
- 本包整理自 DSH 项目内的 `xuean-gaoli` 实验候选技能及其 Python/Typst 代码；MIT 许可是对本发布包文件的授权，不改变第三方依赖、字体、图片来源或上游材料各自的权利与许可。
- 第三方 Python 依赖、字体、Typst 等各自遵循上游许可证；详见 `NOTICE.md` 和 `requirements.lock.txt` 对应包的许可证。
- 包内只带手写自造示例，不带真实试卷、个人数据、账号配置或运行产物。使用真实材料时，来源、答案、图片的版权与使用范围由使用者自行核实。

## 真实局限

- 现为实验候选，主要验证初高中物理；不是任意网站、任意版式的全自动系统。
- 提取/OCR/来源核验可能需要模型辅助；人工审核和逐页目视必需。
- 搜索预算流程可被直接工具调用绕过；CLI 只约束走 CLI 的调用。
- 年度、地区、考试名称、材料性质必须回源核实；不能为过 schema 猜填。
- 不承诺成功率、准确率或“全自动正确”；机器 audit 通过不等于内容/排版合格。
- 当前发布包没有重新跑真实找题；只做安装/发现/doctor/最小自造流程验证。真实能力边界见 `references/limits.md`。

## 验证

实际命令、结果、未验证项见 [VALIDATION.md](VALIDATION.md)。
