#!/usr/bin/env python3
"""学案能力入口（单一 CLI + 子命令）。

用法：
  xuean.py doctor [--write]
  xuean.py extract <pdf|图片> [--page N] [--render-out path.png] [--run RUN]
  xuean.py ocr <图片> [--engine vision] [--fast] [--lang zh-Hans]
  xuean.py fetch <url> [--out path]            # 需要 web_fetch 后端，未接通时给出明确错误
  xuean.py validate <record.json> [--allow-draft] [--run RUN]
  xuean.py preview <record.json> [--run RUN]   # 只做预览，不更新交付状态
  xuean.py build <record.json> [--run RUN] [--draft]
  xuean.py audit <pdf> [--run RUN] [--expect-body-pt 11.5]
  xuean.py record-review <record.json> --check source|text|answer|redraw|physics --note "..." --evidence path
  xuean.py deliver <pdf> [--run RUN] [--dest DIR]
  xuean.py report [--run RUN]

所有子命令失败时返回非零退出码，并输出可读原因。
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from xueanlib import paths  # noqa: E402


def _cmd_doctor(args) -> int:
    from xueanlib import doctor

    return doctor.main(write=args.write)


def _cmd_extract(args) -> int:
    from xueanlib import extract

    return extract.main(args)


def _cmd_crop(args) -> int:
    from xueanlib import extract

    box = tuple(float(v) for v in args.box.split(","))
    if len(box) != 4:
        print("--box 需要 x0,y0,x1,y1 四个 0—1 之间的数")
        return 2
    meta = extract.crop_region(Path(args.src), box, Path(args.out), page_no=args.page, scale=args.scale, preprocess=args.preprocess)
    print(json.dumps(meta, ensure_ascii=False, indent=2))
    return 0


def _cmd_ocr(args) -> int:
    from xueanlib import ocr

    return ocr.main(args)


def _cmd_fetch(args) -> int:
    from xueanlib import fetch as fetch_mod

    return fetch_mod.main(args)


def _cmd_validate(args) -> int:
    from xueanlib import validate

    return validate.main(args)


def _cmd_preview(args) -> int:
    from xueanlib import layout

    return layout.main(args, mode="preview")


def _cmd_build(args) -> int:
    from xueanlib import layout

    return layout.main(args, mode="build")


def _cmd_audit(args) -> int:
    from xueanlib import audit

    return audit.main(args)


def _cmd_record_review(args) -> int:
    from xueanlib import fingerprint

    return fingerprint.record_review(args)


def _cmd_visual(args) -> int:
    from xueanlib import visual

    return visual.main(args)


def _cmd_import(args) -> int:
    from xueanlib import import_question

    return import_question.cli(args)


def _cmd_deliver(args) -> int:
    from xueanlib import deliver

    return deliver.main(args)


def _cmd_report(args) -> int:
    from xueanlib import report

    return report.main(args)


def _cmd_promote(args) -> int:
    from xueanlib import models, validate
    import json

    path = __import__("pathlib").Path(args.record)
    rec = json.loads(path.read_text(encoding="utf-8"))
    issues = validate.collect(rec)
    blocks = [i for i in issues if i["level"] == "block"]
    if blocks:
        for b in blocks:
            print(f"[阻断] {b['code']}: {b['message']}")
        print("拒绝提升：仍有阻断项；不得用 PASS 字段绕过。")
        return 1
    if models.get(rec, "source.status") != models.SOURCE_STATUS_PASS:
        print("拒绝提升：source.status 不是“通过”。")
        return 1
    rec["status"] = "通过"
    payload = json.dumps(rec, ensure_ascii=False, indent=2) + "\n"
    payload.encode("utf-8")
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(path)
    print(f"已提升为正式记录：{path}")
    print(f"  仍有警告：{len([i for i in issues if i['level'] == 'warn'])} 条；未自动视为视觉验收。")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="xuean", description="学案制作能力入口")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("doctor", help="环境自检")
    d.add_argument("--write", action="store_true", help="写入 environment.json")
    d.set_defaults(func=_cmd_doctor)

    e = sub.add_parser("extract", help="PDF/图片定向提取")
    e.add_argument("input")
    e.add_argument("--page", type=int, default=None, help="1 起的页码")
    e.add_argument("--render-out", default=None, help="把目标页渲染为 PNG")
    e.add_argument("--run", default=None)
    e.set_defaults(func=_cmd_extract)

    c = sub.add_parser("crop", help="按归一化区域从页面图/PDF页裁出题图")
    c.add_argument("src")
    c.add_argument("--box", required=True, help="x0,y0,x1,y1（0—1，左上为原点）")
    c.add_argument("--out", required=True)
    c.add_argument("--page", type=int, default=None)
    c.add_argument("--scale", type=float, default=3.0)
    c.add_argument("--preprocess", choices=["raw", "gray"], default="raw")
    c.set_defaults(func=_cmd_crop)

    o = sub.add_parser("ocr", help="本地 OCR（Apple Vision）")
    o.add_argument("image")
    o.add_argument("--engine", default="vision")
    o.add_argument("--fast", action="store_true")
    o.add_argument("--lang", default=None)
    o.add_argument("--json", action="store_true")
    o.set_defaults(func=_cmd_ocr)

    f = sub.add_parser("fetch", help="备用获取路径：curl 取公开页/文件并记录状态与哈希")
    f.add_argument("url")
    f.add_argument("--out", default=None)
    f.add_argument("--timeout", type=int, default=30)
    f.add_argument("--referer", default=None)
    f.set_defaults(func=_cmd_fetch)

    v = sub.add_parser("validate", help="统一题目数据准入校验")
    v.add_argument("record")
    v.add_argument("--allow-draft", action="store_true", help="允许草稿，但标注 DRAFT")
    v.add_argument("--run", default=None)
    v.add_argument("--json", action="store_true")
    v.set_defaults(func=_cmd_validate)

    pv = sub.add_parser("preview", help="预览（始终 DRAFT，不更新交付状态）")
    pv.add_argument("record", nargs="+")
    pv.add_argument("--run", default=None)
    pv.add_argument("--no-qa", action="store_true", help="不生成内部 QA 核对册")
    pv.set_defaults(func=_cmd_preview)

    b = sub.add_parser("build", help="从同一数据生成正式/草稿（可多题合册）")
    b.add_argument("record", nargs="+")
    b.add_argument("--run", default=None)
    b.add_argument("--draft", action="store_true")
    b.add_argument("--no-qa", action="store_true", help="不生成内部 QA 核对册")
    b.set_defaults(func=_cmd_build)

    a = sub.add_parser("audit", help="PDF 输出检查")
    a.add_argument("pdf")
    a.add_argument("--run", default=None)
    a.add_argument("--expect-body-pt", type=float, default=11.5)
    a.set_defaults(func=_cmd_audit)

    r = sub.add_parser("record-review", help="记录一次真实检查并绑定当前指纹")
    r.add_argument("record")
    r.add_argument("--check", required=True, choices=["source", "text", "answer", "redraw", "physics"])
    r.add_argument("--note", required=True)
    r.add_argument("--evidence", action="append", default=[])
    r.add_argument("--status", default=None, help="通过/未通过/待审 等；默认通过")
    r.add_argument("--actor", default="DSH", help="实际执行审核者；默认 DSH，不冒充教师")
    r.add_argument("--method", default="DSH 回源/目视核对（模型辅助，非教师本人复核）")
    r.set_defaults(func=_cmd_record_review)

    vs = sub.add_parser("visual", help="逐页目视记录（绑定当前 PDF 哈希）")
    vs.add_argument("pdf")
    vs.add_argument("--page", type=int, default=None)
    vs.add_argument("--note", default=None)
    vs.add_argument("--run", required=True)
    vs.add_argument("--viewer", default="full-page-png@2x")
    vs.add_argument("--action", choices=["record", "status"], default="record")
    vs.set_defaults(func=_cmd_visual)

    dl = sub.add_parser("deliver", help="版本化交付并复核哈希")
    dl.add_argument("pdf")
    dl.add_argument("--run", default=None)
    dl.add_argument("--dest", default="delivered")
    im = sub.add_parser("import", help="公开 HTML/扫描页 → 统一题记录（保真公式与答案）")
    im.add_argument("--profile", choices=["jyeoo", "scan"], required=True)
    im.add_argument("--source", required=True, help="jyeoo: HTML 路径；scan: manifest.json")
    im.add_argument("--url", default="", help="公开来源 URL")
    im.add_argument("--id", required=True, help="记录 ID")
    im.add_argument("--fig-dir", default=None)
    im.add_argument("--records", default="records")
    im.add_argument("--stage", choices=["初中", "高中"], default=None,
                    help="来源实际学段；不设默认，jyeoo 导入必须显式给出")
    im.add_argument("--year", type=int, default=None,
                    help="考试年份；未知时用 --year-label，不凭空填默认年")
    im.add_argument("--year-label", default="",
                    help="未知/学年年份的文字标签，如“2023/2024学年”或“未标”")
    im.add_argument("--year-evidence", default="",
                    help="年份从原页哪一句/哪一处核到；没有证据就留空")
    im.add_argument("--delivery", choices=["questions_only", "with_sourced_answers"],
                    default="questions_only", help="默认题目版；来源答案版须映射完整后再选")
    im.add_argument("--source-role", choices=["original", "derived", "model_excerpt", "transcription"],
                    default="unknown", help="导入的 HTML 是原始页还是模型派生摘录；新 HTML 默认 unknown 不放行")
    im.add_argument("--original-file", default=None,
                    help="派生摘录必须链回的实际原文件/HTML")
    im.add_argument("--original-url", default=None,
                    help="派生摘录对应的最终原始 URL")
    im.add_argument("--scope-selector", default="section.quesborder, div.quesborder",
                    help="题目主块的 CSS selector 清单（站点无关，按原 DOM 定界）")
    im.add_argument("--original-scope-selector", default=None,
                    help="派生摘录对应的原件题块 selector；不填则沿用 scope-selector")
    im.add_argument("--fetch-meta", default=None,
                    help="xuean.py fetch 生成的原始页 meta JSON（含 final_url/sha256/status）")
    im.add_argument("--original-fetch-meta", default=None,
                    help="派生摘录对应的原件 fetch meta JSON")
    im.add_argument("--material-type", choices=["exam", "homework", "question_bank", "textbook", "unknown"],
                    default=None, help="来源真实性质；默认按 exam_type 推断，不冒充考试")
    im.add_argument("--publisher", default="菁优网（jyeoo.com）",
                    help="来源发布者；本地/其他站点应显式给出，不能冒充")
    im.add_argument("--region", default="")
    im.add_argument("--exam", default="")
    im.add_argument("--exam-type", default="")
    im.add_argument("--points", type=int, default=0)
    im.set_defaults(func=_cmd_import)
    dl.set_defaults(func=_cmd_deliver)

    rp = sub.add_parser("report", help="汇总一次 run 的检查记录")
    rp.add_argument("--run", default=None)
    rp.set_defaults(func=_cmd_report)

    from xueanlib.task import register as _register_task

    _register_task(sub)

    pr = sub.add_parser("promote", help="审核齐全后把记录提升为正式状态（不绕过阻断）")
    pr.add_argument("record")
    pr.set_defaults(func=_cmd_promote)

    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    paths.ensure_dirs()
    try:
        return int(args.func(args) or 0)
    except SystemExit:
        raise
    except Exception as exc:
        print(f"错误：{type(exc).__name__}: {exc}", file=sys.stderr)
        if "--debug" in (argv or sys.argv):
            traceback.print_exc()
        return 2


if __name__ == "__main__":
    sys.exit(main())
