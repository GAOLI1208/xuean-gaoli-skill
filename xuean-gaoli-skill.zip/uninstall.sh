#!/bin/sh
# Project-scoped uninstaller. Refuses to remove a source checkout.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_ROOT=${1:-$(pwd)}
if [ ! -d "$PROJECT_ROOT" ]; then
  mkdir -p "$PROJECT_ROOT" || { echo "无法创建项目根目录：$PROJECT_ROOT" >&2; exit 2; }
fi
PROJECT_ROOT=$(CDPATH= cd -- "$PROJECT_ROOT" && pwd)
DEST="$PROJECT_ROOT/.dsh/skills/xuean-gaoli"
if [ "$ROOT" = "$PROJECT_ROOT" ]; then
  if [ -d "$ROOT/.venv" ]; then
    rm -rf "$ROOT/.venv"
    echo "已删除本包目录的隔离 .venv（源码文件保留）"
  else
    echo "本包目录没有隔离 .venv"
  fi
  exit 0
fi
if [ ! -f "$DEST/.xuean-installed" ]; then
  echo "未找到安装标记：$DEST/.xuean-installed" >&2
  exit 2
fi
rm -rf "$DEST"
echo "已卸载：$DEST"
