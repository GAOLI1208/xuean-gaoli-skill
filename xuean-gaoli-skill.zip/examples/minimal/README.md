# 自造最小示例

本目录的题目、来源文件和答案均为**自造**，不对应任何真实试卷、学校、题库或账号；只用于安装后的 `validate`/`promote`/`build` smoke test。

```sh
"$SKILL_DIR/bin/xuean" validate examples/minimal/record.json
"$SKILL_DIR/bin/xuean" record-review examples/minimal/record.json --check source \
  --note "自造示例，仅验证来源审核" --evidence examples/minimal/source.txt
"$SKILL_DIR/bin/xuean" record-review examples/minimal/record.json --check text \
  --note "自造示例，文字/空位核对" --evidence examples/minimal/source.txt
"$SKILL_DIR/bin/xuean" promote examples/minimal/record.json
"$SKILL_DIR/bin/xuean" build examples/minimal/record.json --run examples/minimal/out
"$SKILL_DIR/bin/xuean" audit runs/examples/minimal/out/demo-uniform-motion.build.pdf --run examples/minimal/out
```

`questions_only` 示例不展示答案；生成物写到 `examples/minimal/out/`，该目录被 `.gitignore` 忽略。它不是真实找题能力的证明。
