#!/bin/sh
# Project-scoped installer. Creates an isolated .venv; no user-level install.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_ROOT=${1:-$(pwd)}
if [ ! -d "$PROJECT_ROOT" ]; then
  mkdir -p "$PROJECT_ROOT" || { echo "无法创建项目根目录：$PROJECT_ROOT" >&2; exit 2; }
fi
PROJECT_ROOT=$(CDPATH= cd -- "$PROJECT_ROOT" && pwd)
if [ "$ROOT" = "$PROJECT_ROOT" ]; then
  DEST="$ROOT"
else
  DEST="$PROJECT_ROOT/.dsh/skills/xuean-gaoli"
fi
PYTHON=${PYTHON:-python3}

if ! command -v "$PYTHON" >/dev/null 2>&1; then
  echo "找不到 Python：$PYTHON；可设置 PYTHON=/path/to/python3.12" >&2
  exit 2
fi
"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("版本门槛为 Python >= 3.10；当前发版仅实际验证 3.12（当前 %s）" % sys.version.split()[0])
if sys.version_info >= (3, 14):
    raise SystemExit("版本门槛为 Python < 3.14；当前发版仅实际验证 3.12；3.10–3.13 为预期范围，未逐版验证")
print("Python", sys.version.split()[0])
PY

if [ "$ROOT" != "$DEST" ]; then
  mkdir -p "$PROJECT_ROOT/.dsh/skills"
  if [ -e "$DEST" ] && [ -n "$(ls -A "$DEST" 2>/dev/null || true)" ]; then
    echo "目标已存在且非空：$DEST" >&2
    echo "请先运行 ./uninstall.sh \"$PROJECT_ROOT\"，或换一个项目根目录。" >&2
    exit 3
  fi
  mkdir -p "$DEST"
  # Copy only distributable files; never runtime data or a local venv.
  (cd "$ROOT" && tar \
    --exclude='.venv' --exclude='.git' --exclude='__pycache__' \
    --exclude='*.pyc' --exclude='.DS_Store' --exclude='.cache' \
    --exclude='runs' --exclude='sources' --exclude='records' \
    --exclude='environment.json' -cf - .) | (cd "$DEST" && tar -xf -)
fi

cd "$DEST"
python_bin="$PYTHON"
if [ ! -x ".venv/bin/python" ]; then
  "$python_bin" -m venv .venv
fi
.venv/bin/python -m pip install --disable-pip-version-check --upgrade pip >/dev/null
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.lock.txt
touch .xuean-installed
echo "已安装：$DEST"
echo "运行：$DEST/bin/xuean doctor"
echo "若使用 DSH：从项目根启动 DSH，确认 .dsh/skills/xuean-gaoli/SKILL.md 被发现。"
