#set page(paper: "a4", margin: (x: 2cm, top: 1.8cm, bottom: 1.8cm), numbering: "1 / 1")
#set text(font: ("Songti SC",), size: 11.5pt, lang: "zh", region: "cn")
#set par(leading: 0.85em, spacing: 0.9em, justify: true)

#show heading.where(level: 1): it => block(above: 1.2em, below: 0.6em, text(size: 17pt, weight: "bold", it.body))
#show heading.where(level: 2): it => block(above: 1em, below: 0.5em, text(size: 13pt, weight: "bold", it.body))
#show heading.where(level: 3): it => block(above: 0.8em, below: 0.4em, text(size: 11.5pt, weight: "bold", it.body))

#let meta(body) = text(size: 10pt, fill: rgb("#444444"))[#body]
#let rule = line(length: 100%, stroke: 0.4pt + rgb("#999999"))
#let pagebreak = pagebreak
