---
name: xuean-gaoli
description: 制作初高中物理教学学案：按条件找真实题并给逐条件证据候选；从给定 HTML/PDF/扫描页提取某题并保留原件定位；把已选题生成 A4 11.5pt 学案（题目版/来源答案版），完成审核、审计、逐页目视与交付。实验候选，项目范围安装，不做用户级安装。
---

# xuean-gaoli（实验候选）

## 范围与边界

- 主要验证初高中物理。知识点、题型、地区、年份都应来自老师需求，不按某道题、某个网站或某种电路写死流程。
- 只用真实公开材料或用户提供的本地文件；不购买、不注册、不登录付费题库、不导 Cookie、不绕验证。
- 不创建子代理，不自动上传 Git；默认项目范围安装，不装用户级全局技能。
- **搜索预算不是硬隔离**：当前流程约束是每次实际搜索前 `reserve-search`、执行后 `add-search --reservation`；如果工具被直接调用而绕过 CLI，CLI 无法拦截。必须保存可核的实际搜索轨迹，不能把“预占数”当成真实调用数。
- 提取、OCR、来源核验可能需要模型辅助；不是任意网站全自动。年份、地区、考试名称、材料性质必须回源核实，不能为过 schema 猜填。
- 搜索摘要不是原题；有答案不等于答案完整；分号段数相等不等于逐空映射。

## 环境与入口

包根目录记为 `SKILL_DIR`；不要使用外部项目的 `.venv`、解释器或模板。

```sh
SKILL_DIR="$(cd "$(dirname "$0")" && pwd)"   # 在包根执行时
"$SKILL_DIR/bin/xuean" --help
"$SKILL_DIR/bin/xuean" doctor
```

首次使用或重新安装隔离依赖：

```sh
cd "$SKILL_DIR"
PYTHON=python3.12 ./install.sh ./  # 若在包根直接安装
# 或在任意项目根安装：
./install.sh /path/to/project
```

安装脚本只在项目 `.dsh/skills/xuean-gaoli/` 建隔离 `.venv`，不修改用户级目录；卸载用 `./uninstall.sh /path/to/project`。

DSH 从工作区的 `.dsh/skills` 项目范围发现技能；安装后**新会话**确认 `SKILL.md` 可见。DSH 只负责发现与调用说明，PDF 生成由本包 `bin/xuean` 的 Typst/Python 依赖完成。

## 入口 A：按条件找候选

1. 把老师原话写成需求 JSON；未指定的字段写 `null`，不补默认学段/年份。示例见 `references/search-and-candidates.md`。
2. 建任务，按计划搜索；每项默认最多 6 次搜索、4 个详细候选。**每次实际搜索前预占**，执行后回填结果/429/实际打开数；达到 6/4 或 HTTP 429 停止继续搜索，但已读且合格的候选仍可选。
3. 读到完整原题后，逐条件写“字段 + 原文片段 + 覆盖范围 + 满足/不符/未知”。多空/多关系题必须写 `coverage`；缺覆盖时 `select` 拒绝。
4. 硬条件有不符或未知不选；题材相近但所求不同必须拒绝。正常流程停下等老师选，不自动做整册。

```sh
"$SKILL_DIR/bin/xuean" task new --file req.json --id demo-topic
"$SKILL_DIR/bin/xuean" task plan demo-topic
"$SKILL_DIR/bin/xuean" task reserve-search demo-topic --query "..."
# 实际搜索后：
"$SKILL_DIR/bin/xuean" task add-search demo-topic --reservation S01 --file search.json
"$SKILL_DIR/bin/xuean" task add-candidate demo-topic --record records/cand.json --checks checks.json
"$SKILL_DIR/bin/xuean" task select demo-topic C1
"$SKILL_DIR/bin/xuean" task resume demo-topic
```

## 入口 B：给 URL/本地材料提指定题

先判材料类型；不把搜索摘要或模型摘录当原题。

- HTML：`import --profile jyeoo` 是当前随包 HTML 适配器的**兼容名称**，不代表对任意站点或整站支持。必须显式 `--stage`、`--year`/`--year-label`、`--source-role original|derived`；懒加载属性 `data-src`/`data-lazysrc`、相对 URL 会解析，失败写 `problem.figure_failures`。
- 原始 DOM：`--scope-selector` 必须唯一命中 1 个题块；记录 `source.dom`（scope_count、declared/usable/missing、lazy_attrs、hash）。网络原件要保存 fetch meta，并校验 `final_url`/`status`/`sha256`；记录 URL 必须等于 `requested_url` 或 `final_url` 才属于同一次抓取，合法重定向记 `SRC_FETCH_REDIRECT`，其它 URL 一律 `SRC_FETCH_URL_MISMATCH`（同一文件/hash 也不行）。
- 派生摘录：必须再给 `--original-file`/`--original-url`/`--original-scope-selector`；原文件/hash/DOM 链必须核过，原件题块也必须唯一命中。摘录不是原件。
- 年份未知：用 `--year-label` + `--year-evidence`，不要默认 2024。材料性质用 `exam|homework|question_bank|textbook|unknown`；只有 `exam` 才配“真实考试题”页头。
- PDF/扫描：用 manifest 写来源文件/hash、题目页/区域/续页、答案页/区域、身份、输出；扫描 OCR 只识别目标区域，跨页必须是同一题跨页。

```sh
"$SKILL_DIR/bin/xuean" import --profile jyeoo --source page.html \
  --url https://example.org/page --id demo-1 --stage 高中 \
  --year-label "2023/2024学年" --year-evidence "原页页眉" \
  --region 未标 --exam "自造/示例卷名" --exam-type 练习 --material-type homework \
  --source-role original --scope-selector "section.quesborder" \
  --fetch-meta page.html.meta.json --delivery questions_only
```

## 入口 C：生成学案

1. `validate`；有阻断就补材料/映射/审核，**不改 PASS 字段绕过**。
2. `questions_only` 不要求来源答案；`with_sourced_answers` 必须有答案原件和逐空 `answer.mapping`（`mapping_status=complete`）。多空题显式 `problem.answer_slots`；老师只要题目版时，即使有答案也 `display_answers=false`。
3. 逐项 `record-review`：`source`、`text`、必要时 `answer`/`redraw`；`optional_explanations` 才加 `physics`。审核记的是实际检查，不是导入器自动生成。
4. 全部通过后 `promote`，再 `build`、`audit`、逐页 `visual`、`deliver`。
5. 首次导入保存在 `records/first/`，后续映射/审核不覆盖；每次构建尝试保存在 run 的 `build-attempts/`，首次失败不消失。

```sh
"$SKILL_DIR/bin/xuean" validate records/demo-1.json
"$SKILL_DIR/bin/xuean" record-review records/demo-1.json --check source --note "回源核对" --evidence page.html
"$SKILL_DIR/bin/xuean" record-review records/demo-1.json --check text --note "逐空核对" --evidence page.html
"$SKILL_DIR/bin/xuean" promote records/demo-1.json
"$SKILL_DIR/bin/xuean" build records/demo-1.json --run demo-run
"$SKILL_DIR/bin/xuean" audit runs/demo-run/demo-1.build.pdf --run demo-run
"$SKILL_DIR/bin/xuean" visual runs/demo-run/demo-1.build.pdf --run demo-run --page 1 --note "逐页目视"
"$SKILL_DIR/bin/xuean" deliver runs/demo-run/demo-1.build.pdf --dest runs/demo-delivered
```

## 硬规矩

- 图：题干出现“如图/图中/图线/图甲/图像/坐标/曲线”等引用已有图的上下文，没有图或图失败就阻断；`expected=false` 不能把漏图变完成。只有“请画出/作出/补全…”且没有引用已有图，才是学生作图，不要求原题有图；“曲线运动”等概念词不算图。
- 来源：原始 DOM 声明图数量与记录（含失败）要对上；派生摘录必须有原文件/hash/DOM/selector 链。网络来源必须有 fetch metadata 和同一次抓取的 URL 链。
- 身份：年份/地区未知要明示；作业/题库/练习不能写“真实考试题”页头。
- 答案：映射必须有来源位置 + 原文片段 + 目标空位；`answer` 是“见解答/见解析”或作图未列文字时阻断。
- 交付：只认同一 PDF 哈希 + audit + 全页 visual；换 PDF、只看部分页都使旧记录失效。机器 audit 通过不等于排版/内容合格，必须逐页目视。

## 失败与停止

- 6 次搜索/4 个详细候选用完仍无满足候选：报告具体差距，不放宽硬条件，不拼接不同候选。
- HTTP 429 停止继续搜索并保留证据；已读候选可继续处理，但不能把超预算的失败回填成成功。
- 图下载/解码失败、映射未覆盖、答案为占位、原卷/答案身份冲突：停下说明，不猜。

## 按需 references

- `references/search-and-candidates.md`：需求 JSON、任务命令、候选证据、预算/429。
- `references/extract.md`：HTML/PDF/扫描、DOM/图/fetch、人工标注。
- `references/answers.md`：答案原件、逐空映射、多空/作图、占位。
- `references/delivery.md`：审核、promote/build/audit/visual/deliver、版面。
- `references/limits.md`：真实验证边界、平台依赖和未验证项。
- `references/knowledge-checks.md`：初高中物理通用检查提醒，不是专用流程。
