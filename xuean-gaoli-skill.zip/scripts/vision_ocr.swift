// Apple Vision 本地 OCR 入口（macOS）。
// 用法: vision_ocr <图片路径> [--fast] [--lang zh-Hans,en-US] [--max-lines N]
// 输出: JSON 到 stdout，含引擎、尺寸、逐行文本/置信度/包围盒、耗时、截断提示。
// 设计说明：只做文字识别；电路拓扑、轨道形状仍需视觉读图，不在此判断。
import Foundation
import Vision
import ImageIO

struct Line: Encodable {
    let text: String
    let confidence: Double
    let bbox: [Double] // [x, y, w, h]，Vision 归一化坐标，原点左下
}

struct Output: Encodable {
    let engine: String
    let engine_version: String
    let image: String
    let width: Int
    let height: Int
    let fast: Bool
    let languages: [String]
    let lines: [Line]
    let truncated: Bool
    let elapsed_ms: Int
}

func fail(_ message: String, _ code: Int32 = 1) -> Never {
    let payload = ["error": message]
    if let data = try? JSONSerialization.data(withJSONObject: payload),
       let text = String(data: data, encoding: .utf8) {
        print(text)
    }
    exit(code)
}

var args = Array(CommandLine.arguments.dropFirst())
guard let path = args.first else { fail("missing image path") }
args.removeFirst()

var fast = false
var maxLines = 400
var requestedLangs: [String] = []
var i = 0
while i < args.count {
    switch args[i] {
    case "--fast": fast = true
    case "--lang":
        i += 1
        if i < args.count { requestedLangs = args[i].split(separator: ",").map(String.init) }
    case "--max-lines":
        i += 1
        if i < args.count { maxLines = Int(args[i]) ?? maxLines }
    default: break
    }
    i += 1
}

guard let source = CGImageSourceCreateWithURL(URL(fileURLWithPath: path) as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
    fail("cannot read image: \(path)")
}

let started = Date()
let request = VNRecognizeTextRequest()
request.recognitionLevel = fast ? .fast : .accurate
request.usesLanguageCorrection = !fast

let supportedAccurate = (try? VNRecognizeTextRequest.supportedRecognitionLanguages(for: .accurate, revision: VNRecognizeTextRequestRevision3)) ?? []
let supportedFast = (try? VNRecognizeTextRequest.supportedRecognitionLanguages(for: .fast, revision: VNRecognizeTextRequestRevision3)) ?? []
let supported = fast ? supportedFast : supportedAccurate
var languages: [String] = []
if !requestedLangs.isEmpty {
    // 不支持的语种直接报错，避免静默用 Latin 模型识别中文
    let unsupported = requestedLangs.filter { !supported.contains($0) }
    if !unsupported.isEmpty { fail("unsupported languages: \(unsupported) supported: \(supported)") }
    languages = requestedLangs
} else if supported.contains("zh-Hans") {
    languages = ["zh-Hans", "en-US"].filter { supported.contains($0) }
} else if supported.contains("zh-Hant") {
    languages = ["zh-Hant", "en-US"].filter { supported.contains($0) }
} else {
    languages = supported.filter { $0.hasPrefix("en") }
}
request.recognitionLanguages = languages

let handler = VNImageRequestHandler(cgImage: image, options: [:])
do {
    try handler.perform([request])
} catch {
    fail("vision request failed: \(error)")
}

let observations = request.results ?? []
var lines: [Line] = []
var truncated = false
for observation in observations {
    if lines.count >= maxLines { truncated = true; break }
    guard let candidate = observation.topCandidates(1).first else { continue }
    let box = observation.boundingBox
    lines.append(Line(
        text: candidate.string,
        confidence: Double(candidate.confidence),
        bbox: [Double(box.origin.x), Double(box.origin.y), Double(box.width), Double(box.height)]
    ))
}

let output = Output(
    engine: "apple-vision",
    engine_version: "VNRecognizeTextRequestRevision3",
    image: path,
    width: image.width,
    height: image.height,
    fast: fast,
    languages: languages,
    lines: lines,
    truncated: truncated,
    elapsed_ms: Int(Date().timeIntervalSince(started) * 1000)
)
let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys]
do {
    let data = try encoder.encode(output)
    FileHandle.standardOutput.write(data)
    print("")
} catch {
    fail("encode failed: \(error)")
}
