# 审核、版式与交付

## 审核矩阵

| 模式 | 必须 | 不自动要求 |
|---|---|---|
| `questions_only` | source、text、必要图 redraw | answer、physics、独立重解 |
| `with_sourced_answers` | 以上 + answer（原件+映射 complete） | 自写长解、独立重算、physics |
| `optional_explanations` | 以上适用项 + physics | 冒充原卷答案 |

- `validate` 的阻断不能靠改 PASS 字段绕过。
- 审核字段写“通过”不等于实际检查；指纹必须与当前内容一致，证据文件必须存在且 hash 匹配。
- `promote` 只把已审核记录提升；版本/内容变化会使审核失效。

## 命令

```sh
"$SKILL_DIR/bin/xuean" validate records/demo-1.json
"$SKILL_DIR/bin/xuean" promote records/demo-1.json
"$SKILL_DIR/bin/xuean" build records/demo-1.json --run demo-run
"$SKILL_DIR/bin/xuean" audit runs/demo-run/demo-1.build.pdf --run demo-run
"$SKILL_DIR/bin/xuean" visual runs/demo-run/demo-1.build.pdf --run demo-run --page 1 --note "逐页目视"
"$SKILL_DIR/bin/xuean" deliver runs/demo-run/demo-1.build.pdf --dest runs/demo-delivered
```

- A4、正文 11.5pt、中文字体嵌入、题目与来源索引分块；不把内部 selector、本地路径、长 URL 放进教学正文。
- 交付只认同一 PDF 哈希 + audit + 全部页面 visual；换 PDF、重导出、只看部分页都使旧记录失效。
- 机器 audit 通过不等于排版/内容合格；逐页检查标题孤页、图问分离、空位消失、波浪号/单位丢失。

## 首次/构建留存

首次导入保存在 `records/first/`；每次 `build` 在 run 的 `build-attempts/` 保存尝试和阻断。后续成功不能删除首次失败。
