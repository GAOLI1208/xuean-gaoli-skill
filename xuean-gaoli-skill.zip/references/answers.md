# 来源答案与逐空映射

## 四件事分开

1. 来源身份：卷名/年份/地区/题号/材料性质。
2. 题面完整：题干、选项、小问、空位、图。
3. 答案原件 + 映射：原答案页/文件，逐空对应。
4. 独立解题：是否自己重算/重解；来源答案版不强制自写长解。

`record-review` 的 `source/text/answer/redraw` 是人工检查记录，不是导入器自动生成。`physics` 只在自写讲解或独立解题时适用。

## 模式

- `questions_only`：不要求来源答案，即使有答案也不显示；老师只要题目版时 `display_answers=false`。
- `with_sourced_answers`：必须有答案原件和逐空 `answer.mapping`，`mapping_status=complete`。
- `optional_explanations`：在来源答案基础上另写讲解/重解；必须与来源答案分开。

## 多空题

显式写 `problem.answer_slots`，例如：

```json
[
  {"id": "(1)", "label": "(1)", "kind": "text", "required": true},
  {"id": "(2)", "label": "(2)", "kind": "text", "required": true}
]
```

映射：

```json
{
  "source_locator": "答案页/答案块/selector",
  "source_quote": "原答案原文片段",
  "answer": "该空答案",
  "targets": ["(1)"],
  "status": "mapped"
}
```

- 一个父 label 不能覆盖多个子空；每个 required 空位都要精确命中。
- `source_locator`、`source_quote`、`targets` 缺一不可。
- 答案是“见解答/见解析/略/作图见解析”或作图未列文字时阻断，不能算完整。
- 答案图必须存在且 hash 匹配；答案图不能拿题图冒充。
