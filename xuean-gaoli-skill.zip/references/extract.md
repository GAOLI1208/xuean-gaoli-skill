# 完整提取

## HTML

`--profile jyeoo` 是随包 HTML 适配器的兼容名称，不是对任意站点/整站支持的承诺。

```sh
"$SKILL_DIR/bin/xuean" import --profile jyeoo --source page.html \
  --url https://example.org/page --id demo-1 --stage 高中 \
  --year 2024 --year-evidence "原页试卷标题" --region 示例地区 \
  --exam "示例考试名" --exam-type 高考 --material-type exam \
  --source-role original --scope-selector "section.quesborder" \
  --fetch-meta page.html.meta.json --delivery questions_only
```

- 必须显式给实际 `--stage`，并给 `--year` 或 `--year-label`；`--year` 必须有 `--year-evidence`。
- 必须声明 `--source-role original|derived`；`unknown` 会被 `SRC_ORIGIN_UNKNOWN` 阻断。
- 派生摘录还要 `--original-file`、`--original-url`、`--original-scope-selector`；证据优先指向原文件。

## DOM、图与 fetch

- `--scope-selector` 必须唯一命中 1 个题块；记录 `scope_count`、`declared_images`、`usable_images`、`missing_src`、`lazy_attrs` 和 DOM hash。
- 图片属性包括 `src`、`data-src`、`data-lazysrc`、`srcset`；相对 URL 按原页解析。失败写 `problem.figure_failures`，不能静默丢。
- 网络原件先用 `fetch` 保存 HTML + meta；记录 URL 必须等于 `fetch.requested_url` 或 `fetch.final_url`。两者都不等是 `SRC_FETCH_URL_MISMATCH`；合法重定向记 `SRC_FETCH_REDIRECT`；缺 requested/final 分别阻断。
- `fetch` hash 必须绑定本地原件 hash；本地 `file://` 材料不强制网络 fetch。
- 题干引用已有图（如图/图中/图线/图甲/图像/坐标/曲线）必须有图；只有“请画出/作出/补全…”且没有引用已有图，才是学生作图，不要求原题有图；“曲线运动”等概念词不算图。

## PDF / 扫描 manifest

manifest 至少写：来源文件/hash、题目页/区域/续页、答案页/区域、身份（年份证据/地区/卷名/题号）、材料性质、输出目录。原生 PDF 优先文本层+bbox；扫描只 OCR 目标区域并缓存；跨页必须是原卷同一题跨页，记录 `cross_page`/`source_pages`。

```sh
"$SKILL_DIR/bin/xuean" import --profile scan --source path/to/manifest.json --id demo-1
```

## 人工标注

新站结构不匹配时，只基于已保存 DOM/页图提出边界/映射清单；程序核位置和资产。手填/改字/选框/整段转录必须写 `problem.manual`，标明 DSH 辅助，不能包装成全自动。
