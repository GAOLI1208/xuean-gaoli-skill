# 当前能力与限制

## 已验证范围

- 主要验证初高中物理；HTML 提取、PDF/扫描 manifest、来源答案逐空映射、A4 Typst 生成、audit/visual/deliver 的**机制**已走过。
- 本发布包只带自造最小示例，不带真实试卷、`runs/`、账号配置或个人数据。
- 安装/发现/help/doctor/最小自造流程的实测见根目录 `VALIDATION.md`。

## 平台与依赖

- 版本门槛：Python >= 3.10, < 3.14；**当前仅实际验证 3.12**。3.10/3.11/3.13 为预期兼容范围，未逐版验证。安装器在项目内创建隔离 `.venv`，不打包解释器或第三方二进制。
- 依赖锁定在 `requirements.lock.txt`：BeautifulSoup、pdfplumber/pdfminer、pypdf、pypdfium2、Pillow、Typst Python 包、SymPy 等；各自遵循上游许可证。
- Typst 排版需要系统中文字体；macOS 已验证 `Songti SC`（`Songti.ttc`）。其它系统需要自行提供兼容字体/字体路径，当前未验证。
- 扫描 OCR 使用 macOS `xcrun`/Swift 编译 `scripts/vision_ocr.swift`，需要 Xcode Command Line Tools；未在 Windows/Linux 验证 OCR。
- DSH 是可选集成：技能从工作区 `.dsh/skills` 发现；本包不做用户级安装，不自动上传 Git。

## 真实局限

- 现为**实验候选**，主要验证初高中物理；不是任意网站、任意版式的全自动系统。
- 提取、OCR、公式/图文关系、来源核验可能需要模型辅助；人工审核和逐页目视仍必需。
- 搜索预算流程可能被直接工具调用绕过；CLI 只能约束走 CLI 的调用。年度/地区/材料性质必须回源核实。
- 不承诺成功率或“全自动正确”；不能把“运行成功”“生成 PDF”当作找题/答案正确。
- 站点适配是有限适配；不要把某个站点的 selector 复用到其它站点。
- 真实试卷、个人数据、账号配置、`.venv`、缓存和运行产物不随包分发。
