# 搜索与候选

## 需求 JSON

未指定字段写 `null`，不要补默认学段、年份或地区。

```json
{
  "request": "老师原话/请求摘要",
  "stage": "初中或高中；未指定写 null",
  "knowledge_concepts": ["..."],
  "asked_relation": "原题实际求什么关系/量",
  "question_type": "choice 或 constructed_response；未指定写 null",
  "region": null,
  "year": null,
  "exam_type": null,
  "figure_required": true,
  "answer_required": "sourced",
  "conditions": [
    {"id": "H1", "text": "硬条件原文", "kind": "semantic", "hard": true}
  ],
  "preferences": [],
  "notes": ""
}
```

## 任务命令

```sh
"$SKILL_DIR/bin/xuean" task new --file req.json --id demo-topic
"$SKILL_DIR/bin/xuean" task plan demo-topic
"$SKILL_DIR/bin/xuean" task reserve-search demo-topic --query "关键词"
# 实际执行一次 web_search/web_fetch 后：
"$SKILL_DIR/bin/xuean" task add-search demo-topic --reservation S01 --file search.json
"$SKILL_DIR/bin/xuean" task add-candidate demo-topic --record records/cand.json --checks checks.json
"$SKILL_DIR/bin/xuean" task select demo-topic C1
"$SKILL_DIR/bin/xuean" task resume demo-topic
```

`reserve-search` 只预占；真正执行搜索后必须 `add-search --reservation` 回填实际 query、结果数、详细打开数和失败。预占数不等于实际调用数，报告两者。

## 预算与 429

- 默认每项 6 次搜索、4 个详细候选；详细打开也单独计数。
- 达到上限或 HTTP 429 后停止继续搜索；已读且硬条件满足的候选仍可 `add-candidate/select`。
- 429 是止损信号，不等于“超预算后自动成功”；超预算且没有合格候选仍记失败。
- 若工具被直接调用而绕过 CLI，CLI 不能硬拦截；必须靠实际轨迹和报告披露，不夸大“预算已强制”。

## 候选证据卡

逐条件写：

```json
[
  {
    "condition_id": "H1",
    "status": "satisfied",
    "field": "problem.stem",
    "quote": "原页可回查片段",
    "coverage": "多空/多关系时逐项列出覆盖范围",
    "note": "判断依据"
  }
]
```

- `satisfied` 必须有原文片段；不能用“题型像”“机构标签”代替。
- 多空、多关系、多个小问必须写 `coverage`，短词不能证明多个空位。
- 硬条件有不符/未知不选。搜索顺序先核对；第一个满足全部硬条件的候选选中，不因后面更漂亮换题。
- 选中后保存原件、fetch meta、首版记录和后续辅助版本；不覆盖首次记录。
