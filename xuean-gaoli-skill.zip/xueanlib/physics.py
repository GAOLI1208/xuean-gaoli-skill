"""物理一致性检查：题图关系、初始位置、小问与答案对应、答案比较声明、代数残差。

只做可判定的部分。系统选择、守恒条件是否成立仍需人（或模型视觉+物理）判断，
这里把“图与推导冲突”这类可判定冲突挡在正式生成之前。
"""

from __future__ import annotations

from . import models

SIGN_POS = {"+", "right", "右", "正"}
SIGN_NEG = {"-", "left", "左", "负"}


def check_positions(rec: dict) -> list[dict]:
    """objects: {id, side: left/right, ref: 参照物}  vs  solution.initial_positions: {id: "+L"/"-L"/0}"""
    issues = []
    fig = models.figure(rec) or {}
    rel = fig.get("relations") or {}
    initial = models.get(rec, "solution.initial_positions", {}) or {}
    for obj in rel.get("objects") or []:
        oid = obj.get("id")
        side = (obj.get("side") or "").lower()
        ref = obj.get("ref")
        if not oid or side not in ("left", "right", "above", "below"):
            continue
        if oid not in initial:
            issues.append(
                {
                    "code": "PHYS_POSITION_UNDECLARED",
                    "level": "warn",
                    "message": f"图中物体 {oid} 在 {ref} 的 {side}，但解析未声明初始坐标正负",
                }
            )
            continue
        val = str(initial[oid]).strip()
        sign = SIGN_POS if val.startswith("+") or val in ("0", "0.0") else SIGN_NEG if val.startswith("-") else None
        if sign is None:
            issues.append({"code": "PHYS_POSITION_UNPARSED", "level": "warn", "message": f"{oid} 初始坐标 {val!r} 无法判定正负"})
            continue
        if side in ("left", "above") and sign == SIGN_POS and val not in ("0", "0.0"):
            issues.append(
                {
                    "code": "PHYS_POSITION_CONFLICT",
                    "level": "block",
                    "message": f"题图中 {oid} 在 {ref} 左侧（或上方），解析却用初始 x={val}（正方向同侧），图与推导冲突",
                }
            )
        if side in ("right", "below") and sign == SIGN_NEG:
            issues.append(
                {
                    "code": "PHYS_POSITION_CONFLICT",
                    "level": "block",
                    "message": f"题图中 {oid} 在 {ref} 右侧（或下方），解析却用初始 x={val}（负号），图与推导冲突",
                }
            )
    return issues


def check_sub_answers(rec: dict) -> list[dict]:
    issues = []
    subs = [s.get("label") for s in models.subquestions(rec) if s.get("label")]
    answers = {a.get("label") for a in models.get(rec, "solution.sub_answers", []) or [] if a.get("label")}
    answers |= {k for k, v in models.answer_items(rec).items() if (v or {}).get("answer")}
    answers |= {s.get("label") for s in models.subquestions(rec) if (s.get("answer") or "").strip()}
    mode = models.get(rec, "delivery.mode")
    missing = [s for s in subs if s not in answers]
    extra = [a for a in answers if a not in subs]
    if missing and mode in ("with_sourced_answers", "optional_explanations"):
        issues.append({"code": "PHYS_SUBANSWER_MISSING", "level": "block", "message": f"小问缺少对应解答：{missing}"})
    elif missing:
        issues.append(
            {
                "code": "PHYS_SUBANSWER_MISSING_DRAFT",
                "level": "info",
                "message": f"题目版未写自主解：缺 {missing}（允许，但不得宣称已核验答案）",
            }
        )
    if extra and not models.is_choice(rec):
        issues.append({"code": "PHYS_SUBANSWER_EXTRA", "level": "warn", "message": f"解答标签在小问中不存在：{extra}"})
    if not subs and not models.is_choice(rec):
        issues.append({"code": "PHYS_NO_SUBQUESTION", "level": "block", "message": "没有小问，无法逐问核对"})
    return issues


def check_comparison(rec: dict) -> list[dict]:
    issues = []
    cmp_ = models.get(rec, "solution.comparison", {}) or {}
    status = cmp_.get("status")
    mode = models.get(rec, "delivery.mode")
    if status not in models.COMPARISON_STATUS:
        issues.append({"code": "PHYS_COMPARISON_STATUS", "level": "block", "message": f"答案比较状态 {status!r} 无效"})
    if status in ("missing", None):
        level = "block" if mode == "with_sourced_answers" else "warn"
        issues.append(
            {
                "code": "PHYS_COMPARISON_MISSING",
                "level": level,
                "message": "无可信比较答案：题目版可交付但须明示未附答案，不得输出“答案已对照核验”",
            }
        )
    if status == "partial" and not cmp_.get("diff_notes"):
        issues.append({"code": "PHYS_COMPARISON_NOTES", "level": "warn", "message": "部分对照须写明差异说明"})
    claim_words = ("已对照", "全部核对", "答案已核验", "答案核对通过")
    text = " ".join(
        str(models.get(rec, "solution.comparison.diff_notes") or "").split()
    )
    if status != "compared":
        notes = []
        for sub in models.subquestions(rec):
            notes.append(str(sub.get("answer") or ""))
        notes.append(str(models.get(rec, "solution.comparison.diff_notes") or ""))
        joined = " ".join(notes)
        hit = [w for w in claim_words if w in joined]
        if hit:
            issues.append(
                {
                    "code": "PHYS_FALSE_CLAIM",
                    "level": "block",
                    "message": f"比较答案为 {status}，却出现“{hit}”表述，属虚假核验声明",
                }
            )
    return issues


def check_sympy(rec: dict) -> list[dict]:
    """solution.checks: [{stage, kind:"sympy", equation:"lhs=rhs", note}]"""
    issues = []
    checks = models.get(rec, "solution.checks", []) or []
    if not checks:
        issues.append({"code": "PHYS_NO_ALGEBRA_CHECK", "level": "info", "message": "没有代数/数值校验记录"})
        return issues
    try:
        import sympy as sp
    except Exception:
        issues.append({"code": "PHYS_SYMPY_UNAVAILABLE", "level": "warn", "message": "SymPy 不可用，跳过代数校验"})
        return issues
    for idx, chk in enumerate(checks, 1):
        eq = chk.get("equation")
        stage = chk.get("stage") or f"#{idx}"
        if not eq:
            issues.append({"code": "PHYS_CHECK_NO_EQUATION", "level": "warn", "message": f"校验 {stage} 没有方程"})
            continue
        if "=" not in eq:
            issues.append({"code": "PHYS_CHECK_FORMAT", "level": "warn", "message": f"校验 {stage} 方程 {eq!r} 不是 a=b 形式"})
            continue
        lhs, rhs = eq.split("=", 1)
        subs = chk.get("subs") or {}
        try:
            syms = {name: sp.Symbol(name) for name in subs}
            expr = sp.sympify(lhs) - sp.sympify(rhs)
            if subs:
                # 代入具体数值：适合“解出结果”的方程（v**2/180 - h = 0, subs={v:6,h:0.2}）
                values = {syms[name]: sp.sympify(str(val)) for name, val in subs.items()}
                residual = sp.simplify(expr.subs(values))
                is_zero = abs(complex(sp.N(residual))) < 1e-9
            else:
                residual = sp.simplify(expr)
                is_zero = residual == 0
        except Exception as exc:
            issues.append({"code": "PHYS_CHECK_PARSE", "level": "warn", "message": f"校验 {stage} 无法解析：{exc}"})
            continue
        if not is_zero:
            issues.append(
                {
                    "code": "PHYS_CHECK_RESIDUAL",
                    "level": "block",
                    "message": f"阶段 {stage} 的方程 {eq} 残差不为零（subs={subs}, 结果 = {residual}）",
                }
            )
        else:
            tag = "代入数值残差为零" if subs else "代数残差为零"
            issues.append({"code": "PHYS_CHECK_OK", "level": "info", "message": f"阶段 {stage} {tag}"})
    return issues


def check(rec: dict) -> list[dict]:
    return check_positions(rec) + check_sub_answers(rec) + check_comparison(rec) + check_sympy(rec)
