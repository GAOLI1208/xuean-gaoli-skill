"""doctor：只读自检，输出实际状态；--write 时落盘 environment.json。

不修改宿主环境，不装依赖，不改配置。
"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import paths

CST = timezone(timedelta(hours=8))


def _run(cmd, timeout=20):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (p.stdout or "").strip() or (p.stderr or "").strip()
    except Exception as exc:  # pragma: no cover - 环境相关
        return f"ERROR: {exc}"


def _lib_versions() -> dict:
    out = {}
    for name in ("typst", "pypdf", "pypdfium2", "pdfplumber", "PIL", "sympy"):
        try:
            mod = __import__(name)
            out[name] = {
                "status": "ok",
                "version": getattr(mod, "__version__", None)
                or getattr(mod, "VERSION", None)
                or "unknown",
            }
        except Exception as exc:
            out[name] = {"status": "fail", "error": type(exc).__name__ + ": " + str(exc)[:160]}
    return out


TYPST_SMOKE = r"""
#set page(width: 8cm, height: 4cm, margin: 6pt)
#set text(font: "Songti SC", size: 11.5pt)
中文自检：$v = v_0 + a t$，电阻 $R = U\/I$。
"""


def _typst_smoke() -> dict:
    try:
        import typst
    except Exception as exc:
        return {"status": "fail", "error": f"import: {exc}"}
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "smoke.typ"
        src.write_text(TYPST_SMOKE, encoding="utf-8")
        pdf = Path(td) / "smoke.pdf"
        try:
            typst.compile(
                str(src),
                output=str(pdf),
                font_paths=[str(p) for p in paths.FONT_DIRS if p.exists()],
            )
        except Exception as exc:
            return {"status": "fail", "error": f"compile: {str(exc)[:300]}"}
        if not pdf.exists() or pdf.stat().st_size == 0:
            return {"status": "fail", "error": "no output pdf"}
        try:
            from pypdf import PdfReader

            reader = PdfReader(str(pdf))
            page = reader.pages[0]
            fonts = set()
            for name, ref in (page.get("/Resources", {}).get("/Font", {}) or {}).items():
                fonts.add(str(ref.get_object().get("/BaseFont")))
            text = page.extract_text() or ""
        except Exception as exc:
            return {"status": "partial", "error": f"pdf read: {exc}"}
        return {
            "status": "ok" if ("中" in text and fonts) else "fail",
            "fonts": sorted(fonts),
            "text_ok": "中" in text,
            "bytes": pdf.stat().st_size,
        }


def _fonts() -> dict:
    info = {"songti_path": str(paths.SONGTI), "songti_exists": paths.SONGTI.exists()}
    dirs = [str(p) for p in paths.FONT_DIRS if p.exists()]
    info["font_dirs"] = dirs
    return info


def _app_version() -> str:
    import plistlib

    plist = Path(os.environ.get("DSH_APP_PLIST", "")).expanduser()
    if not str(plist) or not plist.exists():
        return "not-detected (standalone is OK)"
    try:
        with plist.open("rb") as fh:
            data = plistlib.load(fh)
        return data.get("CFBundleShortVersionString", "unknown")
    except Exception:
        return "unknown"


def _profile_state() -> dict:
    prof = paths.DESKTOP_PROFILE
    if prof is None:
        return {
            "dir": "", "exists": False, "package_json": False, "patch": False,
            "dep_count": 0, "has_search_tools": False, "dshmarket": None,
        }
    pkg = prof / "package.json"
    patch = prof / "cordis.patch.yml"
    deps = {}
    if pkg.exists():
        try:
            deps = json.loads(pkg.read_text(encoding="utf-8")).get("dependencies", {})
        except Exception:
            deps = {}
    return {
        "dir": str(prof),
        "exists": prof.exists(),
        "package_json": pkg.exists(),
        "patch": patch.exists(),
        "dep_count": len(deps),
        "has_search_tools": "dsh-search-tools" in deps,
        "dshmarket": deps.get("dshmarket", deps.get("@dshmarket/dshmarket")),
    }


def _optional_path(p, version: bool = False) -> dict:
    item = {"path": str(p) if p else "", "exists": bool(p and Path(p).exists())}
    if version and item["exists"]:
        item["version"] = _run([str(p), "-v"])
    return item


def collect() -> dict:
    env = {
        "generated_at": datetime.now(CST).isoformat(timespec="seconds"),
        "machine": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "macos": platform.mac_ver()[0],
        },
        "paths": {
            "lab_root": str(paths.LAB_ROOT),
            "workspace": str(paths.WORKSPACE),
            "host_python": _optional_path(paths.DSH_PYTHON),
            "lab_python": _optional_path(paths.LAB_PYTHON),
            "venv_python": _optional_path(paths.VENV_PYTHON),
            "node": _optional_path(paths.DSH_NODE, version=True),
            "dsh_cli": _optional_path(paths.DSH_CLI),
        },
        "runtime": {
            "python_executing": sys.executable,
            "python_version": sys.version.split()[0],
            "dsh_app_version": _app_version(),
        },
        "libs": _lib_versions(),
        "fonts": _fonts(),
        "typst_smoke": _typst_smoke(),
        "swift": _run(["xcrun", "--find", "swift"]) if Path("/usr/bin/xcrun").exists() else None,
        "profile": _profile_state(),
    }
    return env


def summary(env: dict) -> tuple[bool, list[str]]:
    lines = []
    ok = True
    lines.append(f"DSH 应用 {env['runtime']['dsh_app_version']} · macOS {env['machine']['macos']} · {env['machine']['machine']}")
    for key in ("lab_python", "host_python", "venv_python", "node"):
        item = env["paths"][key]
        state = "OK" if item["exists"] else ("未配置" if not item.get("path") else "缺失")
        if key == "lab_python":
            ok = ok and item["exists"]
        lines.append(f"  {key:12s} {state:4s} {item.get('path') or '-'}" + (f" ({item.get('version')})" if item.get("version") else ""))
    libs = env["libs"]
    lib_txt = ", ".join(
        f"{n} {'OK' if v['status']=='ok' else 'FAIL'}" for n, v in libs.items()
    )
    ok = ok and all(v["status"] == "ok" for v in libs.values())
    lines.append(f"  依赖         {lib_txt}")
    t = env["typst_smoke"]
    ok = ok and t["status"] == "ok"
    lines.append(f"  Typst 样页   {t['status']}" + (f" fonts={t.get('fonts')}" if t.get("fonts") else f" {t.get('error','')}"))
    lines.append(f"  中文字体     Songti.ttc {'存在' if env['fonts']['songti_exists'] else '缺失'}")
    lines.append(f"  Swift        {env['swift']}")
    prof = env["profile"]
    lines.append(
        f"  desktop 配置  patch={prof['patch']} deps={prof['dep_count']} "
        f"search-tools={'已装' if prof['has_search_tools'] else '未装'} dshmarket={prof['dshmarket']}"
    )
    return ok, lines


def main(write: bool = False) -> int:
    paths.ensure_dirs()
    env = collect()
    ok, lines = summary(env)
    print("\n".join(lines))
    if write:
        paths.DIRS["env"].write_text(
            json.dumps(env, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(f"\n已写入 {paths.rel(paths.DIRS['env'])}")
    print("\n结论：" + ("环境可用" if ok else "环境有缺口，见上"))
    return 0 if ok else 1
