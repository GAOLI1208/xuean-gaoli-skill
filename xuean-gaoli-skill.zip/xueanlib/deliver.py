"""版本化交付：只对“当前已审计过的文件”复制，并复读哈希确认。

文件名带内容哈希前缀与时间戳，避免覆盖同名文件。
"""

from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import fingerprint, paths

CST = timezone(timedelta(hours=8))


def _audit_matches(pdf: Path) -> tuple[Path | None, str]:
    """找一条“审计记录里保存的不可变摘要”与当前文件完全一致的记录。

    第 1 轮缺陷：拿当前文件与自身比较，同路径原地改动仍能匹配。
    现在只认审计时写入的 pdf_sha256/bytes/page_count，且三者都必须与当前文件一致。
    """
    from pypdf import PdfReader

    pdf = Path(pdf).resolve()
    cur_sha = fingerprint.sha256_file(pdf)
    cur_bytes = pdf.stat().st_size
    cur_pages = len(PdfReader(str(pdf)).pages)
    runs = paths.LAB_ROOT / "runs"
    if not runs.exists():
        return None, "没有 runs 目录"
    reasons = []
    for audit_file in sorted(runs.rglob("audit.json")):
        try:
            data = json.loads(audit_file.read_text(encoding="utf-8"))
        except Exception:
            reasons.append(f"{audit_file}: 无法解析")
            continue
        recorded_sha = data.get("pdf_sha256")
        if not recorded_sha:
            reasons.append(f"{audit_file}: 旧版审计记录无不可变摘要")
            continue
        if Path(data.get("pdf", "")).resolve() != pdf:
            continue
        if recorded_sha != cur_sha:
            reasons.append(f"{audit_file}: 记录摘要 {recorded_sha[:12]}… ≠ 当前 {cur_sha[:12]}…")
            continue
        if data.get("bytes") != cur_bytes or data.get("page_count") != cur_pages:
            reasons.append(f"{audit_file}: 大小/页数与记录不符")
            continue
        return audit_file, ""
    return None, "；".join(reasons[-3:]) or "无匹配审计记录"


def main(args) -> int:
    pdf = Path(args.pdf)
    if not pdf.exists():
        print(f"文件不存在：{pdf}", file=sys.stderr)
        return 2
    audit_file, why = _audit_matches(pdf)
    if audit_file is None:
        print(f"拒绝交付：该文件没有对应且未失效的审计记录（{why}）", file=sys.stderr)
        print("  同路径原地改动、重新导出、页面替换都会使旧审计失效；先重跑 audit。", file=sys.stderr)
        return 1
    audit = json.loads(audit_file.read_text(encoding="utf-8"))
    if not (audit.get("body_ok") and audit.get("fonts_embedded")) or any(not p["a4"] for p in audit["pages"]):
        print("拒绝交付：审计记录显示机器检查不合格", file=sys.stderr)
        return 1

    # 逐页目视必须绑定同一 PDF 哈希，否则只有机器检查不算验收。
    # run 由审计记录所在目录推出，不能靠调用方“记得加 --run”；
    # 显式传了 --run 但与审计来源不符，说明拿错了记录，直接拒绝。
    from pypdf import PdfReader as _PR
    from . import visual

    runs_root = paths.LAB_ROOT / "runs"
    audit_run = str(audit_file.parent.relative_to(runs_root))
    if args.run and args.run != audit_run:
        print(
            f"拒绝交付：审计记录来自 run “{audit_run}”，与指定的 --run “{args.run}” 不一致；"
            "换 PDF 或换 run 后必须重新 audit。",
            file=sys.stderr,
        )
        return 1
    run_id = args.run or audit_run
    page_total = len(_PR(str(pdf)).pages)
    vis = visual.status(pdf, run_id, page_total)
    if not vis["ok"]:
        why_pages = "、".join(str(x) for x in vis["missing_pages"]) or "—"
        print(
            f"拒绝交付：run “{run_id}” 的逐页目视未覆盖当前 PDF（已覆盖 {vis['covered']}/{page_total}，"
            f"缺页 {why_pages}；记录哈希 {str(vis['recorded_sha256'])[:12]}… 与当前 {vis['sha256'][:12]}…）",
            file=sys.stderr,
        )
        print("  先运行 visual 逐页记录，再 deliver；未传 --run 时按审计所在 run 查找。", file=sys.stderr)
        return 1

    sha = fingerprint.sha256_file(pdf)
    dest_dir = Path(args.dest)
    dest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(CST).strftime("%Y%m%d-%H%M%S")
    dest = dest_dir / f"{pdf.stem}_{stamp}_{sha[:8]}.pdf"
    shutil.copy2(pdf, dest)

    # 复读确认
    from pypdf import PdfReader

    src_pages = len(PdfReader(str(pdf)).pages)
    dst_pages = len(PdfReader(str(dest)).pages)
    dst_sha = fingerprint.sha256_file(dest)
    ok = dst_sha == sha and dst_pages == src_pages
    record = {
        "at": datetime.now(CST).isoformat(timespec="seconds"),
        "source": str(pdf),
        "dest": str(dest),
        "sha256": sha,
        "pages": dst_pages,
        "audit": str(audit_file),
        "run": run_id,
        "visual_pages": vis["covered"],
        "verified": ok,
    }
    # 第7轮修复：run_id 是从审计记录推导的；省略 --run 时也必须落交付日志。
    rd = paths.run_dir(run_id)
    (rd / "deliver.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"已交付：{dest}")
    print(f"  页面 {dst_pages}，哈希 {dst_sha[:16]}… {'一致' if ok else '不一致'}")
    print(f"  审计记录：{paths.rel(audit_file)}")
    return 0 if ok else 1
