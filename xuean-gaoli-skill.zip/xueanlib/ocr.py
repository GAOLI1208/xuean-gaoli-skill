"""本地 OCR：Apple Vision 稳定入口 + 按内容哈希与设置缓存。

只做文字识别；公式只当草稿，电路/轨道等图形关系仍需视觉读图。
缓存键 = 图片 sha256 + 引擎 + 识别级别 + 语言 + 最大行数。
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from . import paths

SWIFT_SRC = paths.LAB_ROOT / "scripts" / "vision_ocr.swift"
BIN = paths.LAB_ROOT / ".cache" / "bin" / "vision_ocr"
CACHE = paths.LAB_ROOT / ".cache" / "ocr"


def available() -> bool:
    return (
        Path("/usr/bin/xcrun").exists()
        and SWIFT_SRC.exists()
        and subprocess.run(["xcrun", "--find", "swift"], capture_output=True).returncode == 0
    )


def ensure_binary(rebuild: bool = False) -> Path:
    BIN.parent.mkdir(parents=True, exist_ok=True)
    if BIN.exists() and not rebuild and BIN.stat().st_mtime >= SWIFT_SRC.stat().st_mtime:
        return BIN
    cmd = ["xcrun", "swiftc", "-O", str(SWIFT_SRC), "-o", str(BIN)]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"Swift 编译失败：{proc.stderr.strip()[:600]}")
    return BIN


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_key(p: Path, fast: bool, lang: str | None) -> str:
    raw = f"{_sha256(p)}|vision|{int(fast)}|{lang or 'auto'}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def run(image, fast: bool = False, lang: str | None = None, max_lines: int = 400) -> dict:
    img = Path(image)
    if not img.exists():
        raise FileNotFoundError(img)
    CACHE.mkdir(parents=True, exist_ok=True)
    key = _cache_key(img, fast, lang)
    cache_file = CACHE / f"{key}.json"
    if cache_file.exists():
        data = json.loads(cache_file.read_text(encoding="utf-8"))
        data["cache_hit"] = True
        data["cache_key"] = key
        return data

    binary = ensure_binary()
    cmd = [str(binary), str(img), "--max-lines", str(max_lines)]
    if fast:
        cmd.append("--fast")
    if lang:
        cmd += ["--lang", lang]
    started = time.time()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    elapsed = time.time() - started
    if proc.returncode != 0:
        raise RuntimeError(f"OCR 失败：{proc.stdout.strip()[:300]} {proc.stderr.strip()[:300]}")
    data = json.loads(proc.stdout)
    data["cache_hit"] = False
    data["cache_key"] = key
    data["wall_ms"] = int(elapsed * 1000)
    data["image_sha256"] = _sha256(img)
    data["image_rel"] = paths.rel(img)
    low_conf = [ln for ln in data.get("lines", []) if ln.get("confidence", 1) < 0.5]
    data["uncertain_lines"] = len(low_conf)
    cache_file.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return data


def main(args) -> int:
    try:
        data = run(args.image, fast=args.fast, lang=args.lang)
    except Exception as exc:
        print(f"OCR 失败：{exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    print(f"引擎 {data['engine']}  语言 {'/'.join(data['languages'])}  {data['width']}x{data['height']}")
    print(f"缓存 {'命中' if data['cache_hit'] else '未命中'}  {data.get('elapsed_ms', 0)} ms  {len(data['lines'])} 行  低置信 {data['uncertain_lines']} 行")
    if data.get("truncated"):
        print("注意：结果被截断（超过 max-lines），不是完整识别")
    for ln in data["lines"]:
        print(f"  [{ln['confidence']:.2f}] {ln['text']}")
    return 0
