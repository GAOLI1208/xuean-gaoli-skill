"""汇总一次 run 的准入/生成/审计/目视/交付记录，供报告直接引用。"""

from __future__ import annotations

import json
from pathlib import Path

from . import paths


def main(args) -> int:
    run_id = args.run
    if not run_id:
        runs = sorted([p for p in (paths.LAB_ROOT / "runs").iterdir() if p.is_dir()])
        if not runs:
            print("没有 run 记录")
            return 1
        run_id = runs[-1].name
    rd = paths.run_dir(run_id)
    print(f"run {run_id}")
    for name in ("validate.json", "build.json", "audit.json", "visual-review.json", "deliver.json"):
        p = rd / name
        if not p.exists():
            print(f"  {name:<22} 缺失")
            continue
        data = json.loads(p.read_text(encoding="utf-8"))
        if name == "validate.json":
            s = data["summary"]
            print(f"  {name:<22} 阻断 {len(s['blocks'])} · 警告 {len(s['warns'])} · admissible={s['admissible']}")
        elif name == "build.json":
            print(f"  {name:<22} {Path(data['pdf']).name}  {data['seconds']}s  draft={data['draft']}")
        elif name == "audit.json":
            print(f"  {name:<22} {data['page_count']} 页  正文 {data['body_pt_mode']}pt  字体嵌入={data['fonts_embedded']}")
        elif name == "visual-review.json":
            print(f"  {name:<22} 覆盖 {len(data.get('pages', {}))}/{data.get('page_count')} 页  sha={str(data.get('sha256'))[:12]}")
        else:
            print(f"  {name:<22} {Path(data['dest']).name}  verified={data['verified']}")
    return 0
