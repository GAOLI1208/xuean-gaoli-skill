"""题源/题面/题图/答案/审核准入校验。

输出分级问题：block（阻止正式生成）、warn（可进草稿并显示缺口）、info。
退出码：有 block 且未 --allow-draft → 1。
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from . import answers, fingerprint, models, paths, physics, provenance, svgcheck

REQUIRED_KEYS = ("layout", "objects", "labels")


def _issue(code, level, message, spec="", field=""):
    return {"code": code, "level": level, "message": message, "spec": spec, "field": field}


def _resolve(p) -> Path | None:
    if not p:
        return None
    path = Path(p)
    return path if path.is_absolute() else paths.LAB_ROOT / path


def _is_http_url(u) -> bool:
    return str(u or "").startswith(("http://", "https://"))


def _check_fetch(label: str, fetch, local_path, local_sha: str, url: str) -> list[dict]:
    out = []
    if not isinstance(fetch, dict) or fetch.get("error"):
        out.append(_issue("SRC_FETCH_META_MISSING", "block",
                          f"{label}为网络来源，但缺 fetch metadata（最终URL/状态/hash）", "§5.2",
                          f"{label}.fetch"))
        return out
    status = fetch.get("status")
    if status not in (200, "200"):
        out.append(_issue("SRC_FETCH_STATUS", "block",
                          f"{label} fetch 状态 {status!r}，不是 200；不得当已取得", "§5.2", f"{label}.fetch.status"))
    final = str(fetch.get("final_url") or "").strip()
    if not _is_http_url(final):
        out.append(_issue("SRC_FETCH_FINAL_URL", "block",
                          f"{label} fetch 没有可核的最终 URL", "§5.2", f"{label}.fetch.final_url"))
    sha = str(fetch.get("sha256") or "").strip()
    if not local_sha:
        out.append(_issue("SRC_FETCH_LOCAL_HASH", "block",
                          f"{label} fetch 未绑定本地原始文件 hash", "§5.2", f"{label}.fetch.local_sha256"))
    if not sha or (local_sha and sha != local_sha):
        out.append(_issue("SRC_FETCH_HASH", "block",
                          f"{label} fetch hash 与原始文件/hash 不符（或缺失）", "§5.2", f"{label}.fetch.sha256"))
    req = str(fetch.get("requested_url") or "").strip()
    if not _is_http_url(req):
        out.append(_issue("SRC_FETCH_REQUESTED_URL", "block",
                          f"{label} fetch 缺可核的 requested_url（不能用同一文件/hash 冒充别次抓取）", "§5.2",
                          f"{label}.fetch.requested_url"))
        return out
    if not url:
        out.append(_issue("SRC_FETCH_URL_MISSING", "block",
                          f"{label} 有 fetch meta 但没有记录来源 URL", "§5.2", f"{label}.url"))
        return out
    # 同一个文件/hash 不算同一次抓取：记录 URL 必须等于 requested_url，
    # 或等于有记录的 final_url（合法重定向）。两个都不是就是借文件冒充。
    chain = {req, final}
    if url not in chain:
        out.append(_issue("SRC_FETCH_URL_MISMATCH", "block",
                          f"{label} 记录 URL 不在本次 fetch 的 requested/final URL 中；不得借同一文件/hash冒充原件",
                          "§5.2", f"{label}.url"))
    elif req != final:
        out.append(_issue("SRC_FETCH_REDIRECT", "info",
                          f"{label} 记录 URL 属于有记录的合法重定向（requested != final）", "§5.2",
                          f"{label}.fetch.final_url"))
    return out


def check_source(rec: dict) -> list[dict]:
    out = []
    ident = models.get(rec, "identity", {}) or {}
    src = models.get(rec, "source", {}) or {}
    for key in ("region", "exam_name", "exam_type", "original_number"):
        if ident.get(key) in (None, "", []):
            out.append(_issue("SRC_IDENTITY_MISSING", "block", f"身份字段缺失：{key}", "§5.1", f"identity.{key}"))
    if ident.get("exam_year") in (None, "") and not str(ident.get("exam_year_label") or "").strip():
        out.append(_issue("SRC_YEAR_MISSING", "block", "年份未知时必须明确写 exam_year_label（如“2023/2024学年”或“未标”），不得默认填 2024", "§5.2", "identity.exam_year_label"))
    if ident.get("exam_year") not in (None, "") and not isinstance(ident.get("exam_year"), int):
        out.append(_issue("SRC_YEAR_TYPE", "block", "exam_year 只能是整数；学年/未知请写 exam_year_label", "§5.2", "identity.exam_year"))
    if isinstance(ident.get("exam_year"), int) and not str(ident.get("year_evidence") or "").strip():
        out.append(_issue("SRC_YEAR_UNTRACED", "warn", "年份是整数但未记录 year_evidence；需能回查原页声明", "§5.2", "identity.year_evidence"))
    if str(ident.get("region") or "").strip() in ("未标", "未标（试卷未印地区）", "未知", "unknown"):
        out.append(_issue("SRC_REGION_UNKNOWN", "warn", "地区未标；如教师把地区设硬条件，候选不得选中", "§5.2", "identity.region"))

    def _locator(u) -> bool:
        s = str(u or "").strip()
        if s.startswith(("http://", "https://", "file://")):
            return True
        if not s:
            return False
        p = Path(s)
        if not p.is_absolute():
            p = paths.LAB_ROOT / p
        return p.exists()

    urls = [u for u in (src.get("urls") or []) if _locator(u)]
    local_files = [x for x in (src.get("local_files") or []) if isinstance(x, dict) and _locator(x.get("path"))]
    if not urls and not local_files:
        out.append(_issue("SRC_NO_URL", "block", "没有可定位的具体来源 URL 或本地来源文件", "§5.2", "source.urls|source.local_files"))

    ptype = src.get("publication_type")
    if ptype not in models.PUBLICATION_TYPES:
        out.append(_issue("SRC_PUBLICATION_TYPE", "block", f"资料性质未标（第一方/完整转载/汇编），当前 {ptype!r}", "§5.2", "source.publication_type"))

    dom = src.get("dom") or {}
    role = str(src.get("origin_role") or "")
    if role in ("derived", "model_excerpt", "transcription"):
        orig = src.get("original") or {}
        if not orig.get("path") or not orig.get("sha256") or not orig.get("dom"):
            out.append(_issue("SRC_DERIVED_UNVERIFIED", "block",
                              "派生摘录未链回原始文件/hash/DOM；不得自证完整", "§5.2", "source.original"))
        else:
            op = _resolve(orig.get("path"))
            if not op or not op.exists():
                out.append(_issue("SRC_ORIGINAL_MISSING", "block",
                                  f"派生摘录链回的原文件不存在：{orig.get('path')}", "§5.2", "source.original.path"))
            elif fingerprint.sha256_file(op) != orig.get("sha256"):
                out.append(_issue("SRC_ORIGINAL_HASH", "block",
                                  "派生摘录链回的原文件哈希不符（原文件被换过）", "§5.2", "source.original.sha256"))
            odom = orig.get("dom") or {}
            declared = odom.get("declared_images")
            accounted = len(models.figures(rec)) + len(models.answer_block(rec).get("figures") or []) + len(models.get(rec, "problem.figure_failures") or [])
            if isinstance(declared, int) and declared > accounted:
                out.append(_issue("SRC_DERIVED_IMAGE_LOSS", "block",
                                  f"原始 DOM 声明 {declared} 个图，派生记录只交待 {accounted} 个（含失败）；缺图不得自证完整",
                                  "§5.2", "source.original.dom.declared_images"))
            if (src.get("evidence") or [{}])[0].get("path") == (src.get("derived") or {}).get("path"):
                out.append(_issue("SRC_DERIVED_EVIDENCE", "block",
                                  "来源证据优先指向派生摘录而不是原文件；不能把摘录当原件", "§5.2", "source.evidence"))
    elif role == "original" and not dom:
        out.append(_issue("SRC_DOM_UNRECORDED", "warn", "原始导入未记录 DOM 图文声明统计", "§5.2", "source.dom"))
    elif role in ("", "unknown") and dom and dom.get("kind") not in ("pdf", "scan"):
        out.append(_issue("SRC_ORIGIN_UNKNOWN", "block",
                          "新 HTML 未声明 original/derived；unknown 不得正式放行", "§5.2", "source.origin_role"))

    if dom and dom.get("kind") not in ("pdf", "scan"):
        sc = int(dom.get("scope_count") or 0)
        if sc == 0:
            out.append(_issue("SRC_SCOPE_MISSING", "block",
                              "题目主块 selector 命中 0 个块；不能把空 DOM 当有效原页", "§5.2", "source.dom.scope_count"))
        elif sc > 1:
            out.append(_issue("SRC_SCOPE_AMBIGUOUS", "block",
                              f"题目主块 selector 命中 {sc} 个块；不能把多题当一题", "§5.2", "source.dom.scope_count"))
        declared = dom.get("declared_images")
        accounted = len(models.figures(rec)) + len(models.answer_block(rec).get("figures") or []) + len(models.get(rec, "problem.figure_failures") or [])
        if isinstance(declared, int) and declared > accounted:
            out.append(_issue("SRC_DOM_IMAGES_UNACCOUNTED", "block",
                              f"DOM 声明 {declared} 个 img，记录只交待 {accounted} 个（含失败）；不得静默丢图", "§5.2", "source.dom.declared_images"))
    if role in ("derived", "model_excerpt", "transcription"):
        odom = (src.get("original") or {}).get("dom") or {}
        osc = int(odom.get("scope_count") or 0)
        if osc != 1:
            out.append(_issue("SRC_ORIGINAL_SCOPE", "block",
                              f"原件题块 selector 必须唯一有效，当前命中 {osc} 个；派生摘录不能自证", "§5.2",
                              "source.original.dom.scope_count"))
        ourl = str((src.get("original") or {}).get("url") or "")
        if _is_http_url(ourl):
            out.extend(_check_fetch("source.original", (src.get("original") or {}).get("fetch"),
                                    (src.get("original") or {}).get("path"),
                                    str((src.get("original") or {}).get("sha256") or ""), ourl))
        elif (src.get("original") or {}).get("fetch"):
            out.append(_issue("SRC_FETCH_URL_MISSING", "block",
                              "source.original 有 fetch meta 但没有 http(s) 来源 URL", "§5.2",
                              "source.original.url"))
    if role == "original":
        url0 = next((u for u in (src.get("urls") or []) if _is_http_url(u)), "")
        if url0:
            local = (src.get("local_files") or [{}])[0]
            out.extend(_check_fetch("source", src.get("fetch"), local.get("path"),
                                    str(local.get("sha256") or ""), url0))
        elif src.get("fetch"):
            out.append(_issue("SRC_FETCH_URL_MISSING", "block",
                              "source 有 fetch meta 但没有 http(s) 来源 URL", "§5.2", "source.urls"))
    mt = str(src.get("material_type") or "unknown")
    if mt not in ("exam", "homework", "question_bank", "textbook", "unknown"):
        out.append(_issue("SRC_MATERIAL_TYPE", "block", f"来源性质 {mt!r} 非法", "§5.2", "source.material_type"))
    elif mt == "unknown":
        out.append(_issue("SRC_MATERIAL_TYPE_UNKNOWN", "warn", "来源性质未知；不得用“真实考试题”页头", "§5.2", "source.material_type"))

    ev = src.get("evidence") or []
    if not ev:
        out.append(_issue("SRC_NO_EVIDENCE", "block", "没有证据文件，来源无法定位到具体题", "§5.2", "source.evidence"))
    for i, item in enumerate(ev):
        p = _resolve(item.get("path"))
        field = f"source.evidence[{i}]"
        if not p or not p.exists():
            out.append(_issue("SRC_EVIDENCE_MISSING_FILE", "block", f"证据文件不存在：{item.get('path')}", "§5.2", field))
            continue
        actual = fingerprint.sha256_file(p)
        if item.get("sha256") and item["sha256"] != actual:
            out.append(_issue("SRC_EVIDENCE_HASH", "block", f"证据文件哈希不符：{item.get('path')}", "§5.2", field))
        if not item.get("page") and not item.get("selector"):
            out.append(_issue("SRC_EVIDENCE_LOCATE", "block", "证据未给出页码或题号选择器，不能定位到具体题", "§5.2", field))
    if ev and not urls and not local_files:
        out.append(_issue("SRC_EVIDENCE_NO_URL", "block", "有证据文件但没有来源 URL/本地文件", "§5.2"))

    if ptype == "汇编":
        independent = [e for e in ev if e.get("independence") == "first_party"]
        if src.get("status") == "通过" and not independent:
            out.append(
                _issue(
                    "SRC_COMPILATION_ONLY",
                    "block",
                    "只有汇编标签、没有第一方或可信转载证据，不得记为“通过”",
                    "§5.2",
                    "source.status",
                )
            )
        if src.get("status") != "通过":
            out.append(_issue("SRC_STATUS_PENDING", "warn", f"资料为汇编且状态为 {src.get('status')}，题源待核", "§5.2", "source.status"))

    bn = ident.get("booklet_number")
    on = ident.get("original_number")
    if bn and on and str(bn) == str(on) and ptype == "汇编":
        out.append(_issue("SRC_NUMBER_CONFUSED", "warn", "汇编编号与原卷题号相同，需确认不是把汇编编号当原卷题号", "§5.2", "identity.original_number"))

    if ident.get("exam_year") and isinstance(ident.get("exam_year"), int):
        year = ident["exam_year"]
        retrieved = src.get("retrieved_at")
        if not retrieved:
            out.append(_issue("SRC_NO_RETRIEVED_AT", "block", "未记录下载/取得时间", "§5.2", "source.retrieved_at"))
        else:
            try:
                ry = datetime.fromisoformat(str(retrieved).replace("Z", "+00:00")).year
                if ry < year:
                    out.append(_issue("SRC_TIME_CONFLICT", "block", "取得时间早于考试年份，时间线冲突", "§5.2", "source.retrieved_at"))
            except ValueError:
                out.append(_issue("SRC_RETRIEVED_AT_FORMAT", "warn", "取得时间不是 ISO 8601", "§5.2", "source.retrieved_at"))

    upstream = src.get("upstream") or []
    if isinstance(upstream, list) and len(upstream) > 1:
        out.append(_issue("SRC_NOT_INDEPENDENT", "warn", f"多个来源共享上游 {upstream}，不算独立证据", "§5.2", "source.upstream"))

    # 题源状态是硬门槛：只有显式“通过”才允许正式编排。
    raw_status = src.get("status")
    status = str(raw_status).strip() if raw_status is not None else ""
    if status not in models.SOURCE_STATUS:
        out.append(
            _issue(
                "SRC_STATUS_UNKNOWN",
                "block",
                f"题源状态 {raw_status!r} 不在白名单（线索/待核实/通过/受限/冲突），未知状态不得正式准入",
                "§5.2",
                "source.status",
            )
        )
    elif status != models.SOURCE_STATUS_PASS:
        out.append(
            _issue(
                "SRC_STATUS_NOT_PASS",
                "block",
                f"题源状态为“{status}”，未核实不得正式编排（只能预览 DRAFT 并显示缺口）",
                "§5.2",
                "source.status",
            )
        )
    else:
        ev_first_party = any(e.get("independence") == "first_party" for e in ev)
        if ptype == "完整转载" and not ev_first_party:
            out.append(
                _issue(
                    "SRC_REPRINT_NO_TRACE",
                    "warn",
                    "完整转载但证据未标明独立性，核实结论仍需人工确认原卷特征",
                    "§5.2",
                    "source.evidence",
                )
            )
    return out


def check_problem(rec: dict) -> list[dict]:
    out = []
    prob = models.get(rec, "problem", {}) or {}
    stem = (prob.get("stem") or "").strip()
    if not stem:
        out.append(_issue("TXT_NO_STEM", "block", "题干为空", "§5.1", "problem.stem"))
    for msg in models.body_markup(stem):
        out.append(_issue("TXT_LATEX_RESIDUE", "block", msg, "§9.1", "problem.stem"))
    claim_text = stem + "\n" + "\n".join(str((x or {}).get("text") or "") for x in (prob.get("subquestions") or []))
    claims = prob.get("figure_claims") or provenance.figure_claims(claim_text)
    if claims and not models.figures(rec):
        out.append(_issue("FIG_CLAIMED_MISSING", "block",
                          f"题干声明依赖图/图线/坐标系（{claims[0]}），但记录没有题图；expected=false 不能算完成",
                          "§5.3", "problem.figure_claims"))
    opts = prob.get("options") or []
    if opts and len(opts) < 2:
        out.append(_issue("TXT_OPTIONS_TOO_FEW", "block", "选择题选项少于 2 个", "§5.1", "problem.options"))
    subs = prob.get("subquestions") or []
    if not subs and not opts:
        out.append(_issue("TXT_NO_SUBQUESTION", "block", "既没有小问也没有选项，无法逐问核对", "§6.1", "problem.subquestions"))
    labels = []
    for i, sub in enumerate(subs):
        lbl = (sub.get("label") or "").strip()
        if not lbl:
            out.append(_issue("TXT_SUB_NO_LABEL", "block", f"第 {i+1} 小问缺标签", "§5.1", f"problem.subquestions[{i}]"))
        elif lbl in labels:
            out.append(_issue("TXT_SUB_DUP_LABEL", "block", f"小问标签重复：{lbl}", "§5.1", f"problem.subquestions[{i}]"))
        labels.append(lbl)
        if not (sub.get("text") or "").strip():
            out.append(_issue("TXT_SUB_NO_TEXT", "block", f"小问 {lbl} 题面为空", "§5.1", f"problem.subquestions[{i}]"))
        for msg in models.body_markup(sub.get("text") or ""):
            out.append(_issue("TXT_LATEX_RESIDUE", "block", msg, "§9.1", f"problem.subquestions[{i}].text"))

    # 完整性声明：原题有图/有定数选项时必须逐项对上，否则“缺图/漏选项”会静默通过。
    expected = prob.get("expected") or {}
    if expected:
        if expected.get("figure") and not models.figure(rec):
            out.append(_issue("TXT_FIGURE_MISSING", "block", "原题声明有图，但记录中没有题图", "§5.3", "problem.expected.figure"))
        want = expected.get("option_count")
        if isinstance(want, int) and len(opts) != want:
            out.append(
                _issue("TXT_OPTIONS_MISSING", "block", f"原题 {want} 个选项，实际 {len(opts)} 个（漏选项不得静默通过）", "§5.1", "problem.options")
            )
        want_subs = expected.get("subquestion_count")
        if isinstance(want_subs, int) and len(subs) != want_subs:
            out.append(
                _issue(
                    "TXT_SUBQUESTIONS_MISSING",
                    "block",
                    f"原题 {want_subs} 个小问，实际 {len(subs)} 个（漏小问不得静默通过）",
                    "§5.1",
                    "problem.subquestions",
                )
            )
        if expected.get("figure") and models.figure(rec):
            ev = (models.figure(rec) or {}).get("evidence_path")
            if not ev:
                out.append(_issue("TXT_FIGURE_NO_EVIDENCE", "block", "原题图缺原图证据", "§5.3", "problem.figure.evidence_path"))

    unresolved = prob.get("unresolved_chars") or []
    if unresolved:
        out.append(
            _issue(
                "TXT_UNRESOLVED_CHARS",
                "block",
                f"存在未能认读的字/公式 {unresolved}，不得猜题进入正式成品",
                "§5.4",
                "problem.unresolved_chars",
            )
        )
    return out


def _check_one_figure(rec: dict, fig: dict, idx: int) -> list[dict]:
    out = []
    pre = f"problem.figures[{idx}]" if len(models.figures(rec)) > 1 else "problem.figure"
    if fig.get("role") not in ("原题图", "解析辅助图", "选项图"):
        out.append(_issue("FIG_ROLE", "block", f"题图 {idx+1} 未标注“原题图/解析辅助图/选项图”", "§5.3", f"{pre}.role"))
    rel = fig.get("relations") or {}
    for key in REQUIRED_KEYS:
        if key not in rel:
            out.append(_issue("FIG_RELATIONS_MISSING", "block", f"题图 {idx+1} 缺图形关系清单字段：{key}", "§5.3", f"{pre}.relations.{key}"))
    if "open_issues" not in rel:
        out.append(_issue("FIG_OPEN_ISSUES", "warn", f"题图 {idx+1} 未记录未决问题清单（open_issues）", "§5.3", f"{pre}.relations.open_issues"))

    ev_path = _resolve(fig.get("evidence_path"))
    if fig.get("role") == "原题图":
        if not ev_path or not ev_path.exists():
            out.append(_issue("FIG_EVIDENCE", "block", f"题图 {idx+1} 缺少原图证据文件", "§5.3", f"{pre}.evidence_path"))

    # 优先直接使用“原图/原卷精确图形区域”（asset_path），不强制矢量化重绘。
    asset = _resolve(fig.get("asset_path"))
    svg_path = _resolve(fig.get("svg_path"))
    if asset:
        if not asset.exists():
            out.append(_issue("FIG_ASSET_MISSING", "block", f"题图 {idx+1} 资产不存在：{fig.get('asset_path')}", "§5.3", f"{pre}.asset_path"))
        else:
            want = fig.get("asset_sha256")
            if want and fingerprint.sha256_file(asset) != want:
                out.append(_issue("FIG_ASSET_HASH", "block", f"题图 {idx+1} 资产哈希与该记录不符（图被换过）", "§5.3", f"{pre}.asset_sha256"))
            if asset.stat().st_size < 1500:
                out.append(_issue("FIG_ASSET_TINY", "warn", f"题图 {idx+1} 资产仅 {asset.stat().st_size} 字节，疑为占位图", "§5.3", f"{pre}.asset_path"))
            crop = fig.get("asset_crop") or {}
            if crop:
                for k in ("source_sha256", "box_normalized"):
                    if not crop.get(k):
                        out.append(_issue("FIG_CROP_INCOMPLETE", "block", f"题图 {idx+1} 裁切记录缺 {k}，无法复核题目图取自何处", "§5.3", f"{pre}.asset_crop"))
            elif fig.get("role") == "原题图":
                out.append(_issue("FIG_CROP_NO_RECORD", "warn", f"题图 {idx+1} 直接使用原图但没记录裁切来源", "§5.3", f"{pre}.asset_crop"))
    if not asset and not svg_path:
        out.append(_issue("FIG_NO_ASSET", "block", f"题图 {idx+1} 既无原图区域资产也无重绘 SVG", "§5.3", pre))
        return out
    if not svg_path:
        if not (fig.get("source_note") or rel.get("redraw_note")):
            out.append(_issue("FIG_SOURCE_NOTE", "warn", f"题图 {idx+1} 直接使用原图但未说明来源/是否重绘", "§5.3", f"{pre}.source_note"))
        return out
    if not svg_path.exists():
        out.append(_issue("FIG_SVG_MISSING", "block", f"题图 {idx+1} 重绘 SVG 不存在", "§5.3", f"{pre}.svg_path"))
        return out
    if not rel.get("redraw_note"):
        out.append(_issue("FIG_REDRAW_NOTE", "block", f"题图 {idx+1} 重绘图未标注“据原题重绘”", "§5.3", f"{pre}.relations.redraw_note"))

    res = svgcheck.check(
        svg_path,
        expected_labels=rel.get("labels") or [],
        expected_times=rel.get("time_labels") or [],
        constraints=rel.get("constraints") or [],
    )
    for item in res["issues"]:
        out.append(_issue(item["code"], item["level"], f"题图 {idx+1}：{item['message']}", "§5.3", pre))
    if res["meta"].get("extra_texts"):
        out.append(
            _issue(
                "FIG_UNDECLARED_LABELS",
                "warn",
                f"题图 {idx+1} 存在未声明的标注：{res['meta']['extra_texts']}，需确认属于原图",
                "§5.3",
                f"{pre}.relations.labels",
            )
        )
    return out


def check_figure(rec: dict) -> list[dict]:
    out = []
    figs = models.figures(rec)
    failures = models.get(rec, "problem.figure_failures") or []
    for i, fail in enumerate(failures):
        out.append(_issue("FIG_DOWNLOAD_FAILED", "block",
                          f"题图/答案图下载或解码失败：{fail.get('figure_no') or fail.get('src')}（{fail.get('reason')}）",
                          "§5.3", f"problem.figure_failures[{i}]"))
    expected_count = models.get(rec, "problem.expected.figure_count")
    if isinstance(expected_count, int) and expected_count > len(figs):
        out.append(_issue("FIG_COUNT_MISSING", "block",
                          f"原题声明/页面有 {expected_count} 个图，记录只有 {len(figs)} 个；缺图不得静默通过",
                          "§5.3", "problem.figures"))
    for i, fig in enumerate(figs):
        out.extend(_check_one_figure(rec, fig, i))
    return out


REVIEW_STATE_CODES = {
    "missing": ("REV_MISSING", "未记录审核"),
    "rejected": ("REV_REJECTED", "审核未通过"),
    "pending": ("REV_PENDING", "审核待完成"),
    "unknown": ("REV_UNKNOWN", "审核状态非法/未知"),
    "stale": ("REV_STALE", "内容变化后审核已失效，须重检"),
}


def check_review(rec: dict) -> list[dict]:
    out = []
    states = fingerprint.review_state(rec)
    applicable = models.applicable_reviews(rec)
    for name, st in states.items():
        if name not in applicable:
            continue
        if st["state"] == "ok":
            continue
        code, label = REVIEW_STATE_CODES[st["state"]]
        out.append(_issue(code, "block", f"{label}：审核项 {name}（{st.get('detail')}）", "§5.4", f"review.{name}"))
    return out


def delivery_mode(rec: dict) -> str:
    mode = models.get(rec, "delivery.mode")
    return str(mode).strip() if mode is not None else ""


def check_answer_evidence(rec: dict) -> list[dict]:
    """带答案模式：答案必须有 URL、原件、SHA256、页码/区域、性质与逐问对应。"""
    out = []
    mode = delivery_mode(rec)
    ans = models.answer_block(rec)
    if mode not in ("with_sourced_answers", "optional_explanations"):
        if ans and ans.get("items"):
            out.append(_issue("ANS_UNEXPECTED", "warn", "题目版带了答案条目，确认不是误把草稿答案混入", "§5.5", "answer"))
        return out
    nature = str(ans.get("nature") or "")
    if nature not in models.ANSWER_NATURES or nature == "未取得":
        out.append(_issue("ANS_NATURE", "block", f"答案性质 {nature!r} 未标或不合法（原卷参考答案/转载参考答案/平台解析）", "§5.5", "answer.nature"))
    url = str(ans.get("source_url") or "")
    if not (url.startswith(("http://", "https://", "file://")) or Path(url).exists()):
        out.append(_issue("ANS_NO_URL", "block", "带答案模式缺答案来源 URL/本地答案文件", "§5.5", "answer.source_url"))
    ev = ans.get("evidence") or []
    if not ev:
        out.append(_issue("ANS_NO_EVIDENCE_FILE", "block", "带答案模式缺答案原件（答案页/答案文件）", "§5.5", "answer.evidence"))
    for i, item in enumerate(ev):
        p = _resolve(item.get("path"))
        field = f"answer.evidence[{i}]"
        if not p or not p.exists():
            out.append(_issue("ANS_EVIDENCE_MISSING", "block", f"答案原件不存在：{item.get('path')}", "§5.5", field))
            continue
        if not item.get("sha256") or fingerprint.sha256_file(p) != item["sha256"]:
            out.append(_issue("ANS_EVIDENCE_HASH", "block", "答案原件哈希缺失或与记录不符（原件被换过）", "§5.5", field))
        if item.get("page") in (None, "") and not item.get("region"):
            out.append(_issue("ANS_EVIDENCE_LOCATE", "block", "答案原件缺页码或区域，无法定位到该题答案", "§5.5", field))
    items = models.answer_items(rec)
    labels = [s.get("label") for s in (models.subquestions(rec) or [])]
    extra = [k for k in items if k not in labels and k != "答案"]
    if extra:
        out.append(_issue("ANS_SUB_EXTRA", "warn", f"答案条目在小问中不存在：{extra}", "§5.5", "answer.items"))
    # 来源答案的完整性由 answer.mapping 判定：逐空覆盖、来源位置、原文片段。
    out.extend(answers.issues(rec))
    return out


def check_delivery(rec: dict) -> list[dict]:
    """按交付模式区分答案要求：题目版允许无答案，答案版必须有可追溯证据。"""
    out = []
    mode = delivery_mode(rec)
    if mode not in models.DELIVERY_MODES:
        out.append(_issue("DLV_MODE", "block", f"交付模式 {mode!r} 未声明或无效", "§5.5", "delivery.mode"))
        return out
    requested = str(models.get(rec, "delivery.requested_mode") or "").strip()
    effective = str(models.get(rec, "delivery.effective_mode") or mode).strip()
    if requested and effective and requested != effective:
        out.append(_issue(
            "DLV_MODE_DOWNGRADED", "block",
            f"用户请求 {requested}，实际 {effective}；{models.get(rec, 'delivery.downgrade_reason') or '未写降级原因'}。"
            "不得静默把来源答案版改成题目版报完成。",
            "§5.5", "delivery.requested_mode",
        ))
    if requested == "questions_only" and mode in ("with_sourced_answers", "optional_explanations"):
        out.append(_issue("DLV_MODE_OVERDELIVERED", "block",
                          "用户只要题目版，实际交付了答案；答案只能作为单独证据，不得自动展示",
                          "§5.5", "delivery.requested_mode"))
    display = models.get(rec, "delivery.display_answers")
    if requested == "questions_only" and display is True:
        out.append(_issue("DLV_ANSWER_DISPLAY", "block",
                          "题目版设置 display_answers=true；会泄露答案", "§5.5", "delivery.display_answers"))
    cmp_ = models.get(rec, "solution.comparison", {}) or {}
    if mode == "with_sourced_answers":
        # 来源答案模式只要求原件+完整映射；不要求独立解题/自写长解。
        st = answers.mapping_state(rec)
        if st["status"] != "complete":
            out.append(
                _issue(
                    "DLV_ANSWERS_UNVERIFIED", "block",
                    f"来源答案映射状态为 {st['status']!r}；必须 complete 且逐空覆盖",
                    "§5.5", "answer.mapping_status",
                )
            )
    elif mode == "optional_explanations":
        if not models.get(rec, "delivery.explanations_requested"):
            out.append(
                _issue("DLV_EXPLAIN_NOT_REQUESTED", "block", "optional_explanations 模式未记录用户明确要求讲解", "§5.5", "delivery.explanations_requested")
            )
        if cmp_.get("status") == "compared" and not (cmp_.get("source") or "").strip():
            out.append(_issue("DLV_ANSWERS_NO_SOURCE", "block", "声明已对照答案但未记录答案来源", "§5.5", "solution.comparison.source"))
    else:  # questions_only
        if models.get(rec, "delivery.claims_answers_verified") or (models.get(rec, "delivery") or {}).get("claims_answers_verified"):
            out.append(
                _issue("DLV_QUESTIONS_ONLY_CLAIM", "block", "题目版不得声明“答案已核验”", "§5.5", "delivery.claims_answers_verified")
            )
    return out


def collect(rec: dict) -> list[dict]:
    issues = []
    issues += check_source(rec)
    issues += check_problem(rec)
    issues += check_figure(rec)
    issues += physics.check(rec)
    issues += check_delivery(rec)
    issues += check_answer_evidence(rec)
    issues += check_review(rec)
    return issues


def has_block(issues) -> bool:
    return any(i["level"] == "block" for i in issues)


def summarise(rid: str, issues) -> dict:
    return {
        "id": rid,
        "blocks": [i for i in issues if i["level"] == "block"],
        "warns": [i for i in issues if i["level"] == "warn"],
        "infos": [i for i in issues if i["level"] == "info"],
        "admissible": not has_block(issues),
    }


def print_issues(issues) -> None:
    icon = {"block": "阻断", "warn": "警告", "info": "信息"}
    for i in issues:
        print(f"  [{icon.get(i['level'], i['level'])}] {i['code']}: {i['message']}")
    if not issues:
        print("  （无问题）")


def load_record(path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(args) -> int:
    rec = load_record(args.record)
    issues = collect(rec)
    summary = summarise(rec.get("id"), issues)
    print(f"准入校验 {rec.get('id')}  status={rec.get('status')}  stage={rec.get('stage')}")
    print(f"  阻断 {len(summary['blocks'])} · 警告 {len(summary['warns'])} · 信息 {len(summary['infos'])}")
    print_issues([i for i in issues if i["level"] != "info"])
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    if args.run:
        rd = paths.run_dir(args.run)
        (rd / "validate.json").write_text(
            json.dumps({"summary": summary, "issues": issues}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    if summary["admissible"]:
        print("结论：允许进入正式生成")
        return 0
    if args.allow_draft:
        print("结论：仅允许草稿（DRAFT），阻断项见上，不得作为正式交付")
        return 0
    print("结论：阻断，禁止正式生成")
    return 1
