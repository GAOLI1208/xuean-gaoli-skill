"""第7轮：最小通用任务接口（需求 → 搜索证据 → 候选 → 选择 → 续接）。

设计边界：
- 程序只检查明确字段、证据文件/定位和状态；语义是否符合由模型读原题判断，
  但必须把题面字段与原文片段写入逐条件证据，不接受 matched=true。
- 旧池/旧记录只能作回归材料；新任务必须有自己的搜索调用记录与候选快照。
- 不在这里发网络请求；搜索由 DSH 的 web_search/web_fetch 插件完成，再把
  原始轨迹/响应摘要登记到任务。这样不另写搜索引擎，也不伪造搜索调用。
"""

from __future__ import annotations

import copy
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import fingerprint, models, paths

CST = timezone(timedelta(hours=8))
TASK_ROOT = paths.DIRS["runs"] / "tasks"
MAX_SEARCHES = 6
MAX_DETAIL_OPENS = 4

CONDITION_KINDS = {
    "stage", "region", "year", "exam_type", "question_type",
    "min_subquestions", "figure_required", "answer_required", "semantic",
}


def _now() -> str:
    return datetime.now(CST).isoformat(timespec="seconds")


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(path)


def _read_json(path: Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _task_dir(task_id: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9._-]{3,80}", task_id or ""):
        raise SystemExit(f"任务 ID 不合法：{task_id!r}")
    return TASK_ROOT / task_id


def _load(task_id: str) -> tuple[Path, dict]:
    td = _task_dir(task_id)
    p = td / "task.json"
    if not p.exists():
        raise SystemExit(f"任务不存在：{task_id}（{p}）")
    return td, _read_json(p)


def _save(td: Path, task: dict) -> None:
    task["updated_at"] = _now()
    _write_json(td / "task.json", task)


def _source_fp_no_status(rec: dict) -> str:
    """选候选时只认来源/证据/文件变化；source.status 的审核状态变化不算证据变。"""
    r = copy.deepcopy(rec)
    if isinstance(r.get("source"), dict):
        r["source"]["status"] = "__review_state__"
    return fingerprint.components(r)["source"]


def _event(task: dict, kind: str, detail: str, **extra) -> None:
    task.setdefault("events", []).append({"at": _now(), "type": kind, "detail": detail, **extra})


def _norm_conditions(raw) -> list[dict]:
    if not isinstance(raw, list) or not raw:
        raise SystemExit("需求必须包含至少一条 conditions（硬条件/偏好）；不能只给一句自然语言就让程序猜。")
    out = []
    for i, c in enumerate(raw, 1):
        if isinstance(c, str):
            c = {"text": c, "kind": "semantic", "hard": True}
        if not isinstance(c, dict):
            raise SystemExit(f"conditions[{i}] 必须是对象或字符串")
        cid = str(c.get("id") or f"C{i}").strip()
        kind = str(c.get("kind") or "semantic").strip()
        if kind not in CONDITION_KINDS:
            raise SystemExit(f"conditions[{i}].kind 不支持：{kind!r}；可用 {sorted(CONDITION_KINDS)}")
        text = str(c.get("text") or "").strip()
        if not text:
            raise SystemExit(f"conditions[{i}].text 不能为空")
        item = {
            "id": cid, "text": text, "kind": kind,
            "hard": bool(c.get("hard", True)),
            "value": c.get("value"),
        }
        out.append(item)
    ids = [c["id"] for c in out]
    if len(set(ids)) != len(ids):
        raise SystemExit(f"conditions id 重复：{ids}")
    return out


def validate_requirement(raw: dict) -> dict:
    if not isinstance(raw, dict):
        raise SystemExit("需求文件必须是 JSON object")
    req = {
        "request": str(raw.get("request") or "").strip(),
        "stage": raw.get("stage"),          # 未指定就保留 null，不填默认“初中”
        "knowledge_concepts": raw.get("knowledge_concepts") or [],
        "asked_relation": str(raw.get("asked_relation") or "").strip(),
        "question_type": raw.get("question_type"),
        "region": raw.get("region"),
        "year": raw.get("year"),
        "exam_type": raw.get("exam_type"),
        "figure_required": raw.get("figure_required"),
        "answer_required": raw.get("answer_required"),
        "conditions": _norm_conditions(raw.get("conditions")),
        "preferences": raw.get("preferences") or [],
        "notes": raw.get("notes") or "",
    }
    if not req["request"]:
        raise SystemExit("需求缺少 request（教师原话/请求摘要）")
    if req["stage"] not in (None, "初中", "高中"):
        raise SystemExit("stage 只能是 初中/高中 或 null（未指定不要补设）")
    if req["year"] is not None and not isinstance(req["year"], int):
        raise SystemExit("year 必须是整数或 null")
    if req["answer_required"] not in (None, "none", "sourced", "optional"):
        raise SystemExit("answer_required 只能是 none/sourced/optional 或 null")
    return req


def _field_value(rec: dict, field: str):
    if field == "stage":
        return rec.get("stage")
    if field == "year":
        return models.get(rec, "identity.exam_year")
    if field == "region":
        return models.get(rec, "identity.region")
    if field == "exam_type":
        return models.get(rec, "identity.exam_type")
    if field == "question_type":
        prob = rec.get("problem") or {}
        if models.is_choice(rec):
            return "choice"
        if prob.get("subquestions"):
            return "constructed_response"
        return "unknown"
    if field == "subquestion_count":
        return len(models.subquestions(rec))
    if field == "figure_count":
        return len(models.figures(rec))
    if field == "answer_mode":
        mode = models.get(rec, "delivery.mode")
        if mode == "with_sourced_answers":
            # answer_mode 只能证明模式+映射声明，不能证明答案原件真实性。
            if models.get(rec, "answer.mapping_status") == "complete" and models.get(rec, "answer.evidence"):
                return "with_sourced_answers"
            return "questions_only"
        return mode
    if field.startswith("problem.") or field.startswith("identity.") or field.startswith("source."):
        return models.get(rec, field)
    return models.get(rec, field)


def _status_from_compare(kind: str, value, actual) -> str:
    if kind == "stage":
        if actual in (None, ""):
            return "unknown"
        return "satisfied" if actual == value else "not_satisfied"
    if kind == "year":
        if actual in (None, "", "未标"):
            return "unknown"
        try:
            return "satisfied" if int(actual) == int(value) else "not_satisfied"
        except (TypeError, ValueError):
            return "unknown"
    if kind == "region":
        if actual in (None, ""):
            return "unknown"
        return "satisfied" if str(value) in str(actual) else "not_satisfied"
    if kind == "exam_type":
        if actual in (None, ""):
            return "unknown"
        return "satisfied" if str(value) in str(actual) else "not_satisfied"
    if kind == "question_type":
        if actual in (None, "unknown"):
            return "unknown"
        return "satisfied" if actual == value else "not_satisfied"
    if kind == "min_subquestions":
        if actual is None:
            return "unknown"
        return "satisfied" if int(actual) >= int(value) else "not_satisfied"
    if kind == "figure_required":
        actual = int(actual or 0)
        if value is True:
            return "satisfied" if actual > 0 else "not_satisfied"
        if value is False:
            return "satisfied" if actual == 0 else "not_satisfied"
        return "unknown"
    if kind == "answer_required":
        actual = str(actual or "")
        if value == "sourced":
            return "satisfied" if actual == "with_sourced_answers" else "not_satisfied"
        if value == "none":
            return "satisfied" if actual == "questions_only" else "not_satisfied"
        return "unknown"
    return "unknown"


def auto_check(rec: dict, cond: dict) -> dict | None:
    """对明确字段由程序判定；semantic 条件必须由模型提供证据。"""
    kind = cond["kind"]
    if kind == "semantic":
        return None
    field = {
        "stage": "stage", "year": "year", "region": "region", "exam_type": "exam_type",
        "question_type": "question_type", "min_subquestions": "subquestion_count",
        "figure_required": "figure_count", "answer_required": "answer_mode",
    }[kind]
    value = cond.get("value")
    actual = _field_value(rec, field)
    status = _status_from_compare(kind, value, actual)
    return {
        "condition_id": cond["id"], "status": status, "source": "program",
        "field": field,
        "quote": "" if actual is None else str(actual),
        "note": f"程序检查 {field}={actual!r}；条件 {cond['text']}"
                + ("；answer_mode 只证明模式/映射声明，答案原件真实性需回源核" if kind == "answer_required" else ""),
    }


def _check_evidence(rec: dict, chk: dict) -> tuple[bool, str]:
    field = str(chk.get("field") or "").strip()
    quote = str(chk.get("quote") or "").strip()
    if not field:
        return False, "缺 field"
    val = _field_value(rec, field)
    if val is None:
        return False, f"题面字段不存在/为空：{field}"
    text = json.dumps(val, ensure_ascii=False) if not isinstance(val, str) else val
    if not quote:
        return False, f"缺 quote（{field} 的原文片段）"
    if quote not in text:
        return False, f"quote 未在 {field} 中逐字找到"
    return True, ""


def _candidate_card(task: dict, cand: dict) -> str:
    lines = [f"候选 {cand['id']}：{cand.get('title') or cand.get('record_id')}",
             f"  记录：{cand.get('record_path')}",
             f"  来源：{cand.get('source_url') or '—'}"]
    for chk in cand.get("checks", []):
        mark = {"satisfied": "满足", "not_satisfied": "不符", "unknown": "未知"}.get(chk.get("status"), "?")
        lines.append(f"  [{mark}] {chk.get('condition_id')} {chk.get('note') or ''}")
        if chk.get("field"):
            lines.append(f"       {chk['field']}: {str(chk.get('quote') or '')[:120]}")
        if chk.get("coverage"):
            cov = chk["coverage"]
            if isinstance(cov, (list, tuple)):
                cov = "、".join(str(x) for x in cov)
            lines.append(f"       覆盖：{str(cov)[:160]}")
    lines.append(f"  硬条件：{'全部满足' if cand.get('hard_ok') else '未全部满足'}；"
                 f"证据完整：{'是' if cand.get('evidence_ok') else '否'}")
    return "\n".join(lines)


def cmd_new(args) -> int:
    raw = _read_json(Path(args.file))
    req = validate_requirement(raw)
    task_id = args.id or ("xuean-" + datetime.now(CST).strftime("%Y%m%d-%H%M%S"))
    td = _task_dir(task_id)
    if td.exists():
        raise SystemExit(f"任务已存在，拒绝覆盖：{td}")
    td.mkdir(parents=True)
    task = {
        "schema_version": 1, "id": task_id, "created_at": _now(), "updated_at": _now(),
        "status": "needs_search", "requirement": req,
        "search": {"calls": [], "call_count": 0, "detail_opens": 0, "subqueries": 0,
                   "budget": {"max_searches": MAX_SEARCHES, "max_detail_opens": MAX_DETAIL_OPENS}},
        "queries": [], "candidates": [], "selection": None, "events": [],
    }
    _event(task, "created", "需求已持久化")
    _write_json(td / "requirement.json", req)
    _save(td, task)
    print(f"任务：{task_id}")
    print(f"  目录：{paths.rel(td)}")
    print(f"  条件：{len(req['conditions'])} 条（硬 {sum(1 for c in req['conditions'] if c['hard'])}）")
    print(f"  下一步：xuean.py task plan {task_id}")
    return 0


def cmd_list(args) -> int:
    TASK_ROOT.mkdir(parents=True, exist_ok=True)
    rows = []
    for p in sorted(TASK_ROOT.glob("*/task.json")):
        try:
            t = _read_json(p)
        except Exception:
            continue
        rows.append((t.get("id", p.parent.name), t.get("status"), t.get("created_at"),
                     len(t.get("candidates") or []), (t.get("requirement") or {}).get("request", "")[:48]))
    if not rows:
        print("（还没有任务）")
        return 0
    for rid, status, at, n, req in rows:
        print(f"{rid}\t{status}\t候选 {n}\t{at}\t{req}")
    return 0


def cmd_show(args) -> int:
    td, task = _load(args.task)
    print(json.dumps(task, ensure_ascii=False, indent=2))
    return 0


def cmd_plan(args) -> int:
    td, task = _load(args.task)
    req = task["requirement"]
    concepts = [str(x) for x in (req.get("knowledge_concepts") or [])]
    parts = []
    if req.get("stage"):
        parts.append(str(req["stage"]))
    if req.get("region"):
        parts.append(str(req["region"]))
    if req.get("year"):
        parts.append(str(req["year"]))
    if req.get("exam_type"):
        parts.append(str(req["exam_type"]))
    parts += concepts
    if req.get("asked_relation"):
        parts.append(str(req["asked_relation"]))
    if req.get("question_type"):
        parts.append(str(req["question_type"]))
    core = " ".join(x for x in parts if x)
    queries = [
        core,
        f"{core} 物理 真题",
        f"{core} 试题 解析",
    ]
    # 失败调整：不重复同一句，换“题型/作答结构/年份/地区”的限定词。
    if args.reason:
        queries = [
            f"{core} {args.reason}",
            f"{core} 原卷 扫描",
            f"{core} 答案 详解",
        ]
    task.setdefault("queries", []).append(
        {"round": args.round, "reason": args.reason or "", "queries": queries, "at": _now()}
    )
    _event(task, "search_plan", f"round {args.round}: {len(queries)} 条查询")
    task["status"] = "needs_candidates" if task.get("candidates") else "needs_search"
    _save(td, task)
    print(f"查询计划（第 {args.round} 轮，{len(queries)} 条）：")
    for q in queries:
        print(f"  - {q}")
    print("  用 web_search/web_fetch 执行；把原始轨迹/摘要登记到 task add-search。")
    print(f"  预算：搜索 ≤{MAX_SEARCHES} 次，详细打开 ≤{MAX_DETAIL_OPENS} 个候选。")
    return 0


def cmd_reserve_search(args) -> int:
    """在真正调用 web_search 之前占用一次预算；结果由 add-search 回填。"""
    td, task = _load(args.task)
    if task.get("status") in ("search_blocked_429", "search_exhausted", "detail_exhausted"):
        raise SystemExit("本项搜索已停止（429/预算耗尽）；不得再预占/调用。")
    opened = int(getattr(args, "opened", 0) or 0)
    if task["search"]["call_count"] >= MAX_SEARCHES:
        task["status"] = "search_exhausted"
        _save(td, task)
        raise SystemExit(f"搜索预算已满（{MAX_SEARCHES} 次）；本次调用未预占，必须停止。")
    if task["search"]["detail_opens"] + opened > MAX_DETAIL_OPENS:
        raise SystemExit(f"详细打开预算超限：已 {task['search']['detail_opens']}，本次 {opened}，上限 {MAX_DETAIL_OPENS}。")
    rid = f"S{task['search']['call_count'] + 1:02d}"
    item = {"id": rid, "state": "reserved", "at": _now(),
            "tool": getattr(args, "tool", None) or "web_search",
            "query": getattr(args, "query", "") or "",
            "opened": opened, "summary": "", "raw_path": "", "failure": "",
            "http_status": None, "error": ""}
    task["search"].setdefault("reserved", []).append(item)
    task["search"]["call_count"] += 1
    task["search"]["detail_opens"] += opened
    task["status"] = "search_reserved"
    _event(task, "search_reserved", f"{rid} call={task['search']['call_count']}", opened=opened)
    _save(td, task)
    print(f"已预占搜索 {task['search']['call_count']}/{MAX_SEARCHES}：{rid}（opened={opened}）")
    print(f"  先执行实际搜索，再用 task add-search {args.task} --reservation {rid} --file result.json 回填。")
    return 0


def cmd_add_search(args) -> int:
    td, task = _load(args.task)
    data = _read_json(Path(args.file)) if args.file else {}
    if not isinstance(data, dict):
        raise SystemExit("搜索记录必须是 JSON object")
    reserved = data.get("reservation_id") or getattr(args, "reservation", None)
    pending = next((x for x in (task["search"].get("reserved") or []) if x.get("id") == reserved), None) if reserved else None
    if reserved and not pending:
        raise SystemExit(f"找不到未回填的搜索预占：{reserved}")
    if not reserved:
        if task.get("status") in ("search_blocked_429", "search_exhausted", "detail_exhausted"):
            raise SystemExit("本项搜索已停止（429/预算耗尽）；不得再登记实际调用。")
        if task["search"]["call_count"] >= MAX_SEARCHES:
            # 关键：先保存并拒绝，绝不继续 append 后覆盖状态。
            task["status"] = "search_exhausted"
            _event(task, "search_exhausted", f"达到 {MAX_SEARCHES} 次预算；拒绝追加")
            _save(td, task)
            raise SystemExit(f"搜索预算已满（{MAX_SEARCHES} 次）；拒绝追加，状态已保存。")
        if not getattr(args, "allow_unreserved", False):
            raise SystemExit("未预占搜索：正式流程必须先用 task reserve-search 占用预算；"
                             "旧流程可显式 --allow-unreserved 但会标 legacy。")
    opened = int(data.get("opened") or (pending or {}).get("opened") or 0)
    if pending:
        if opened != int(pending.get("opened") or 0):
            # 预占后实际打开数变化：补差额并检查上限。
            delta = opened - int(pending.get("opened") or 0)
            if delta > 0 and task["search"]["detail_opens"] + delta > MAX_DETAIL_OPENS:
                raise SystemExit(f"详细打开预算超限：已 {task['search']['detail_opens']}，追加 {delta}，上限 {MAX_DETAIL_OPENS}。")
            task["search"]["detail_opens"] += max(0, delta)
    raw_path = data.get("raw_path")
    saved_raw = ""
    if raw_path:
        src = Path(raw_path)
        if not src.exists():
            raise SystemExit(f"原始响应文件不存在：{src}")
        dest = td / "search" / f"call-{task['search']['call_count']:02d}{src.suffix or '.txt'}"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        saved_raw = paths.rel(dest)
    item = {
        "at": _now(), "tool": data.get("tool") or "web_search",
        "query": data.get("query") or (pending or {}).get("query") or "",
        "subqueries": int(data.get("subqueries") or 0),
        "result_count": data.get("result_count"), "opened": opened,
        "summary": data.get("summary") or "", "raw_path": saved_raw,
        "failure": data.get("failure") or "",
        "http_status": data.get("http_status"), "error": data.get("error") or "",
        "reservation_id": reserved or "",
        "legacy_unreserved": bool(not reserved),
    }
    if pending:
        pending.update({**item, "state": "done"})
        task["search"]["calls"].append(pending)
        task["search"]["reserved"] = [x for x in task["search"]["reserved"] if x.get("id") != reserved]
        task["search"]["subqueries"] += item["subqueries"]
    else:
        task["search"]["calls"].append(item)
        task["search"]["call_count"] += 1
        task["search"]["subqueries"] += item["subqueries"]
        task["search"]["detail_opens"] += opened
    _event(task, "search", item["query"], call=task["search"]["call_count"], opened=opened,
           http_status=item.get("http_status"), reservation=reserved or "")
    if str(item.get("http_status") or "") == "429":
        task["status"] = "search_blocked_429"
        task["search"]["blocked"] = "HTTP 429"
        _event(task, "search_blocked_429", "HTTP 429；本项立即停止")
        _save(td, task)
        print(f"已回填搜索 {task['search']['call_count']}/{MAX_SEARCHES}；HTTP 429，本项立即停止。")
        return 1
    if task["search"]["call_count"] >= MAX_SEARCHES:
        task["status"] = "search_exhausted"
        _event(task, "search_exhausted", f"达到 {MAX_SEARCHES} 次预算；已读候选仍可选")
    elif task["search"]["detail_opens"] >= MAX_DETAIL_OPENS:
        task["status"] = "detail_exhausted"
        _event(task, "detail_exhausted", f"达到 {MAX_DETAIL_OPENS} 个详细打开预算；已读候选仍可选")
    else:
        task["status"] = "needs_candidates" if not task.get("candidates") else "ready_for_selection"
    _save(td, task)
    print(f"已回填搜索 {task['search']['call_count']}/{MAX_SEARCHES}：{reserved or 'legacy-unreserved'}")
    return 0


def _load_checks(args) -> list[dict]:
    if getattr(args, "checks", None):
        raw = _read_json(Path(args.checks))
    elif getattr(args, "checks_json", None):
        raw = json.loads(args.checks_json)
    else:
        raw = []
    if isinstance(raw, dict):
        raw = raw.get("checks") or []
    if not isinstance(raw, list):
        raise SystemExit("checks 必须是数组")
    return raw


def cmd_add_candidate(args) -> int:
    td, task = _load(args.task)
    rec_path = Path(args.record)
    if not rec_path.is_absolute():
        rec_path = paths.LAB_ROOT / rec_path
    if not rec_path.exists():
        raise SystemExit(f"候选记录不存在：{rec_path}")
    rec = _read_json(rec_path)
    cid = args.candidate_id or f"C{len(task['candidates']) + 1}"
    if any(c.get("id") == cid for c in task.get("candidates") or []):
        raise SystemExit(f"候选 {cid} 已存在；不得覆盖旧证据，请用新 candidate-id。")
    cdir = td / "candidates"
    cdir.mkdir(parents=True, exist_ok=True)
    snapshot = cdir / f"{cid}.record.json"
    shutil.copy2(rec_path, snapshot)
    checks = _load_checks(args)
    by_id = {str(c.get("condition_id") or c.get("id")): c for c in checks if isinstance(c, dict)}
    out_checks = []
    ok = True
    for cond in task["requirement"]["conditions"]:
        auto = auto_check(rec, cond)
        chk = by_id.get(cond["id"])
        if auto is not None:
            # 明确字段由程序判定，模型提供的同 id 结果不能覆盖不符/未知。
            if chk and chk.get("status") in ("satisfied", "not_satisfied", "unknown"):
                auto["model_note"] = chk.get("note") or ""
            out_checks.append(auto)
        else:
            if not chk:
                out_checks.append({"condition_id": cond["id"], "status": "unknown", "source": "model",
                                   "field": "", "quote": "", "note": "未提供题面证据"})
                ok = False
                continue
            ev_ok, why = _check_evidence(rec, chk)
            status = str(chk.get("status") or "unknown")
            if status not in ("satisfied", "not_satisfied", "unknown"):
                raise SystemExit(f"候选 {cid} 条件 {cond['id']} 状态非法：{status}")
            if status in ("satisfied", "not_satisfied") and not ev_ok:
                status = "unknown"
                chk["note"] = (chk.get("note") or "") + f"（证据不足：{why}）"
            out_checks.append({
                "condition_id": cond["id"], "status": status, "source": "model",
                "field": chk.get("field") or "", "quote": chk.get("quote") or "",
                "coverage": chk.get("coverage") or "",
                "note": chk.get("note") or "",
            })
        if cond["hard"] and out_checks[-1]["status"] != "satisfied":
            ok = False
    all_evidence = all(c["status"] in ("satisfied", "not_satisfied") for c in out_checks)
    # 多空/多关系/逐项类语义条件必须写覆盖到的空位或关系，不能只用短词。
    coverage_required = []
    for cond in task["requirement"]["conditions"]:
        if cond.get("kind") == "semantic" and re.search(r"(空|关系|小问|多个|至少|全部|逐|每一)", str(cond.get("text") or "")):
            coverage_required.append(cond["id"])
    missing_cov = [c["condition_id"] for c in out_checks
                   if c["condition_id"] in coverage_required and not str(c.get("coverage") or "").strip()]
    coverage_ok = not missing_cov
    cand = {
        "id": cid, "record_id": rec.get("id"), "record_path": paths.rel(snapshot),
        "source_url": (models.get(rec, "source.urls") or [None])[0],
        "title": args.title or models.get(rec, "teaching.topic") or rec.get("id"),
        "added_at": _now(), "record_sha256": fingerprint.sha256_file(snapshot),
        "source_fingerprint": _source_fp_no_status(rec),
        "checks": out_checks,
        "hard_ok": ok, "evidence_ok": all_evidence and coverage_ok,
        "coverage_required": coverage_required, "coverage_missing": missing_cov,
        "hard_failures": [c["condition_id"] for c in out_checks if c["status"] == "not_satisfied"],
        "unknown_hard": [c["condition_id"] for c in out_checks
                         if c["status"] == "unknown" and any(x["id"] == c["condition_id"] and x["hard"] for x in task["requirement"]["conditions"])],
    }
    task["candidates"] = [c for c in task["candidates"] if c["id"] != cid] + [cand]
    task["status"] = "ready_for_selection" if any(c["hard_ok"] for c in task["candidates"]) else "needs_candidates"
    _event(task, "candidate_added", f"{cid} {cand['title']}", hard_ok=ok)
    _save(td, task)
    print(_candidate_card(task, cand))
    if not ok:
        print("  注意：该候选不能用于选择；硬条件存在不符或未知。")
    return 0


def cmd_select(args) -> int:
    td, task = _load(args.task)
    cand = next((c for c in task["candidates"] if c["id"] == args.candidate), None)
    if cand is None:
        raise SystemExit(f"候选不存在：{args.candidate}")
    if not cand.get("hard_ok"):
        print(_candidate_card(task, cand))
        raise SystemExit("拒绝选择：硬条件未全部满足；不得放宽硬条件。")
    if not cand.get("evidence_ok"):
        print(_candidate_card(task, cand))
        raise SystemExit("拒绝选择：证据不完整（含多空/关系覆盖）；不得用短词代替逐项证据。")
    snap = Path(cand.get("record_path") or "")
    if not snap.is_absolute():
        snap = paths.LAB_ROOT / snap
    if not snap.exists():
        raise SystemExit(f"候选快照不存在：{snap}")
    if cand.get("record_sha256") and fingerprint.sha256_file(snap) != cand["record_sha256"]:
        raise SystemExit("拒绝选择：候选快照在登记后被改动，旧条件证据已失效。")
    snap_rec = _read_json(snap)
    if cand.get("source_fingerprint") and _source_fp_no_status(snap_rec) != cand["source_fingerprint"]:
        raise SystemExit("拒绝选择：来源文件/来源元数据已变化，旧候选条件失效。")
    task["selection"] = {"candidate_id": cand["id"], "at": _now(), "notes": args.note or "",
                         "record_sha256": cand.get("record_sha256"),
                         "source_fingerprint": cand.get("source_fingerprint")}
    task["status"] = "selected"
    _event(task, "selected", f"{cand['id']} {cand['title']}")
    _save(td, task)
    print(f"已选择：{cand['id']} {cand['title']}")
    print(f"  记录：{cand['record_path']}")
    print(f"  续接：xuean.py task resume {task['id']}")
    return 0


def cmd_resume(args) -> int:
    td, task = _load(args.task)
    print(f"任务 {task['id']}  状态 {task['status']}")
    print(f"  需求：{(task.get('requirement') or {}).get('request')}")
    print(f"  搜索：{task['search']['call_count']}/{MAX_SEARCHES} 次，详细打开 {task['search']['detail_opens']}/{MAX_DETAIL_OPENS}，子查询 {task['search']['subqueries']}")
    print(f"  候选：{len(task.get('candidates') or [])} 个")
    for c in task.get("candidates") or []:
        print(f"    {c['id']}\t{'可选' if c.get('hard_ok') else '不可选'}\t{c.get('title')}")
    sel = task.get("selection")
    if sel:
        c = next((x for x in task["candidates"] if x["id"] == sel["candidate_id"]), None)
        stale = []
        if c:
            snap = Path(c.get("record_path") or "")
            if not snap.is_absolute():
                snap = paths.LAB_ROOT / snap
            if not snap.exists():
                stale.append("快照文件不存在")
            else:
                if c.get("record_sha256") and fingerprint.sha256_file(snap) != c["record_sha256"]:
                    stale.append("快照 hash 变化")
                if c.get("source_fingerprint") and _source_fp_no_status(_read_json(snap)) != c["source_fingerprint"]:
                    stale.append("来源 fingerprint 变化")
        if stale:
            task["status"] = "selection_stale"
            _save(td, task)
            print(f"  警告：选择已失效（{'；'.join(stale)}）；需重查候选/重新选择。")
            return 1
        else:
            print(f"  已选：{sel['candidate_id']} {c.get('title') if c else ''}")
            print(f"  记录：{c.get('record_path') if c else ''}")
            print(f"  下一步：xuean.py validate <记录>；补齐审核后用 build/audit/visual/deliver。")
    elif task.get("candidates"):
        print(f"  下一步：xuean.py task select {task['id']} <候选ID>")
    else:
        print(f"  下一步：xuean.py task plan {task['id']}，搜索后 task add-search / add-candidate")
    return 0


def register(subparsers) -> None:
    p = subparsers.add_parser("task", help="需求→搜索证据→候选→选择→续接")
    p.set_defaults(func=main)
    sub = p.add_subparsers(dest="task_command", required=True)

    n = sub.add_parser("new", help="从需求 JSON 新建任务")
    n.add_argument("--file", required=True)
    n.add_argument("--id")
    n.set_defaults(func=cmd_new)

    ls = sub.add_parser("list", help="列出任务")
    ls.set_defaults(func=cmd_list)

    sh = sub.add_parser("show", help="显示任务 JSON")
    sh.add_argument("task")
    sh.set_defaults(func=cmd_show)

    pl = sub.add_parser("plan", help="生成查询计划（不代发搜索）")
    pl.add_argument("task")
    pl.add_argument("--round", type=int, default=1)
    pl.add_argument("--reason", default="", help="上一轮失败原因，用于换查询")
    pl.set_defaults(func=cmd_plan)

    rsv = sub.add_parser("reserve-search", help="实际 web_search 前占用一次预算（返回 reservation id）")
    rsv.add_argument("task")
    rsv.add_argument("--query", default="")
    rsv.add_argument("--tool", default="web_search")
    rsv.add_argument("--opened", type=int, default=0)
    rsv.set_defaults(func=cmd_reserve_search)

    se = sub.add_parser("add-search", help="回填一次搜索/429；正式流程须先 reserve-search")
    se.add_argument("task")
    se.add_argument("--file", required=True, help="JSON：query/tool/raw_path/opened/summary/http_status...")
    se.add_argument("--reservation", default="", help="预占 ID；不给则拒绝（旧流程需显式 allow）")
    se.add_argument("--allow-unreserved", action="store_true", help="仅兼容旧流程：标 legacy_unreserved")
    se.set_defaults(func=cmd_add_search)

    ca = sub.add_parser("add-candidate", help="登记候选与逐条件题面证据")
    ca.add_argument("task")
    ca.add_argument("--record", required=True)
    ca.add_argument("--candidate-id")
    ca.add_argument("--title")
    ca.add_argument("--checks", help="逐条件 checks JSON 文件")
    ca.add_argument("--checks-json", help="逐条件 checks JSON 字符串")
    ca.set_defaults(func=cmd_add_candidate)

    sel = sub.add_parser("select", help="选择候选（硬条件必须全部满足）")
    sel.add_argument("task")
    sel.add_argument("candidate")
    sel.add_argument("--note", default="")
    sel.set_defaults(func=cmd_select)

    rs = sub.add_parser("resume", help="续接：显示当前状态与下一入口")
    rs.add_argument("task")
    rs.set_defaults(func=cmd_resume)


def main(args) -> int:
    func = getattr(args, "func", None)
    if func is None:
        raise SystemExit("缺少 task 子命令")
    return int(func(args) or 0)
