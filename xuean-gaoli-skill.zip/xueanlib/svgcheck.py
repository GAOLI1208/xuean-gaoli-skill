"""SVG 题图检查：标签是否真的在图中，几何约束是否满足。

只检查 SVG 中实际存在的对象，不接受“manifest 里写了 expected_labels 就算齐全”。
复杂曲线、拓扑关系仍需视觉核对，这里只做可判定的部分。
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

SUB = str.maketrans("₀₁₂₃₄₅₆₇₈₉₊₋", "0123456789+-")
SEP = re.compile(r"[\s_^{}]+")


def norm(s: str) -> str:
    s = str(s).translate(SUB)
    s = SEP.sub("", s)
    return s.replace("（", "(").replace("）", ")").lower()


def _local(tag: str) -> str:
    return tag.split("}")[-1]


class SvgDoc:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.texts: list[tuple[str, str]] = []  # (normalized, 原文)
        self.elements: dict[str, dict] = {}
        self.errors: list[str] = []
        try:
            root = ET.parse(self.path).getroot()
        except Exception as exc:
            self.errors.append(f"SVG 解析失败：{exc}")
            return
        for el in root.iter():
            tag = _local(el.tag)
            if tag in ("text", "tspan"):
                txt = "".join(el.itertext()).strip()
                if txt:
                    self.texts.append((norm(txt), txt))
            elif tag in ("ellipse", "circle", "rect", "line", "path", "polyline", "polygon", "marker"):
                eid = el.get("id")
                if eid:
                    self.elements[eid] = {"tag": tag, **el.attrib}

    def has(self, label: str) -> bool:
        target = norm(label)
        return any(target == t for t, _ in self.texts)

    def find_labels(self, label: str) -> list[str]:
        target = norm(label)
        return [orig for t, orig in self.texts if target == t]


def parse_float(v, default=None):
    try:
        return float(str(v).replace("px", ""))
    except Exception:
        return default


def check(svg_path, expected_labels=None, expected_times=None, constraints=None) -> dict:
    """返回 {ok, issues:[{code,level,message}], meta}"""
    issues = []
    doc = SvgDoc(Path(svg_path))
    if doc.errors:
        return {"ok": False, "issues": [{"code": "SVG_PARSE", "level": "block", "message": doc.errors[0]}], "meta": {}}

    all_expected = list(expected_labels or []) + list(expected_times or [])
    missing = [lbl for lbl in all_expected if not doc.has(lbl)]
    present_norm = {t for t, _ in doc.texts}
    declared_norm = {norm(x) for x in all_expected}
    extra = sorted({orig for t, orig in doc.texts if t not in declared_norm})

    if missing:
        issues.append(
            {
                "code": "SVG_MISSING_LABEL",
                "level": "block",
                "message": f"图中缺少声明过的标签：{missing}（实际文本：{[o for _, o in doc.texts]}）",
            }
        )
    if any(len(t) > 12 for t, _ in doc.texts):
        issues.append(
            {
                "code": "SVG_LONG_TEXT",
                "level": "warn",
                "message": "图中有过长文本元素，可能把题干塞进图里",
            }
        )

    for c in constraints or []:
        typ = c.get("type")
        eid = c.get("id")
        if typ == "ellipse":
            el = doc.elements.get(eid)
            if not el or el["tag"] not in ("ellipse",):
                issues.append({"code": "SVG_CONSTRAINT_MISSING", "level": "block", "message": f"几何约束要求椭圆 id={eid}，图中未找到"})
                continue
            rx = parse_float(el.get("rx"))
            ry = parse_float(el.get("ry"))
            if not rx or not ry:
                issues.append({"code": "SVG_CONSTRAINT_BAD", "level": "block", "message": f"椭圆 {eid} 缺 rx/ry"})
                continue
            orientation = c.get("orientation")
            if orientation == "tall" and not (ry > rx):
                issues.append({"code": "SVG_ORIENTATION", "level": "block", "message": f"椭圆 {eid} 应为窄高（ry>rx），实际 rx={rx}, ry={ry}"})
            if orientation == "flat" and not (rx > ry):
                issues.append({"code": "SVG_ORIENTATION", "level": "block", "message": f"椭圆 {eid} 应为宽扁（rx>ry），实际 rx={rx}, ry={ry}"})
            ratio = max(rx, ry) / min(rx, ry)
            lo = c.get("axis_ratio_min")
            hi = c.get("axis_ratio_max")
            if lo is not None and ratio < lo:
                issues.append({"code": "SVG_RATIO", "level": "block", "message": f"椭圆 {eid} 长短轴比 {ratio:.2f} 小于下限 {lo}"})
            if hi is not None and ratio > hi:
                issues.append({"code": "SVG_RATIO", "level": "block", "message": f"椭圆 {eid} 长短轴比 {ratio:.2f} 超过上限 {hi}"})
        elif typ == "element":
            if eid not in doc.elements:
                issues.append({"code": "SVG_CONSTRAINT_MISSING", "level": "block", "message": f"几何约束要求元素 id={eid}，图中未找到"})
        elif typ == "marker":
            # 方向箭头：要求存在 marker 或 polyline，属于可判定但不能判断指向，交视觉核对
            if not doc.elements.get(eid):
                issues.append({"code": "SVG_CONSTRAINT_MISSING", "level": "block", "message": f"图中缺少方向元素 id={eid}"})
            issues.append({"code": "SVG_ARROW_VISUAL", "level": "info", "message": f"箭头 {eid} 的方向需视觉核对"})
        else:
            issues.append({"code": "SVG_CONSTRAINT_UNKNOWN", "level": "warn", "message": f"未知几何约束类型：{typ}"})

    meta = {
        "texts": [o for _, o in doc.texts],
        "extra_texts": extra,
        "texts_total": len(doc.texts),
        "elements": sorted(doc.elements),
    }
    ok = not any(i["level"] == "block" for i in issues)
    return {"ok": ok, "issues": issues, "meta": meta}
