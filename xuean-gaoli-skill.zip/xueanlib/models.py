"""统一题目数据结构（单份 JSON 驱动正文、题号、来源索引、教学用途）。

字段定义见 templates/question.schema.json；本模块只做轻量访问与补全，
严格校验在 validate.py。
"""

from __future__ import annotations

STAGES = {"初中", "高中"}
SOURCE_STATUS = {"线索", "待核实", "通过", "受限", "冲突"}
# 只有显式“通过”才允许正式编排；其余（含待核实/线索/受限/冲突/空值/未知）一律只进 DRAFT。
SOURCE_STATUS_PASS = "通过"
DELIVERY_MODES = {"questions_only", "with_sourced_answers", "optional_explanations"}
PUBLICATION_TYPES = {"第一方", "完整转载", "汇编"}
COMPARISON_STATUS = {"missing", "partial", "compared"}
REVIEW_CHECKS = ("source", "text", "answer", "redraw", "physics")
# 审核状态白名单：只有“通过”为 ok，其余必须显式归类并阻断。
REVIEW_PASS = "通过"
REVIEW_REJECT = {"未通过", "失败", "拒绝", "不通过"}
REVIEW_PENDING = {"待审", "待检查", "待核实", "检查中", "pending"}
REVIEW_UNCHECKED = {"未检查", ""}


def get(rec: dict, dotted: str, default=None):
    cur = rec
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def subquestions(rec: dict) -> list[dict]:
    return get(rec, "problem.subquestions", []) or []


def figures(rec: dict) -> list[dict]:
    """一道题可以有多个图（原卷常见：图甲/乙/丙 各自独立）。

    兼容旧记录：`problem.figure` 单图写法等价于 `problem.figures: [figure]`。
    """
    figs = get(rec, "problem.figures")
    if isinstance(figs, list):
        return [f for f in figs if isinstance(f, dict)]
    fig = get(rec, "problem.figure")
    return [fig] if isinstance(fig, dict) else []


def figure(rec: dict) -> dict | None:
    figs = figures(rec)
    return figs[0] if figs else None


def review(rec: dict, check: str) -> dict | None:
    rev = get(rec, f"review.{check}")
    return rev if isinstance(rev, dict) else None


def body_markup(text: str) -> str:
    """排版层约定：题干/解析直接写 Typst markup（公式用 $...$）。

    这里只做最小体检，尽早暴露 LaTeX 残留，避免每次手工换公式系统。
    """
    bad = []
    if "\\frac" in text or "\\sqrt" in text or "$$" in text:
        bad.append("出现 LaTeX 语法（\\frac/\\sqrt/$$），请改写为 Typst：frac(a,b)、sqrt(x)")
    return bad


def empty_record(rid: str) -> dict:
    return {
        "id": rid,
        "status": "线索",
        "stage": None,
        "identity": {
            "exam_year": None,
            "exam_year_label": "未标",
            "year_evidence": "",
            "region": None,
            "school": None,
            "exam_name": None,
            "exam_type": None,
            "original_number": None,
            "bank_id": None,
            "booklet_number": None,
        },
        "source": {
            "urls": [],
            "origin_role": "unknown",
            "derived": None,
            "original": None,
            "dom": {},
            "material_type": "unknown",
            "publisher": None,
            "publication_type": None,
            "retrieved_at": None,
            "evidence": [],
            "upstream": [],
            "open_questions": [],
            "status": "线索",
        },
        "problem": {"stem": "", "options": [], "subquestions": [], "figure": None},
        "teaching": {
            "stage": None,
            "topic": None,
            "knowledge_points": [],
            "prerequisites": [],
            "difficulty_reason": None,
            "est_minutes": None,
            "use": None,
            "textbook": {"publisher": None, "edition": None, "note": "未核实学生实际用书"},
        },
        "delivery": {
            "mode": "questions_only",
            "requested_mode": "questions_only",
            "effective_mode": "questions_only",
            "downgrade_reason": "",
            "display_answers": False,
            "explanations_requested": False,
            "note": "questions_only：允许不附答案，但须明示未附答案",
        },
        "solution": {
            "independent": False,
            "saw_reference": False,
            "system": None,
            "reference_frame": None,
            "stages": [],
            "sub_answers": [],
            "checks": [],
            "initial_positions": {},
            "comparison": {"status": "missing", "source": None, "diff_notes": None},
        },
        "review": {k: {"status": "未检查", "note": None, "evidence": [], "at": None, "fingerprint": None} for k in REVIEW_CHECKS},
    }


def applicable_reviews(rec: dict) -> tuple[str, ...]:
    """按交付模式与题图情况决定哪些审核项适用。

    第7轮把“来源答案”与“独立解题”拆开：
    - questions_only：只核来源/题面/必要图，不要求 answer/physics；
    - with_sourced_answers：加 answer（原件+逐空映射），不强制 independent/physics；
    - optional_explanations：再加 physics（自写推理的物理正确性）。
    没有题图时不要求 redraw；不适用的审核项显示为“不适用”，不能算已通过。
    """
    mode = get(rec, "delivery.mode")
    checks = ["source", "text"]
    if mode in ("with_sourced_answers", "optional_explanations"):
        checks.append("answer")
    if figures(rec):
        checks.append("redraw")
    if mode == "optional_explanations" or get(rec, "solution.independent") or get(rec, "solution.checks"):
        checks.append("physics")
    return tuple(checks)


ANSWER_NATURES = {"原卷参考答案", "转载参考答案", "平台解析", "未取得"}


def answer_block(rec: dict) -> dict:
    ans = get(rec, "answer")
    return ans if isinstance(ans, dict) else {}


def is_choice(rec: dict) -> bool:
    """选择题：有选项、没有小问。"""
    return bool((get(rec, "problem.options") or [])) and not subquestions(rec)


def answer_items(rec: dict) -> dict:
    return {str(i.get("label")): i for i in (answer_block(rec).get("items") or []) if isinstance(i, dict)}
