"""备用获取路径：用系统 curl 取公开页面/文件，并记录可核对的状态与哈希。

说明：这是 dsh-search-tools 抓取器不可用时的**备用**取证通道（本机 fake-IP DNS
使 web_fetch 的 SSRF 防护拒绝所有域名）。它不是搜索引擎，也不解析搜索结果页；
只按给定 URL 下载并留下 http 状态、最终 URL、内容类型、编码、字节数与 SHA256。
不发送 Cookie、不登录、不绕过验证码或付费墙。
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import paths

CST = timezone(timedelta(hours=8))
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def _detect_encoding(raw: bytes, header: str) -> str:
    low = raw[:4096].lower()
    if b"charset=gb" in low or b'charset="gb' in low:
        return "gb18030"
    if header and "charset=" in header.lower():
        return header.lower().split("charset=")[-1].split(";")[0].strip()
    try:
        raw.decode("utf-8")
        return "utf-8"
    except UnicodeDecodeError:
        return "gb18030"


def main(args) -> int:
    out = Path(args.out) if args.out else paths.LAB_ROOT / "sources" / (hashlib.sha256(args.url.encode()).hexdigest()[:12] + ".bin")
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["curl", "-sS", "-L", "--compressed", "-m", str(args.timeout), "-A", UA,
           "-A", UA, "-o", str(out), "-w", "%{http_code}\t%{url_effective}\t%{content_type}\t%{time_total}\t%{size_download}"]
    if args.referer:
        cmd[1:1] = ["-e", args.referer]
    proc = subprocess.run(cmd + [args.url], capture_output=True, text=True)
    if proc.returncode != 0:
        print(f"下载失败：{proc.stderr.strip() or proc.returncode}")
        return 2
    code, final_url, ctype, elapsed, size = (proc.stdout.strip().split("\t") + [""] * 5)[:5]
    raw = out.read_bytes()
    enc = _detect_encoding(raw, "")
    meta = {
        "requested_url": args.url,
        "final_url": final_url,
        "status": int(code or 0),
        "content_type": ctype,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "detected_encoding": enc,
        "seconds": float(elapsed or 0),
        "path": str(out),
        "at": datetime.now(CST).isoformat(timespec="seconds"),
        "via": "curl (备用获取路径；非搜索引擎，不发 Cookie，不绕登录)",
    }
    meta_path = out.with_suffix(out.suffix + ".meta.json")
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"http={meta['status']} bytes={meta['bytes']} enc={enc} {elapsed}s")
    print(f"  final: {final_url}")
    print(f"  saved: {paths.rel(out)}")
    print(f"  meta : {paths.rel(meta_path)}")
    return 0 if meta["status"] == 200 and meta["bytes"] > 0 else 1
