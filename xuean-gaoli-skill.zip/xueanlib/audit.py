"""PDF 输出检查：页面尺寸、字体嵌入、实际正文字号、文字可提取、空白页、栅格图。

区分机器可判定与需目视部分；不把“模板写了 11.5pt”当作实际输出合格。
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

from . import paths

A4_W, A4_H = 595.28, 841.89


def _embedded(font_obj) -> bool:
    try:
        obj = font_obj.get_object()
        desc = obj.get("/FontDescriptor")
        if desc is None:
            descs = obj.get("/DescendantFonts") or []
            for d in descs:
                d2 = d.get_object()
                desc = d2.get("/FontDescriptor")
                if desc is not None:
                    break
        if desc is None:
            return False
        desc = desc.get_object()
        return any(k in desc for k in ("/FontFile", "/FontFile2", "/FontFile3"))
    except Exception:
        return False


def _fonts(page) -> dict:
    out = {}
    try:
        resources = page.get("/Resources", {}) or {}
        fonts = resources.get("/Font", {}) or {}
        for name, ref in fonts.items():
            obj = ref.get_object()
            out[str(obj.get("/BaseFont"))] = {"embedded": _embedded(ref)}
    except Exception:
        pass
    return out


def _raster_images(page) -> int:
    count = 0
    try:
        xobj = (page.get("/Resources", {}) or {}).get("/XObject", {}) or {}
        for _, ref in xobj.items():
            o = ref.get_object()
            if str(o.get("/Subtype")) == "/Image":
                count += 1
    except Exception:
        pass
    return count


def _body_size(pdf_path: Path) -> tuple[float | None, dict]:
    """用 pdfplumber 的实际字符尺寸统计正文主字号。"""
    import pdfplumber

    sizes = Counter()
    detail = Counter()
    with pdfplumber.open(str(pdf_path)) as doc:
        for page in doc.pages:
            for ch in page.chars:
                size = round(float(ch.get("size", 0)), 1)
                if 6.0 <= size <= 24.0:
                    sizes[size] += 1
                    detail[size] += 1
    if not sizes:
        return None, {}
    mode = sizes.most_common(1)[0][0]
    return mode, dict(sorted(detail.items()))


def inspect(pdf_path, expect_body_pt: float = 11.5, render: bool = False, render_dir: Path | None = None) -> dict:
    from pypdf import PdfReader
    import pdfplumber

    pdf = Path(pdf_path)
    reader = PdfReader(str(pdf))
    pages = []
    all_fonts = {}
    total_chars = 0
    for i, page in enumerate(reader.pages, 1):
        w = round(float(page.mediabox.width), 2)
        h = round(float(page.mediabox.height), 2)
        text = page.extract_text() or ""
        total_chars += len(text)
        fonts = _fonts(page)
        all_fonts.update(fonts)
        pages.append(
            {
                "index": i,
                "width": w,
                "height": h,
                "a4": abs(w - A4_W) < 3 and abs(h - A4_H) < 3,
                "text_chars": len(text),
                "fonts": sorted(fonts),
                "raster_images": _raster_images(page),
            }
        )

    body_pt, size_hist = _body_size(pdf)
    body_ok = body_pt is not None and body_pt >= expect_body_pt - 0.1
    embedded_ok = bool(all_fonts) and all(v["embedded"] for v in all_fonts.values())

    warnings = []
    if body_pt is None:
        warnings.append("未统计到正文尺寸")
    if not embedded_ok:
        warnings.append("存在未嵌入字体")
    empty = [p["index"] for p in pages if p["text_chars"] < 5]
    if empty:
        warnings.append(f"疑似空白页：{empty}")
    big_raster = [p["index"] for p in pages if p["raster_images"] > 3]
    if big_raster:
        warnings.append(f"页内含较多栅格图（题图应为矢量）：{big_raster}")

    st = pdf.stat()
    result = {
        "audit_version": "xuean-audit/2",
        "pdf": str(pdf),
        "pdf_sha256": __import__("hashlib").sha256(pdf.read_bytes()).hexdigest(),
        "pdf_mtime_ns": st.st_mtime_ns,
        "at": __import__("datetime").datetime.now(
            __import__("datetime").timezone(__import__("datetime").timedelta(hours=8))
        ).isoformat(timespec="seconds"),
        "bytes": st.st_size,
        "page_count": len(pages),
        "pages": pages,
        "fonts": all_fonts,
        "fonts_embedded": embedded_ok,
        "body_pt_mode": body_pt,
        "expect_body_pt": expect_body_pt,
        "body_ok": body_ok,
        "size_histogram": size_hist,
        "text_chars": total_chars,
        "warnings": warnings,
    }

    if render:
        import pypdfium2 as pdfium

        out_dir = render_dir or (paths.LAB_ROOT / "runs" / "_render")
        out_dir.mkdir(parents=True, exist_ok=True)
        doc = pdfium.PdfDocument(str(pdf))
        renders = []
        try:
            for i in range(len(doc)):
                bmp = doc[i].render(scale=2.0)
                im = bmp.to_pil()
                out = out_dir / f"page-{i+1}.png"
                im.save(out)
                renders.append(str(out))
                result["pages"][i]["render"] = str(out)
        finally:
            doc.close()
        result["renders"] = renders
    return result


def print_report(res: dict) -> bool:
    print(f"PDF 审计：{res['pdf']}")
    print(f"  页数 {res['page_count']}  字节 {res['bytes']}  可提取文字 {res['text_chars']} 字符")
    bad_pages = [p for p in res["pages"] if not p["a4"]]
    print(f"  A4 页面：{'全部合格' if not bad_pages else '不合格页 ' + str([p['index'] for p in bad_pages])}")
    print(f"  字体嵌入：{'是' if res['fonts_embedded'] else '否'} → {sorted(res['fonts'])}")
    print(f"  正文字号：mode={res['body_pt_mode']} pt（要求 ≥ {res['expect_body_pt']}）→ {'合格' if res['body_ok'] else '不合格'}")
    for w in res["warnings"]:
        print(f"  [警告] {w}")
    ok = res["fonts_embedded"] and res["body_ok"] and not bad_pages and res["page_count"] > 0
    print("  结论：" + ("机器检查通过（视觉/内容仍需人工核对）" if ok else "机器检查不合格"))
    return ok


def main(args) -> int:
    rd = paths.run_dir(args.run) if args.run else None
    res = inspect(
        args.pdf,
        expect_body_pt=args.expect_body_pt,
        render=bool(rd),
        render_dir=rd / "pages" if rd else None,
    )
    ok = print_report(res)
    if rd:
        (rd / "audit.json").write_text(json.dumps(res, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"  审计记录：{paths.rel(rd / 'audit.json')}")
    return 0 if ok else 1
