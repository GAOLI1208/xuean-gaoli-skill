"""Portable path resolution for the xuean-gaoli release.

The package root is inferred from this file.  Optional DSH paths are only
read from environment variables; no host account path is hard-coded.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

LAB_ROOT = Path(os.environ.get("XUEAN_HOME") or Path(__file__).resolve().parent.parent).resolve()
WORKSPACE = Path(os.environ.get("XUEAN_WORKSPACE") or LAB_ROOT.parent).resolve()


def _env_path(name: str) -> Path | None:
    value = os.environ.get(name, "").strip()
    return Path(value).expanduser().resolve() if value else None


# DSH application integration is optional; the standalone CLI does not need it.
DSH_PYTHON = _env_path("DSH_PYTHON")
DSH_NODE = _env_path("DSH_NODE")
DSH_CLI = _env_path("DSH_CLI")
DESKTOP_PROFILE = _env_path("DSH_PROFILE")

# The installer-created environment is the normal runtime.
LAB_PYTHON = Path(os.environ.get("XUEAN_PYTHON") or LAB_ROOT / ".venv" / "bin" / "python")
VENV_PYTHON = LAB_PYTHON

# System fonts are platform dependencies, not bundled binaries.
FONT_DIRS = [
    LAB_ROOT / "fonts",
    Path("/System/Library/Fonts/Supplemental"),
    Path("/System/Library/Fonts"),
    Path("/Library/Fonts"),
    Path.home() / "Library" / "Fonts",
]
SONGTI = Path(os.environ.get("XUEAN_SONGTI") or "/System/Library/Fonts/Supplemental/Songti.ttc")

DIRS = {
    "scripts": LAB_ROOT / "scripts",
    "templates": LAB_ROOT / "templates",
    "fixtures": LAB_ROOT / "fixtures",
    "sources": LAB_ROOT / "sources",
    "runs": LAB_ROOT / "runs",
    "reports": LAB_ROOT / "reports",
    "env": LAB_ROOT / "environment.json",
    "state": LAB_ROOT / "STATE.md",
    "cache": LAB_ROOT / ".cache",
}


def ensure_dirs() -> None:
    for key in ("scripts", "templates", "fixtures", "sources", "runs", "reports", "cache"):
        DIRS[key].mkdir(parents=True, exist_ok=True)


def load_environment() -> dict:
    try:
        return json.loads(DIRS["env"].read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}


def run_dir(run_id: str) -> Path:
    p = DIRS["runs"] / run_id
    p.mkdir(parents=True, exist_ok=True)
    return p


def rel(p) -> str:
    p = Path(p).resolve()
    try:
        return str(p.relative_to(LAB_ROOT))
    except ValueError:
        return str(p)


def env_flag(name: str, default: str = "") -> str:
    return os.environ.get(name, default)
