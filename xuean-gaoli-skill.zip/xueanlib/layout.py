"""Typst 排版：同一份题目数据生成正文、题号、来源索引；QA 核对页单独成册。

约定：题干/解析/小问文本直接写 Typst markup（行内公式用 $...$），
不另写数学字符串解析器；LaTeX 残留由 validate 拦截。

第 2 轮修复：
- 每题独立资产命名空间（fig-<id>.svg / evidence-<id>.png），合册不再互相覆盖；
- 来源索引用正常宽度条目（长 URL 可断行 + 可点击），不再塞进窄表格导致重叠；
- 内部核图/证据页输出为独立 QA PDF，正式教学 PDF 只含题目（+ 需要的答案）；
- 预览一律 DRAFT，题源/审核缺口直接印在页面上，不用“看起来正常”掩盖。
"""

from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import answers, fingerprint, models, paths, provenance, validate

CST = timezone(timedelta(hours=8))
BASE = paths.LAB_ROOT / "templates" / "xuean_base.typ"


def esc(text) -> str:
    """普通文本转义为 Typst content（只用于非公式字段）。"""
    s = str(text if text is not None else "")
    for ch in ("\\", "#", "$", "*", "_", "`", "<", ">", "@", "[", "]", "~"):
        s = s.replace(ch, "\\" + ch)
    return s


def stage_label(rec: dict) -> str:
    return models.get(rec, "stage", "") or "未标学段"


def review_flags(rec: dict) -> dict:
    return fingerprint.review_state(rec)


def delivery_mode(rec: dict) -> str:
    mode = models.get(rec, "delivery.mode")
    return str(mode).strip() if mode is not None else ""


def literal_tilde(text) -> str:
    """正文里的 ~ 是范围号，不是 Typst 不断行空格；数学段内保持原样。"""
    parts = re.split(r"(\$[^$]*\$)", str(text or ""))
    return "".join(p if p.startswith("$") else p.replace("~", "\\~") for p in parts)


def display_note(text) -> str:
    """教学页只放老师需要的信息；内部 selector、本地路径和 URL 不进正文。"""
    s = str(text or "")
    s = re.sub(r"(?:div|section|td|span|p)\.[A-Za-z0-9_.#-]+", "", s)
    s = re.sub(r"(?:sources|runs|records|templates)/[^\s，。；;]+", "", s)
    s = re.sub(r"(?<![\w:])/(?:[^/\s]+/){2,}[^\s，。；;]+", "", s)
    s = re.sub(r"https?://[^\s，。；;]+", "", s)
    s = re.sub(r"（?平台题ID[^）)]*）?", "", s)
    s = re.sub(r"\bbank_id\b", "", s)
    s = re.sub(r"[ \t]+", " ", s).strip(" ，。；;·")
    return s


def answer_text_value(v) -> str:
    # 答案原文里的 ~ 在 Typst 中是不断行空格，必须转义，不能静默丢符号。
    return str(v or "").replace("~", "\\~")


def _exam_display(ident: dict) -> str:
    name = str(ident.get("exam_name") or "")
    year = str(ident.get("exam_year") or "")
    if year and name.startswith(year + "年"):
        name = name[len(year) + 1:]
    return name


def _year_display(ident: dict) -> str:
    label = str(ident.get("exam_year_label") or "").strip()
    if label:
        return label
    year = ident.get("exam_year")
    if year not in (None, ""):
        return f"{year} 年"
    return "年份未标"


def _url_display(url) -> str:
    u = str(url or "")
    if u.startswith("file://"):
        return "本地来源：" + Path(u).name
    return u


def _ans(rec: dict, sub: dict) -> str:
    """答案文本：优先小问自带 answer，其次 solution.sub_answers。"""
    if (sub.get("answer") or "").strip():
        return sub["answer"]
    for a in models.get(rec, "solution.sub_answers", []) or []:
        if a.get("label") == sub.get("label") and (a.get("result") or "").strip():
            return a["result"]
    return ""


def _figure_block(rec: dict, workdir: Path, anchor: str = "stem") -> list[str]:
    all_figs = models.figures(rec)
    picked = [(i + 1, f) for i, f in enumerate(all_figs) if (f.get("after") or "stem") == anchor]
    if not picked:
        return []
    out = []
    for k, fig in picked:
        out.extend(_one_figure_block(rec, workdir, fig, k))
    return out


def _one_figure_block(rec: dict, workdir: Path, fig: dict, k: int) -> list[str]:
    rid = rec.get("id") if len(models.figures(rec)) == 1 else f"{rec.get('id')}-f{k}"
    asset = fig.get("asset_path")
    out = []
    if asset:
        a_src = Path(asset)
        if not a_src.is_absolute():
            a_src = paths.LAB_ROOT / a_src
        if a_src.exists():
            a_name = f"asset-{rid}{a_src.suffix.lower()}"
            shutil.copy2(a_src, workdir / a_name)
            width = fig.get("display_width", "62%")
            cap = display_note(fig.get("source_note") or "原题图（取自公开原卷/转载的图形区域）")
            out.append(f"#figure(image(\"{a_name}\", width: {width}), caption: [{esc(fig.get('role'))} · {esc(cap)}], supplement: [图])")
            return out
        out.append(f"#meta[题图资产缺失：{esc(asset)}]")
        return out
    if not fig.get("svg_path"):
        return out
    svg_src = Path(fig["svg_path"])
    if not svg_src.is_absolute():
        svg_src = paths.LAB_ROOT / svg_src
    if svg_src.exists():
        name = f"fig-{rid}.svg"
        shutil.copy2(svg_src, workdir / name)
        width = fig.get("display_width", "55%")
        out.append(f"#figure(image(\"{name}\", width: {width}), caption: [{esc(fig.get('role'))} · 据原题重绘], supplement: [图])")
    else:
        out.append(f"#meta[题图缺失（{esc(fig.get('role') or '—')}），不得作为正式题交付]")
    return out


def _options_block(rec: dict) -> list[str]:
    opts = models.get(rec, "problem.options", []) or []
    if not opts:
        return []
    lines = ["#grid(columns: 2, gutter: 1em,"]
    for i, opt in enumerate(opts):
        label = opt.get("label") if isinstance(opt, dict) else chr(65 + i)
        text = opt.get("text") if isinstance(opt, dict) else str(opt)
        lines.append(f"  [{esc(label)}．{literal_tilde(text)}],")
    lines.append(")")
    return ["\n".join(lines)]


_ANSWER_WORKDIR = [None]


def _answer_block(rec: dict) -> list[str]:
    subs = models.subquestions(rec)
    mode = delivery_mode(rec)
    ans_block = models.answer_block(rec)
    requested = str(models.get(rec, "delivery.requested_mode") or "").strip()
    display = models.get(rec, "delivery.display_answers")
    out = []
    if mode == "questions_only" or requested == "questions_only" or display is False:
        out.append("#block(above: 0.4em)[#meta[本题未附答案（题目版）：答案与讲解按需另出。]]")
        return out
    nature = esc(ans_block.get("nature") or "答案性质未标")
    loc = esc(display_note(ans_block.get("locator") or ""))
    out.append("#block(breakable: false)[")
    out.append("#heading(level: 3)[参考答案]")
    out.append("#block(spacing: 0.35em)[")
    blocks = answers.display_blocks(rec)
    used_figs: set[str] = set()
    if blocks:
        for b in blocks:
            label = esc(b.get("label") or "")
            val = literal_tilde(b.get("text") or "（未取得）")
            out.append(f"  #block[#text(weight: \"bold\")[{label}] {val}]")
            fp = b.get("figure")
            if fp:
                src = Path(fp)
                if not src.is_absolute():
                    src = paths.LAB_ROOT / src
                if src.exists():
                    nm = f"answer-{rec.get('id')}-{len(used_figs)+1}{src.suffix.lower()}"
                    shutil.copy2(src, _ANSWER_WORKDIR[0] / nm)
                    used_figs.add(str(src.resolve()))
                    out.append(f"  #figure(image(\"{nm}\", width: 72%), caption: [答案图], supplement: [图])")
                else:
                    out.append(f"  #meta[答案图缺失：{esc(src.name)}]")
    else:
        items = models.answer_items(rec)
        if models.is_choice(rec):
            val = literal_tilde((items.get("答案") or {}).get("answer") or "（未取得）")
            out.append(f"  #block[答案：#text(weight: \"bold\")[{val}]]")
        else:
            for sub in subs:
                item = items.get(str(sub.get("label"))) or {}
                val = literal_tilde(item.get("answer") or _ans(rec, sub) or "（未取得）")
                out.append(f"  #block[#text(weight: \"bold\")[{esc(sub.get('label'))}] {val}]")
    out.append("]")
    # 旧记录/全局答案图：mapping 没引用到的仍显示，但不能重复。
    ans_figs = ans_block.get("figures") or ([ans_block.get("figure")] if ans_block.get("figure") else [])
    for i, fig in enumerate([f for f in ans_figs if isinstance(f, dict)], 1):
        fp = fig.get("asset_path") or fig.get("path")
        if not fp:
            continue
        src = Path(fp)
        if not src.is_absolute():
            src = paths.LAB_ROOT / src
        if not src.exists():
            out.append(f"#meta[答案图缺失：{esc(src.name)}]")
            continue
        if str(src.resolve()) in used_figs:
            continue
        nm = f"answer-{rec.get('id')}-global-{i}{src.suffix.lower()}"
        shutil.copy2(src, _ANSWER_WORKDIR[0] / nm)
        used_figs.add(str(src.resolve()))
        out.append(f"#figure(image(\"{nm}\", width: 72%), caption: [{esc(fig.get('caption') or '答案附图')}], supplement: [图])")
    out.append(f"#meta[答案性质：{nature}{('　来源：' + loc) if loc else ''}。此为来源答案原文，非本轮自写解析。]")
    out.append("]")
    if mode == "optional_explanations" and models.get(rec, "solution.stages"):
        out.append("#heading(level: 3)[讲解]")
        sol = models.get(rec, "solution", {}) or {}
        if sol.get("system"):
            out.append(f"- 系统：{esc(sol['system'])}；参考系/正方向：{esc(sol.get('reference_frame') or '—')}")
        for st in sol.get("stages", []) or []:
            out.append(f"- {esc(st.get('name') or '')}：{esc(st.get('law') or '')}")
    return out


def _subquestions_block(rec: dict) -> list[str]:
    subs = models.subquestions(rec)
    out = ["#block(spacing: 0.5em)["]
    for sub in subs:
        out.append(f"  #block[#text(weight: \"bold\")[{esc(sub.get('label'))}] {sub.get('text', '')}]")
        out.append("  #block(height: 2.2cm)[]")
    out.append("]")
    return out


def _has_figures_after(rec: dict) -> list[str]:
    return [f.get("after") for f in models.figures(rec) if f.get("after") and f.get("after") != "stem"]


def _header_block(rec: dict, idx: int) -> list[str]:
    """教学页题头：只放老师需要的考试信息；审核状态、取得时间、内部路径一律进 QA。"""
    ident = models.get(rec, "identity", {}) or {}
    points = ident.get("points") or models.get(rec, "teaching.points")
    pt = f"（{points} 分）" if points else ""
    out = ["#heading(level: 2)[", f"第 {idx} 题　{esc(models.get(rec, 'teaching.topic') or '')}{esc(pt)}", "]", "#meta["]
    out.append(
        f"  {_year_display(ident)}　{esc(ident.get('region') or '—')}　{esc(_exam_display(ident) or '—')}　"
        f"原卷题号 {esc(display_note(ident.get('original_number')) or '未核实')}"
    )
    out.append("]")
    out.append("#rule")
    return out


def _is_real(rec: dict) -> bool:
    """只有证据支持真实考试属性时才允许“真实考试题”页头。"""
    return (
        bool(models.get(rec, "source.retrieved_at"))
        and models.get(rec, "source.publication_type") in ("第一方", "完整转载")
        and models.get(rec, "source.status") == "通过"
        and models.get(rec, "status") == "通过"
        and models.get(rec, "source.material_type") == "exam"
    )


def document(records: list[dict], workdir: Path, draft: bool = False) -> str:
    """正式教学用文档：只有题目（按模式附答案），不含内部证据/核图材料。"""
    head = BASE.read_text(encoding="utf-8")
    lines = [head]
    stage = " / ".join(sorted({stage_label(r) for r in records}))
    topics = "；".join(models.get(r, "teaching.topic") or "未标专题" for r in records)
    if all(_is_real(r) for r in records):
        qualified = "（真实考试题）"
    elif all(models.get(r, "source.material_type") == "homework" for r in records):
        qualified = "（来源练习）"
    elif all(models.get(r, "source.material_type") == "question_bank" for r in records):
        qualified = "（题库整理）"
    else:
        qualified = ""
    lines.append(f'#align(center)[#text(size: 18pt, weight: "bold")[物理教学学案{qualified}]]')
    lines.append(f'#align(center)[#meta[{esc(stage)} · {esc(topics)}]]')
    lines.append(f'#align(center)[#meta[能力测试小样 · 生成于 {datetime.now(CST).strftime("%Y-%m-%d %H:%M")}]]')
    if draft:
        lines.append('#align(center)[#text(size: 12pt, fill: rgb("#b00000"), weight: "bold")[DRAFT 草稿：存在未通过准入项，仅作预览]]')
    pending = [r for r in records if models.get(r, "status") != "通过" or models.get(r, "source.status") != "通过"]
    if pending:
        names = "、".join(models.get(r, "id") or "?" for r in pending)
        lines.append(
            f'#align(center)[#text(size: 10.5pt, fill: rgb("#8a4b00"))[候选（待核实）：{esc(names)} —— 题源未通过，仅供内部核对，不得当作真题使用]]'
        )
    lines.append("")
    last_stage = None
    multi_stage = len({stage_label(r) for r in records}) > 1
    for idx, rec in enumerate(records, 1):
        stage_now = stage_label(rec)
        if multi_stage and stage_now != last_stage:
            lines.append(f"#heading(level: 1)[{esc(stage_now)}]")
            last_stage = stage_now
        head = _header_block(rec, idx)
        stem = literal_tilde(models.get(rec, "problem.stem", "") or "")
        # 标题/题头与不太长的首段绑在一起，避免“第 N 题”标题孤零零留在页底。
        if len(stem) <= 420:
            lines.append("#block(breakable: false)[")
            lines.extend(head)
            lines.append("")
            lines.append(stem)
            lines.append("]")
        else:
            lines.extend(head)
            lines.append("")
            lines.append(stem)
        lines.append("")
        lines.extend(_options_block(rec))
        for i, opt in enumerate(models.get(rec, "problem.options", []) or []):
            label = opt.get("label") if isinstance(opt, dict) else chr(65 + i)
            lines.extend(_figure_block(rec, workdir, f"option:{label}"))
        lines.extend(_figure_block(rec, workdir, "stem"))
        for sub in models.subquestions(rec):
            label = esc(sub.get("label"))
            body = literal_tilde(sub.get("text", "") or "")
            anchor = f"sub:{sub.get('label')}"
            extra = _figure_block(rec, workdir, anchor)
            if extra and "§FIG§" in body:
                before, _, after = body.partition("§FIG§")
                lines.append(f"#block(spacing: 0.4em)[#text(weight: \"bold\")[{label}] {before}]")
                lines.extend(extra)
                if after.strip():
                    lines.append(f"#block(above: 0.3em)[{after}]")
            elif extra and len(body) <= 260:
                # 短小问与紧随其后的图放在同一个不可分块，避免图跑到下一页。
                lines.append("#block(breakable: false)[")
                lines.append(f"#block(spacing: 0.4em)[#text(weight: \"bold\")[{label}] {body}]")
                lines.extend(extra)
                lines.append("]")
            else:
                lines.append(f"#block(spacing: 0.4em)[#text(weight: \"bold\")[{label}] {body}]")
                if extra:
                    lines.extend(extra)
            lines.append("#block(height: 0.8cm)[]")
        lines.extend(_answer_block(rec))
        if idx != len(records):
            lines.append("#v(0.6em)")
            lines.append("#heading(level: 1)[—— 下一题 ——]")
        lines.append("")

    lines.append("#v(1.2em)")
    lines.append("#heading(level: 1)[来源索引]")
    lines.append("#meta[同一份题目数据生成；每条给出年份、考试名称、原卷题号、材料性质与可点击来源。]")
    lines.append("")
    for idx, rec in enumerate(records, 1):
        ident = models.get(rec, "identity", {}) or {}
        src = models.get(rec, "source", {}) or {}
        st = review_flags(rec)
        applicable = set(models.applicable_reviews(rec))
        ok = all(v["state"] == "ok" for k, v in st.items() if k in applicable)
        evs = src.get("evidence") or []
        lines.append("#block(above: 1em, below: 1em)[")
        region = str(ident.get("region") or "")
        exam_name = _exam_display(ident)
        full = exam_name if region and region in exam_name else f"{region} {exam_name}".strip()
        lines.append(
            f"#text(weight: \"bold\")[第 {idx} 题]　{esc(_year_display(ident) + ' ' + full)}　"
            f"原卷题号 {esc(display_note(ident.get('original_number')) or '未核实')} #linebreak()"
        )
        lines.append(
            f"#text(size: 10.5pt)[{esc(src.get('publisher') or '未记')}　材料性质：{esc(src.get('publication_type') or '未标')}] #linebreak()"
        )
        for url in (src.get("urls") or [])[:2]:
            u = str(url)
            if u.startswith("file://"):
                # Typst 的 file:// 链接标签会被 // 注释解析吞掉；本地来源只显示文件名。
                lines.append(f"#text(size: 11.5pt)[本地来源：{esc(Path(u).name)} #linebreak()]")
            else:
                lines.append(f"#text(size: 11.5pt)[#link(\"{u}\")[{esc(u)}] #linebreak()]")
        lines.append("]")
    lines.append("")
    lines.append("#meta[说明：本学案为能力测试小样，不代表同一学生的授课顺序；答案性质（原卷参考答案／转载参考答案）已逐题标注。]")
    return "\n".join(lines)


def qa_document(records: list[dict], workdir: Path) -> str:
    """内部 QA 材料：原图证据 vs 重绘并排、图形关系清单、来源与哈希。独立成册，不进教学 PDF。"""
    head = BASE.read_text(encoding="utf-8")
    lines = [head, "#align(center)[#text(size: 16pt, weight: \"bold\")[内部核图/证据核对（QA，不随教学学案发放）]]", ""]
    for idx, rec in enumerate(records, 1):
        rid = rec.get("id")
        fig = models.figure(rec) or {}
        rel = fig.get("relations") or {}
        ident = models.get(rec, "identity", {}) or {}
        src = models.get(rec, "source", {}) or {}
        lines.append(f"#heading(level: 2)[第 {idx} 题 · {esc(rid)}]")
        first_url = (src.get("urls") or ["—"])[0]
        lines.append(
            f"#meta[{esc(str(ident.get('exam_year') or '—'))} {esc(ident.get('region') or '')} {esc(ident.get('exam_name') or '')}　"
            f"原卷题号 {esc(ident.get('original_number') or '—')}　来源 {esc(_url_display(first_url))}]"
        )
        if fig:
            lines.append(f"#meta[图号 {esc(fig.get('figure_no') or '—')}　角色 {esc(fig.get('role'))}　{esc(rel.get('redraw_note') or fig.get('source_note') or '')}]")
            ev = Path(fig.get("evidence_path") or "")
            if not ev.is_absolute():
                ev = paths.LAB_ROOT / ev
            ev_name = f"evidence-{rid}.png"
            ev_copied = False
            all_figs = models.figures(rec)
            single = len(all_figs) == 1
            for k, figk in enumerate(all_figs, 1):
                ridk = rid if single else f"{rid}-f{k}"
                used = None
                for nm in (f"asset-{ridk}.png", f"asset-{ridk}.jpg", f"fig-{ridk}.svg"):
                    if (workdir / nm).exists():
                        used = nm
                        break
                lines.append("#grid(columns: (1fr, 1fr), gutter: 1em,")
                if ev.exists() and not ev_copied and ev.suffix.lower() in (".png", ".jpg", ".jpeg"):
                    shutil.copy2(ev, workdir / ev_name)
                    ev_copied = True
                    lines.append(f"  [#figure(image(\"{ev_name}\", width: 100%), caption: [原图证据/整页 p.{esc(str(figk.get('asset_crop', {}).get('page') or ''))}], supplement: [图])],")
                else:
                    label = "（同一页证据，见上）" if ev_copied else f"（证据为非图片文件：{esc(ev.name)}，见下列证据清单）"
                    lines.append(f"  [{label}],")
                if used:
                    cap = "实际使用图（原卷图形区域）" if used.startswith("asset-") else "据原题重绘"
                    lines.append(f"  [#figure(image(\"{used}\", width: 100%), caption: [{cap} · {esc(figk.get('figure_no') or '')}], supplement: [图])],")
                else:
                    lines.append(f"  [使用图缺失：{esc(figk.get('figure_no') or '')}],")
                lines.append(")")
            rows = [
                ("初始左右/上下", "; ".join(f"{o.get('id')} 在 {o.get('ref')} 的 {o.get('side')}" for o in (rel.get("objects") or []) if o.get("ref")) or str(rel.get("layout") or "—")),
                ("连接与接触", "; ".join(str(x) for x in (rel.get("connections") or [])) or "—"),
                ("标签", "、".join(str(x) for x in (rel.get("labels") or [])) or "—"),
                ("时间标签", "、".join(str(x) for x in (rel.get("time_labels") or [])) or "—"),
                ("未决问题", "; ".join(str(x) for x in (rel.get("open_issues") or [])) or "无"),
            ]
            lines.append("#table(columns: (auto, 1fr), stroke: 0.4pt, [核对项], [记录],")
            for k, v in rows:
                lines.append(f"  [{esc(k)}], [{esc(v)}],")
            lines.append(")")
        for ev_item in src.get("evidence") or []:
            lines.append(
                f"#meta[证据 {esc(str(ev_item.get('path')))}　sha256 {esc(str(ev_item.get('sha256') or '未记')[:32])}…　"
                f"p.{esc(str(ev_item.get('page')))}　{esc(ev_item.get('selector') or '')}]"
            )
        lines.append("#meta[原图与重绘逐项核对：标签、左右关系、连接、曲线朝向、箭头与刻度。图看不清不得猜。]")
        lines.append("#pagebreak()")
    return "\n".join(lines)


def compile_typst(src: Path, out_pdf: Path) -> dict:
    import typst

    started = datetime.now(CST)
    typst.compile(
        str(src),
        output=str(out_pdf),
        root=str(src.parent),
        font_paths=[str(p) for p in paths.FONT_DIRS if p.exists()],
    )
    elapsed = (datetime.now(CST) - started).total_seconds()
    return {"pdf": str(out_pdf), "bytes": out_pdf.stat().st_size, "seconds": round(elapsed, 2)}


def prepare(record_paths: list[Path], run_dir: Path, draft: bool, mode: str, with_qa: bool = True) -> dict:
    recs = [json.loads(Path(p).read_text(encoding="utf-8")) for p in record_paths]
    all_issues = {r["id"]: validate.collect(r) for r in recs}
    blocks = {rid: [i for i in iss if i["level"] == "block"] for rid, iss in all_issues.items()}
    attempt_path = provenance.build_attempt(run_dir, recs, all_issues, mode, draft)
    blocked_ids = [rid for rid, bl in blocks.items() if bl]
    if blocked_ids and not draft:
        for rid in blocked_ids:
            for b in blocks[rid]:
                print(f"  [阻断] {rid} {b['code']}: {b['message']}")
        raise SystemExit("准入未通过：阻塞题不进正式成品（可用 --draft 预览）")

    work = run_dir / "build" / mode
    work.mkdir(parents=True, exist_ok=True)
    for r in recs:
        (work / f"rec-{r['id']}.json").write_text(json.dumps(r, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    _ANSWER_WORKDIR[0] = work
    main_src = work / "main.typ"
    main_src.write_text(document(recs, work, draft=draft), encoding="utf-8")
    stem = recs[0]["id"] if len(recs) == 1 else f"{mode}-{len(recs)}questions"
    out = run_dir / f"{stem}.{mode}.pdf"
    info = compile_typst(main_src, out)
    result = {
        "records": recs,
        "pdf": str(out),
        "workdir": str(work),
        "draft": draft,
        "blocked": {rid: [b["code"] for b in bl] for rid, bl in blocks.items() if bl},
        "attempt": attempt_path,
        **info,
    }
    if with_qa:
        qa_src = work / "qa.typ"
        qa_src.write_text(qa_document(recs, work), encoding="utf-8")
        qa_pdf = run_dir / f"{stem}.qa.pdf"
        info2 = compile_typst(qa_src, qa_pdf)
        result["qa_pdf"] = info2["pdf"]
        result["qa_seconds"] = info2["seconds"]
    return result


def main(args, mode: str) -> int:
    run_id = args.run or datetime.now(CST).strftime("%Y%m%d-%H%M%S") + f"-{mode}"
    rd = paths.run_dir(run_id)
    record_paths = args.record if isinstance(args.record, list) else [args.record]
    draft = mode == "preview" or bool(getattr(args, "draft", False))
    result = prepare(record_paths, rd, draft=draft, mode=mode, with_qa=not getattr(args, "no_qa", False))
    print(f"{'预览' if mode=='preview' else '生成'}完成：{paths.rel(result['pdf'])}（{result['bytes']} bytes，{result['seconds']} s）")
    if result.get("qa_pdf"):
        print(f"  内部 QA 核对册：{paths.rel(result['qa_pdf'])}（不随教学学案发放）")
    if result["blocked"]:
        print(f"  注意：{len(result['blocked'])} 题含阻断项，仅作 DRAFT 预览")
    (rd / "build.json").write_text(
        json.dumps(
            {
                "run": run_id,
                "mode": mode,
                "records": [str(p) for p in record_paths],
                "pdf": str(result["pdf"]),
                "qa_pdf": result.get("qa_pdf"),
                "seconds": result["seconds"],
                "draft": draft,
                "blocked": result["blocked"],
                "attempt": result.get("attempt"),
                "at": datetime.now(CST).isoformat(timespec="seconds"),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return 0
