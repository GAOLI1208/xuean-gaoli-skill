"""来源链、HTML/DOM 图文声明与首测留存。

这里只做站点无关的最小契约：
- 保存实际 HTML 的 hash/final URL/DOM 统计；
- 识别常见 img 懒加载字段与相对 URL；
- 把“题干声明图/图线/坐标系”转成可阻断的声明；
- 派生摘录必须链回原文件/hash/selector，不能自证完整；
- 首次导入快照只写一次，后续映射/审核不覆盖。
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Tag

IMAGE_ATTRS = (
    "data-src", "data-lazysrc", "data-original", "data-original-src",
    "data-lazy-src", "data-lazy", "data-echo", "data-actualsrc",
    "data-url", "src",
)
# 只认“题面是否引用已有图”的通用措辞，不写任何物理公式/变量组合。
# strong：明确指向已有图（如图/图中/图线/图甲…）；generic：图像/坐标/曲线等上下文。
FIG_STRONG_RE = re.compile(
    r"(?:如(?:下|上)?图(?:所示)?|见图|图中|图线|图示|图[甲乙丙丁A-Da-d1-9]|"
    r"图\s*\d+|下列(?:图|图像|图象)|上(?:图|图所示)|下(?:图|图所示)|左图|右图)"
)
FIG_GENERIC_RE = re.compile(
    r"(?:图像|图象|示意图|波形图|状态图|曲线图|坐标系|坐标轴|横坐标|纵坐标|"
    r"曲线(?!运动))"
)
# “画/作出/补全”类要求：只说明学生要自己画，不能据此要求原题已有图。
DRAW_RE = re.compile(
    r"(?:请|试|要求|需要|在.{0,20}中)?(?:画出|作出|画|作|补全|完成).{0,80}"
    r"(?:图|像|曲线|坐标|力臂|光路|电路|绕线|轨迹)"
)


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def image_src_tag(tag: Tag) -> str:
    """取图片实际地址；懒加载优先于答题页的占位 src。"""
    for key in IMAGE_ATTRS:
        val = str(tag.get(key) or "").strip()
        if val and not val.startswith("data:") and not val.lower().startswith("about:"):
            return val
    for key in ("srcset", "data-srcset"):
        srcset = str(tag.get(key) or "").strip()
        if srcset:
            return srcset.split(",")[0].strip().split(" ")[0]
    return ""


def resolve_url(src: str, page_url: str) -> str:
    if not src:
        return ""
    if src.startswith("//"):
        return "https:" + src
    if src.startswith(("http://", "https://", "file://")):
        return src
    return urljoin(page_url, src) if page_url else src


def analyze_html(html_path, page_url: str, selector: str = "section.quesborder, div.quesborder") -> dict:
    """对实际 HTML 做可复核的 DOM 统计；不解释题目，不生成内容。"""
    p = Path(html_path)
    raw = p.read_text("utf-8", "replace")
    soup = BeautifulSoup(raw, "html.parser")
    scopes = soup.select(selector) if selector else []
    scope = scopes[0] if scopes else None
    imgs = scope.find_all("img") if scope is not None else []
    records = []
    for img in imgs:
        raw_src = image_src_tag(img)
        records.append({
            "src_raw": raw_src,
            "src": resolve_url(raw_src, page_url) if raw_src else "",
            "attrs": {k: str(img.get(k)) for k in IMAGE_ATTRS if img.get(k)},
            "class": img.get("class") or [],
        })
    text = scope.get_text("\n", strip=True) if scope is not None else soup.get_text("\n", strip=True)
    return {
        "html_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "final_url": page_url,
        "selector": selector,
        "scope_count": len(scopes),
        "declared_images": len(imgs),
        "usable_images": sum(1 for x in records if x["src"]),
        "missing_src": sum(1 for x in records if not x["src"]),
        "lazy_attrs": sorted({k for x in records for k in x["attrs"] if k.startswith("data-")}),
        "images": records,
        "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "text_chars": len(text),
    }


def figure_claims(text: str) -> list[str]:
    """返回题干中“引用已有图”的措辞；不写具体变量/公式。

    规则：
    - 明确引用已有图（如图/图中/图线/图甲/下列图…）→ 要求图片证据；
    - 只有“图像/坐标/曲线”等通用上下文且没有画图要求 → 要求图片证据；
    - 只有“请画出/作出/补全…”且没有引用已有图 → 是学生作图，不要求原题有图；
    - “曲线运动”等概念词不算图。
    无法判断时由 validate 的图声明/原始 DOM 规则保守处理，不靠猜。
    """
    s = str(text or "")
    strong = {m.group(0) for m in FIG_STRONG_RE.finditer(s)}
    generic = {m.group(0) for m in FIG_GENERIC_RE.finditer(s)}
    draw = bool(DRAW_RE.search(s))
    if strong:
        return sorted(strong | (generic if not draw else set()))
    if generic and not draw:
        return sorted(generic)
    return []


def material_type(exam_type, explicit=None) -> str:
    """把考试/练习来源性质写成通用枚举；不猜具体年份/地区。"""
    if explicit in ("exam", "homework", "question_bank", "textbook", "unknown"):
        return explicit
    t = str(exam_type or "")
    if any(k in t for k in ("中考", "高考", "一模", "二模", "三模", "期末", "期中",
                            "月考", "阶段检测", "联考", "调研", "真题", "模拟")):
        return "exam"
    if "作业" in t or "练习" in t:
        return "homework"
    if "题库" in t:
        return "question_bank"
    if "教材" in t or "课本" in t:
        return "textbook"
    return "unknown"


def original_chain(path, url: str = "", selector: str = "") -> dict:
    p = Path(path) if path else None
    if not p or not p.exists():
        return {"path": str(path) if path else "", "exists": False, "sha256": "", "url": url,
                "selector": selector, "dom": {}}
    return {"path": str(p), "exists": True, "sha256": sha256_file(p), "url": url,
            "selector": selector}


def first_snapshot(records_dir, rec_id: str, rec: dict) -> str:
    """首次导入快照只写一次；后续 import/review/promote 不得覆盖。"""
    d = Path(records_dir) / "first"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{rec_id}.json"
    if not p.exists():
        p.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return str(p)


def build_attempt(run_dir, records: list[dict], issues: dict, mode: str, draft: bool) -> str:
    """保存每次构建尝试（含阻断项）；第一次失败不会因后续成功而消失。"""
    d = Path(run_dir) / "build-attempts"
    d.mkdir(parents=True, exist_ok=True)
    n = 1
    while (d / f"attempt-{n:02d}.json").exists():
        n += 1
    payload = {
        "attempt": n,
        "mode": mode,
        "draft": draft,
        "records": [{"id": r.get("id"), "sha256": hashlib.sha256(
            json.dumps(r, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()} for r in records],
        "issues": {rid: [{"code": i.get("code"), "level": i.get("level"), "message": i.get("message")}
                         for i in iss] for rid, iss in issues.items()},
        "at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    p = d / f"attempt-{n:02d}.json"
    p.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return str(p)
