"""第5轮：保真导入（HTML 题库页 / 原卷扫描页）→ 统一题记录。

设计约束（对应第5轮任务书）：
- 不做每题脚本：题目清单写在数据文件里，适配器按 profile 复用。
- 公式不作平铺：MathJye 的 mfrac/msubsup/msub/msup 转成 Typst 数学，未知结构返回
  unknown，由记录标 needs_review，绝不把“未知”当成功。
- 来源答案只复制原文，不重算、不意译；回填在题干里的答案（sanwser）去掉后另存答案区。
- 图资产校验 HTTP 状态与真实格式（magic bytes），非空 HTML 不当 PNG。
"""
from __future__ import annotations

import hashlib
import json
import pathlib
from pathlib import Path
import re
import subprocess
from datetime import datetime
from urllib.parse import urljoin

from bs4 import BeautifulSoup, Comment, NavigableString, Tag

from . import answers, paths, provenance

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36")

MATH_CLASSES = {"mfrac", "msubsup", "msub", "msup", "mrow", "mo", "mn", "mi", "mtext", "mnormal"}


class UnknownFormula(Exception):
    pass


def _text_of(tag: Tag) -> str:
    t = tag.get_text("", strip=True)
    return t.replace("\u200b", "").strip()


def math_to_typst(tag: Tag) -> str:
    """把一个 MathJye 节点转成 Typst 行内数学内容（不含 $）。未知结构抛 UnknownFormula。"""
    cls = set(tag.get("class") or [])
    if "mfrac" in cls:
        num = tag.select_one(".fracZi")
        den = tag.select_one(".fracMu")
        if num is None or den is None:
            raise UnknownFormula("mfrac 缺 fracZi/fracMu")
        return f"frac({_row(num)}, {_row(den)})"
    if "msubsup" in cls:
        base = tag.select_one(".msubsupCont")
        sup = tag.select_one(".msup")
        sub = tag.select_one(".msub")
        if base is None:
            raise UnknownFormula("msubsup 缺 msubsupCont")
        out = _row(base)
        if sub is not None:
            out += f"_{_row(sub)}"
        if sup is not None:
            out += f"^{_row(sup)}"
        return out
    if "msub" in cls:
        base = tag.find(recursive=False)
        kids = [c for c in tag.children if isinstance(c, Tag)]
        if len(kids) < 2:
            raise UnknownFormula("msub 结构不足")
        return f"{_row(kids[0])}_{_row(kids[1])}"
    if "msup" in cls:
        kids = [c for c in tag.children if isinstance(c, Tag)]
        if len(kids) < 2:
            raise UnknownFormula("msup 结构不足")
        return f"{_row(kids[0])}^{_row(kids[1])}"
    if "mrow" in cls or "MathJye" in cls:
        return _row(tag)
    if "mo" in cls:
        op = _text_of(tag)
        return {"−": "-", "×": "times", "·": "dot"}.get(op, op)
    if "mnormal" in cls:
        return ""
    if tag.find(True) is not None:
        raise UnknownFormula(f"未支持结构：{' '.join(sorted(cls)) or tag.name}")
    return _text_of(tag)


def _row(tag: Tag) -> str:
    parts = []
    for child in tag.children:
        if isinstance(child, Tag):
            if "fracLine" in (child.get("class") or []):
                continue
            parts.append(math_to_typst(child))
        elif isinstance(child, NavigableString):
            s = str(child).strip()
            if s:
                parts.append(s)
    return "".join(parts)


def node_to_typst(node: Tag, *, unknown: list[str]) -> str:
    """把题块/答案块整段转成 Typst 标记：公式包 $...$，图占位跳过，空位下划线。"""
    out: list[str] = []

    def walk(n):
        if isinstance(n, Comment):
            return
        if isinstance(n, NavigableString):
            out.append(str(n))
            return
        if not isinstance(n, Tag):
            return
        cls = set(n.get("class") or [])
        if "sanwser" in cls:          # 页面回填答案，不进题干
            return
        if "MathJye" in cls:
            try:
                body = math_to_typst(n)
                # Typst 把连续字母当标识符；“μg”“Ωs”需断开
                body = re.sub(r"(?<=[μΩ°])(?=[A-Za-z])", " ", body)
                keep = {"frac", "times", "dot", "sqrt", "vec", "sin", "cos", "tan", "max", "min", "pi"}
                body = re.sub(r"(?<![A-Za-z])([A-Za-z]{2,})(?![A-Za-z(])",
                              lambda m: m.group(1) if m.group(1) in keep else " ".join(m.group(1)), body)
                out.append("$" + body + "$")
            except UnknownFormula as exc:
                unknown.append(str(exc))
                out.append(_text_of(n))
            return
        if "quizPutTag" in cls:       # 空位
            out.append("＿＿＿")
            return
        if n.name == "br":
            out.append("\n")
            return
        if n.name == "img":
            out.append("\n")          # 图单独作资产
            return
        if n.name in ("sub", "sup"):
            body = n.get_text("", strip=True).replace("]", r"\]")
            out.append(("#sub[" if n.name == "sub" else "#sup[") + body + "]")
            return
        for c in n.children:
            walk(c)

    walk(node)
    text = "".join(out)
    # 下标/上标：Typst 正文里 #sub[] 不会渲染，改成行内数学 $S_1$
    base = r"[A-Za-z0-9ρμΩαβγθλΔ]"
    text = re.sub("(" + base + r")#sub\[([^\]]+)\]", r"$\1_\2$", text)
    text = re.sub("(" + base + r")#sup\[([^\]]+)\]", r"$\1^\2$", text)
    text = re.sub(r"#sub\[([^\]]+)\]", r"\1", text)
    text = re.sub(r"#sup\[([^\]]+)\]", r"\1", text)
    text = text.replace("\u200b", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip()


CJK = re.compile(r"[\u4e00-\u9fff]")


def normalize_math(text: str) -> str:
    """Typst 数学里不能出现中文或多字母未知标识符：中文公式退回纯文本，字母串断开。"""
    keep = {"frac", "times", "dot", "sqrt", "vec", "sin", "cos", "tan", "max", "min", "pi"}

    def fix(m):
        body = m.group(1)
        if CJK.search(body):
            # 中文下标是常见来源写法（ρ_水）。转成 Typst 的 _( "水" )，保留下标语义；
            # 不能靠删掉下划线来换编译通过。
            body = re.sub(r"(_|\^)\s*([\u4e00-\u9fff]+)",
                          lambda mm: f'{mm.group(1)}("{mm.group(2)}")', body)

            def wrap_cjk(mm):
                s, e = mm.start(), mm.end()
                if (s > 0 and body[s - 1] == '"') or (e < len(body) and body[e] == '"'):
                    return mm.group(0)
                return f'"{mm.group(0)}"'

            body = re.sub(r"[\u4e00-\u9fff]+", wrap_cjk, body)
            return "$" + body + "$"

        def rep(mt):
            w = mt.group(0)
            if w in keep or body[mt.end():mt.end() + 1] == "(":
                return w
            return " ".join(w)
        return "$" + re.sub(r"[A-Za-z]{2,}", rep, body) + "$"

    return re.sub(r"\$([^$]*)\$", fix, text)


def download_figure(url: str, dest: pathlib.Path, referer: str | None = None) -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["curl", "-sS", "-L", "-m", "30", "-A", UA, "-o", str(dest),
           "-w", "%{http_code} %{content_type} %{url_effective}", url]
    if referer:
        cmd[1:1] = ["-e", referer]
    p = subprocess.run(cmd, capture_output=True, text=True)
    first, _, rest = p.stdout.partition(" ")
    ctype, _, final_url = rest.partition(" ")
    status = first.strip()
    data = dest.read_bytes() if dest.exists() else b""
    code = int(status) if status.isdigit() else 0
    is_file_url = str(url).startswith("file://")
    if p.returncode != 0 or (not (200 <= code < 300) and not is_file_url):
        return {"url": url, "final_url": final_url.strip(), "http": status, "curl_exit": p.returncode,
                "content_type": ctype, "ok": False, "reason": f"HTTP/传输失败（curl={p.returncode}）",
                "bytes": len(data)}
    try:
        from PIL import Image
        import io as _io
        im = Image.open(_io.BytesIO(data))
        im.verify()
        im2 = Image.open(_io.BytesIO(data)); im2.load()
        size = im2.size
        fmt = im2.format
    except Exception as exc:
        return {"url": url, "final_url": final_url.strip(), "http": status, "content_type": ctype,
                "ok": False, "reason": f"图片解码失败：{exc}", "bytes": len(data)}
    # 扩展名必须与实际编码一致；否则 Typst 可能按后缀误判图片类型。
    if fmt in ("JPEG", "MPO") and dest.suffix.lower() not in (".jpg", ".jpeg"):
        new_dest = dest.with_suffix(".jpg")
        if new_dest.exists():
            new_dest.unlink()
        dest.rename(new_dest)
        dest = new_dest
    elif fmt == "PNG" and dest.suffix.lower() != ".png":
        new_dest = dest.with_suffix(".png")
        if new_dest.exists():
            new_dest.unlink()
        dest.rename(new_dest)
        dest = new_dest
    elif fmt == "WEBP" and dest.suffix.lower() != ".webp":
        new_dest = dest.with_suffix(".webp")
        if new_dest.exists():
            new_dest.unlink()
        dest.rename(new_dest)
        dest = new_dest
    return {"url": url, "final_url": final_url.strip(), "http": status, "content_type": ctype,
            "ok": True, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "file": str(dest), "decoded_format": fmt, "decoded_size": list(size)}


def image_src(tag: Tag) -> str:
    """取实际图片地址：懒加载优先，其次 src/srcset；相对地址原样返回。"""
    return provenance.image_src_tag(tag)


def _resolve_image_url(src: str, page_url: str) -> str:
    return provenance.resolve_url(src, page_url)


def _images_in_node(node: Tag, default_after: str, page_url: str) -> list[dict]:
    """按 DOM 顺序收集图，并在遇到（N）小问编号时切换 after 锚点。"""
    found: list[dict] = []
    anchor = default_after

    def walk(n):
        nonlocal anchor
        if isinstance(n, Comment):
            return
        if isinstance(n, NavigableString):
            text = str(n)
            m = re.findall(LABEL_TOKEN, text)
            if m:
                label = m[-1].replace("(", "（").replace(")", "）")
                anchor = f"sub:{label}"
            return
        if not isinstance(n, Tag):
            return
        if n.name == "img":
            raw = image_src(n)
            found.append({"element": n, "src_raw": raw,
                          "src": _resolve_image_url(raw, page_url) if raw else "",
                          "after": anchor, "declared": True})
            return
        for c in n.children:
            walk(c)

    walk(node)
    return found


LABEL_TOKEN = r"[（(]\d+[）)]"


def _strip_label(text: str) -> tuple[str, str]:
    m = re.match(r"\s*(" + LABEL_TOKEN + r")\s*", text)
    if not m:
        return "", text.strip()
    label = m.group(1).replace("(", "（").replace(")", "）")
    return label, text[m.end():].strip()


def split_subquestions(text: str) -> list[dict]:
    """把“（1）/ (1) / ①”切成小问；没有则返回空。

    只认出现在文本流中的编号令牌，不把普通括号说明硬拆成小问；嵌套编号
    仍保留为该小问正文的一部分，交给后续 answer mapping 显式处理。
    """
    # 只切行首/句末的（数字）标签；① 等嵌套编号留在小问正文，不另立小问。
    parts = re.split(r"(?=(?:^|[\n。；;]|\s)\s*" + LABEL_TOKEN + r")", text, flags=re.M)
    subs = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        label, body = _strip_label(p)
        if label:
            subs.append({"label": label, "text": body})
    return subs


def jyeoo_record(html_path: pathlib.Path, page_url: str, rec_id: str, *, fig_dir: pathlib.Path,
                 identity: dict, publisher: str = "菁优网（jyeoo.com）",
                 answer_items: list[dict] | None = None,
                 delivery_mode: str = "questions_only",
                 source_role: str = "unknown", original_file: str | None = None,
                 original_url: str | None = None,
                 scope_selector: str = "section.quesborder, div.quesborder",
                 original_scope_selector: str | None = None,
                 fetch_meta: str | None = None,
                 original_fetch_meta: str | None = None) -> dict:
    """从菁优网单题页生成统一记录。

    第7轮补齐：题干/选项/小问/答案的有序块与选择器定位；题干、选项、小问、答案图
    都纳入下载与失败记录；相对 URL/懒加载地址解析；答案只按完整小问标签映射，
    不再用“分号段数碰巧相等”顺序猜配；导入器不写任何 review/compared。
    """
    soup = BeautifulSoup(html_path.read_text("utf-8", "replace"), "html.parser")
    scopes = soup.select(scope_selector)
    scope = scopes[0] if scopes else None
    if scope is None:
        raise SystemExit(f"未找到主问题块：{html_path}（selector={scope_selector!r}）")
    dom = provenance.analyze_html(html_path, page_url, scope_selector)
    stem_node = scope.select_one("div.pt1")
    ans_node = scope.select_one("div.pt11")
    html_rel = str(html_path)
    unknown: list[str] = []
    stem_raw = node_to_typst(stem_node, unknown=unknown) if stem_node else ""
    ans_unknown: list[str] = []
    answer_raw = node_to_typst(ans_node, unknown=ans_unknown) if ans_node else ""
    answer_raw = re.sub(r"^【答案】\s*", "", answer_raw).strip()

    opt_unknown: list[str] = []
    options: list[str] = []
    option_labels: list[str] = []
    option_images: list[dict] = []
    for i, label_node in enumerate(scope.select("td.selectoption label")):
        raw = node_to_typst(label_node, unknown=opt_unknown)
        m = re.match(r"^([A-D])[．.\s]", raw.strip())
        label = m.group(1) if m else chr(65 + i)
        option_labels.append(label)
        options.append(re.sub(r"^[A-D][．.]\s*", "", raw.strip()))
        option_images.extend(_images_in_node(label_node, f"option:{label}", page_url))

    subs = split_subquestions(stem_raw)
    stem = stem_raw
    if subs:
        first = re.search(r"[（(]1[）)]", stem_raw)
        if first:
            stem = stem_raw[:first.start()].strip()

    question_images = _images_in_node(stem_node, "stem", page_url) if stem_node else []
    question_images += option_images
    answer_images = _images_in_node(ans_node, "answer", page_url) if ans_node else []
    seen_images = {id(x["element"]) for x in question_images + answer_images}
    unplaced_images = []
    for img in scope.find_all("img"):
        if id(img) in seen_images:
            continue
        raw = image_src(img)
        unplaced_images.append({"element": img, "src_raw": raw,
                                "src": _resolve_image_url(raw, page_url) if raw else "",
                                "after": "stem", "declared": True, "unplaced": True})
    question_images += unplaced_images

    claim_text = stem + "\n" + "\n".join(s.get("text", "") for s in subs)
    claims = provenance.figure_claims(claim_text)
    figs: list[dict] = []
    fig_failures: list[dict] = []
    if claims and not question_images:
        fig_failures.append({"figure_no": "声明图", "role": "原题图", "after": "stem",
                             "src": "", "src_raw": "", "claim": claims[0],
                             "reason": "题干声明图/图线/坐标系，但实际DOM未提供可提取的题图"})
    answer_figs: list[dict] = []
    for n, info in enumerate(question_images, 1):
        src = info["src"]
        after = info["after"]
        role = "选项图" if after.startswith("option:") else "原题图"
        dest = fig_dir / f"{rec_id}-fig{n}.png"
        if not src:
            fig_failures.append({"figure_no": f"题图{n}", "role": role, "after": after,
                                 "src": "", "src_raw": info.get("src_raw") or "",
                                 "reason": "声明了 img 但没有可用 src/data-src/srcset"})
            continue
        meta = download_figure(src, dest, referer=page_url)
        if not meta["ok"]:
            fig_failures.append({"figure_no": f"题图{n}", "role": role, "after": after,
                                 "src": src, "src_raw": info["src_raw"],
                                 "reason": meta.get("reason"), "http": meta.get("http")})
            continue
        fig = {
            "figure_no": f"题图{n}", "role": role, "after": after,
            "evidence_path": meta["file"], "asset_path": meta["file"],
            "asset_sha256": meta["sha256"], "source_note": "题库转载图（jyeoo）· 非原卷扫描",
            "source_url": meta.get("final_url") or src, "source_src_raw": info["src_raw"],
            "http": meta.get("http"), "content_type": meta.get("content_type"),
            "bytes": meta.get("bytes"), "decoded_size": meta.get("decoded_size"),
            "relations": {"layout": "题干配图，位于题干后" if after == "stem" else "按题面锚点放置",
                          "objects": [], "labels": ["题图"], "open_issues": []},
            "display_width": "55%" if role == "选项图" else "62%",
        }
        figs.append(fig)
    for n, info in enumerate(answer_images, 1):
        src = info["src"]
        dest = fig_dir / f"{rec_id}-answer{n}.png"
        if not src:
            fig_failures.append({"figure_no": f"答案图{n}", "role": "答案图", "after": "answer",
                                 "src": "", "src_raw": info.get("src_raw") or "",
                                 "reason": "声明了答案 img 但没有可用 src/data-src/srcset"})
            continue
        meta = download_figure(src, dest, referer=page_url)
        if not meta["ok"]:
            fig_failures.append({"figure_no": f"答案图{n}", "role": "答案图", "after": "answer",
                                 "src": src, "reason": meta.get("reason"), "http": meta.get("http")})
            continue
        answer_figs.append({
            "figure_no": f"答案图{n}", "role": "答案图", "after": "answer",
            "evidence_path": meta["file"], "asset_path": meta["file"],
            "asset_sha256": meta["sha256"], "source_note": "题库转载答案图（jyeoo）· 非原卷扫描",
            "source_url": meta.get("final_url") or src, "http": meta.get("http"),
            "content_type": meta.get("content_type"), "bytes": meta.get("bytes"),
            "display_width": "62%",
        })

    # 答案映射：只按完整小问标签；没有标签就是未映射，不做分号段数猜配。
    labels = [s["label"] for s in subs]
    mapping, mapping_status = answers.mapping_from_labeled(answer_raw, labels, "页面【答案】块")
    by_label = {}
    for m in mapping:
        for t in m.get("targets") or []:
            by_label[str(t)] = str(m.get("answer") or m.get("source_quote") or "")
    items = [{"label": s["label"], "answer": by_label.get(str(s["label"]), "").strip()} for s in subs]
    if answer_items:
        items = [dict(x) for x in answer_items]
        mapping = []
        for it in items:
            if (it.get("answer") or "").strip():
                mapping.append({"source_locator": "调用方显式给出的答案条目",
                                "source_quote": str(it["answer"]).strip(),
                                "targets": [str(it.get("label"))], "status": "mapped",
                                "method": "explicit_items", "note": "需人工回源核对"})
        mapping_status = "complete" if mapping and all(m.get("source_quote") for m in mapping) else "partial"
    if not subs and answer_raw:
        items = [{"label": "答案", "answer": answer_raw}]
        mapping = [{"source_locator": "页面【答案】块（无小问）",
                    "source_quote": answer_raw, "targets": ["答案"],
                    "status": "mapped", "method": "single_block", "note": "整块答案"}]
        mapping_status = "complete" if not answers.is_placeholder(answer_raw) else "partial"

    answer_available = bool(answer_raw or answer_figs)
    if not answer_available:
        mapping_status = "unmapped"
    requested_mode = delivery_mode
    answer_mode = "with_sourced_answers" if (delivery_mode == "with_sourced_answers" and mapping_status == "complete") else "questions_only"
    downgrade_reason = ""
    if delivery_mode == "with_sourced_answers" and mapping_status != "complete":
        answer_mode = "questions_only"
        downgrade_reason = f"来源答案映射状态 {mapping_status}，未达到 complete；用户请求的来源答案版未完成，已降级为题目版并保留缺口，需补映射后显式改回"

    stem = normalize_math(stem)
    subs = [{**s, "text": normalize_math(s["text"])} for s in subs]
    options = [normalize_math(o) for o in options]
    answer_norm = normalize_math(answer_raw)
    mapping = [{**m, "source_quote": normalize_math(str(m.get("source_quote") or "")),
                "answer": normalize_math(str(m.get("answer") or m.get("source_quote") or ""))}
               for m in mapping]
    items = [{k: (normalize_math(v) if isinstance(v, str) else v) for k, v in it.items()} for it in items]

    blocks = [{"order": 1, "id": "stem", "kind": "stem", "text": stem,
               "source": {"path": html_rel, "selector": "div.pt1", "page": None}}]
    order = 2
    for i, opt in enumerate(options):
        blocks.append({"order": order, "id": f"option:{option_labels[i]}", "kind": "option",
                       "label": option_labels[i], "text": opt,
                       "source": {"path": html_rel, "selector": "td.selectoption label", "page": None}})
        order += 1
    for sub in subs:
        blocks.append({"order": order, "id": f"sub:{sub['label']}", "kind": "subquestion",
                       "label": sub["label"], "text": normalize_math(sub["text"]),
                       "source": {"path": html_rel, "selector": "div.pt1", "page": None}})
        order += 1
    for fig in figs:
        blocks.append({"order": order, "id": f"figure:{fig['figure_no']}", "kind": "figure",
                       "figure_no": fig["figure_no"], "role": fig["role"], "after": fig["after"],
                       "source": {"path": html_rel, "selector": "div.pt1 img", "page": None}})
        order += 1
    if answer_available:
        blocks.append({"order": order, "id": "answer", "kind": "answer", "text": answer_norm,
                       "source": {"path": html_rel, "selector": "div.pt11", "page": None}})

    open_questions = ["原卷题号未标注（平台题ID 见 bank_id）", "无原卷扫描对照，题库图可能重绘"]
    if fig_failures:
        open_questions.append(f"有 {len(fig_failures)} 个图下载/解码失败，见 problem.figure_failures")
    if mapping_status != "complete":
        open_questions.append(f"答案映射状态 {mapping_status}，未映射内容保留在 answer.text")
    if claims and not question_images:
        open_questions.append(f"题干声明图/图线但未提取到题图：{claims[0]}")
    if source_role in ("derived", "model_excerpt", "transcription"):
        open_questions.append("本题来自派生摘录；必须链回原始 HTML/URL/hash 与 selector，不能自证完整")

    html_sha = hashlib.sha256(html_path.read_bytes()).hexdigest()
    derived = source_role in ("derived", "model_excerpt", "transcription")
    orig = {}
    orig_dom = {}
    orig_selector = original_scope_selector or scope_selector
    if original_file:
        orig = provenance.original_chain(original_file, original_url or page_url, orig_selector)
        if orig.get("exists"):
            orig_dom = provenance.analyze_html(original_file, original_url or page_url, orig_selector)
            orig["dom"] = orig_dom
    def _load_fetch(path):
        if not path:
            return None
        fp = Path(path)
        if not fp.exists():
            return {"error": "fetch metadata file missing", "path": str(fp)}
        try:
            return json.loads(fp.read_text(encoding="utf-8"))
        except Exception as exc:
            return {"error": f"fetch metadata unreadable: {exc}", "path": str(fp)}
    fetch = _load_fetch(fetch_meta)
    if orig:
        orig_fetch = _load_fetch(original_fetch_meta)
        if orig_fetch:
            orig["fetch"] = orig_fetch
    evidence_path = orig.get("path") if derived and orig.get("exists") else html_rel
    evidence_sha = orig.get("sha256") if derived and orig.get("exists") else html_sha
    source_evidence = [{
        "path": evidence_path, "sha256": evidence_sha,
        "locate": "原始 HTML 主问题块 + 题面/图像声明" if derived else "主问题块与 DOM 图文声明",
        "page": None, "selector": "div.pt1", "independence": "third_party_repost",
    }]
    if derived and orig.get("exists"):
        source_evidence.append({
            "path": html_rel, "sha256": html_sha, "locate": "模型派生摘录（仅解析副本）",
            "page": None, "selector": "div.pt1", "independence": "model_derived",
        })

    rec = {
        "id": rec_id,
        "status": "待核实",
        "stage": identity.get("stage"),
        "identity": {k: identity.get(k) for k in
                     ("exam_year", "exam_year_label", "year_evidence", "region", "school",
                      "exam_name", "exam_type", "original_number", "bank_id", "booklet_number")},
        "source": {
            "urls": [page_url] if page_url else [],
            "local_files": [{"path": html_rel, "sha256": html_sha}],
            "original_files": ([{"path": orig["path"], "sha256": orig["sha256"]}] if orig.get("exists") else []),
            "origin_role": source_role,
            "derived": ({"path": html_rel, "sha256": html_sha, "role": source_role} if derived else None),
            "original": orig or None,
            "fetch": fetch,
            "dom": dom,
            "material_type": provenance.material_type(identity.get("exam_type"), identity.get("material_type")),
            "publisher": publisher, "publication_type": "完整转载",
            "retrieved_at": datetime.now().isoformat(timespec="seconds"),
            "upstream": "题库聚合，上游多为学校/考试院上传，未独立核验",
            "evidence": source_evidence,
            "open_questions": open_questions,
            # 导入器不冒充核实；source.status 只有显式 record-review --check source 才改“通过”。
            "status": "待核实",
        },
        "problem": {
            "stem": stem, "options": options, "subquestions": subs, "figures": figs,
            "blocks": blocks,
            "answer_slots": [{"id": s["label"], "label": s["label"], "kind": "text", "required": True}
                             for s in subs],
            "figure_expected": bool(question_images) or bool(claims),
            "figure_claims": claims,
            "figure_failures": fig_failures,
            "answer_unmapped": answer_norm if mapping_status != "complete" else None,
            "expected": {"figure": bool(question_images) or bool(claims), "option_count": len(options),
                         "subquestion_count": len(subs), "figure_count": len(question_images)},
            "unresolved_chars": unknown + ans_unknown + opt_unknown,
            "needs_review": bool(unknown or ans_unknown or opt_unknown),
        },
        "teaching": {"stage": identity.get("stage"), "topic": identity.get("topic") or "",
                     "knowledge_points": identity.get("knowledge_points", []),
                     "prerequisites": [], "difficulty_reason": "", "est_minutes": 8, "use": "课后练习",
                     "textbook": ""},
        "solution": {"independent": False, "saw_reference": True, "system": "typst", "reference_frame": "",
                     "stages": [], "sub_answers": [{"label": it["label"], "answer": it["answer"]} for it in items],
                     "initial_positions": {}, "checks": [],
                     "comparison": {"status": "partial" if mapping_status == "complete" else "missing",
                                    "source": page_url or html_rel,
                                    "note": "程序按标签建议映射，未逐项人工复核；不能当 compared"}},
        "answer": {"nature": "转载参考答案" if answer_available else "未取得",
                   "source_url": (orig.get("url") or page_url or html_rel) if derived else (page_url or html_rel),
                   "locator": "页面【答案】块（div.pt11），游客可见，未登录",
                   "evidence": [{"path": evidence_path,
                                 "sha256": evidence_sha,
                                 "page": None, "region": "div.pt11"}],
                   "derived_evidence": ({"path": html_rel, "sha256": html_sha} if derived else None),
                   "items": items, "text": answer_norm,
                   "mapping": mapping, "mapping_status": mapping_status,
                   "figures": answer_figs,
                   "figure": answer_figs[0] if answer_figs else None},
        "delivery": {"mode": answer_mode, "requested_mode": requested_mode,
                     "effective_mode": answer_mode, "downgrade_reason": downgrade_reason,
                     "display_answers": answer_mode != "questions_only",
                     "explanations_requested": False, "claims_answers_verified": False,
                     "note": "导入器只保存来源答案和映射建议，不写已审核；题目版默认不附答案"},
        "review": {},
    }
    return rec


def scan_record(*, rec_id: str, stem: str, subs: list[dict], answer_items: list[dict], answer_text: str,
                page_url: str, question_page: str, answer_page: str, figure_path: str,
                figure_sha: str, identity: dict, evidence_pages: list[dict],
                corrections: list[str], points: int, question_page_no: int,
                ocr_raw: str) -> dict:
    """原卷扫描题：题干为人工按原页校对的文本，图与答案页为原页裁切/OCR 证据。"""
    stem = normalize_math(stem)
    subs = [{**s, "text": normalize_math(s["text"])} for s in subs]
    answer_items = [{**a, "answer": normalize_math(a["answer"])} for a in answer_items]
    answer_text = normalize_math(answer_text)
    return {
        "id": rec_id,
        "status": "通过",
        "stage": identity["stage"],
        "identity": {k: identity.get(k) for k in
                     ("exam_year", "region", "school", "exam_name", "exam_type", "original_number",
                      "bank_id", "booklet_number")},
        "source": {
            "urls": [page_url], "publisher": "苏州汇（转载苏州市教育考试院发布页）",
            "publication_type": "完整转载", "retrieved_at": datetime.now().isoformat(timespec="seconds"),
            "upstream": "苏州市教育考试院（发布页 jyj.suzhou.gov.cn 已见，未下载第一方文件）",
            "evidence": evidence_pages,
            "open_questions": [f"第一方 PDF 需登录，未取；题干为人工按原页校对（改动 {len(corrections)} 处）"],
            "status": "通过",
        },
        "problem": {"stem": stem, "options": [], "subquestions": subs,
                    "points": points,
                    "figures": [{"figure_no": "原题图", "role": "原题图", "after": "stem",
                                 "evidence_path": figure_path, "asset_path": figure_path,
                                 "asset_sha256": figure_sha,
                                 "source_note": f"原卷扫描页 {question_page} 定向裁切，未重绘、未擦水印",
                                 "relations": {"layout": "题干配图，位于题干后", "objects": [], "labels": ["题图"], "open": "需与题干接线拓扑逐项核对"},
                                 "display_width": "62%"}],
                    "expected": {"figure": True, "option_count": 0, "subquestion_count": len(subs)},
                    "unresolved_chars": [], "needs_review": True,
                    "manual_transcription": {"ocr_raw": ocr_raw, "corrections": corrections,
                                             "note": "题干与小问为人工按原卷页校对录入，非自动提取"}},
        "teaching": {"stage": identity["stage"], "topic": identity.get("topic", "电学"), "knowledge_points": identity.get("knowledge_points", []),
                     "prerequisites": [], "difficulty_reason": "", "est_minutes": 8, "use": "课后练习", "textbook": ""},
        "solution": {"independent": False, "saw_reference": True, "system": "typst", "reference_frame": "",
                     "stages": [], "sub_answers": [{"label": it["label"], "answer": it["answer"]} for it in answer_items],
                     "initial_positions": {}, "checks": [],
                     "comparison": {"status": "compared", "source": page_url,
                                    "note": "逐问对照来源答案原文，未独立重算"}},
        "answer": {"nature": "原卷参考答案", "source_url": page_url, "ocr_raw": ocr_raw,
                   "locator": f"原卷答案页 {answer_page}（苏州市教育考试院）",
                   "evidence": [{"path": answer_page,
                                 "sha256": hashlib.sha256(pathlib.Path(answer_page).read_bytes()).hexdigest(),
                                 "page": 10, "region": "答案页", "selector": "原卷答案页第30题行"}],
                   "items": answer_items, "text": answer_text},
        "delivery": {"mode": "with_sourced_answers", "explanations_requested": False,
                     "claims_answers_verified": False, "note": "答案取自原卷答案页 OCR，已人工校对"},
        "review": {},
    }


def write_record(rec: dict, records_dir: pathlib.Path) -> pathlib.Path:
    records_dir.mkdir(parents=True, exist_ok=True)
    provenance.first_snapshot(records_dir, rec["id"], rec)
    out = records_dir / f"{rec['id']}.json"
    out.write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def cli(args) -> int:
    """`xuean.py import` 入口：HTML 题库或 PDF/扫描 manifest → 统一记录。"""
    import pathlib as _p

    src = _p.Path(args.source)
    if args.profile == "jyeoo":
        if not args.stage:
            raise SystemExit("jyeoo 导入必须显式给出 --stage；不得沿用默认学段")
        if args.year is None and not args.year_label:
            raise SystemExit("jyeoo 导入必须给出 --year 或 --year-label；未知年份不得凭空填默认年")
        identity = dict(stage=args.stage, exam_year=args.year,
                        exam_year_label=args.year_label, year_evidence=args.year_evidence,
                        region=args.region, school=None, exam_name=args.exam, exam_type=args.exam_type,
                        material_type=args.material_type,
                        original_number="未核实（平台题ID 见 bank_id）", bank_id="", topic="")
        fig_dir = _p.Path(args.fig_dir) if args.fig_dir else (paths.LAB_ROOT / "sources" / "imports" / args.id / "figs")
        rec = jyeoo_record(src, args.url, args.id, fig_dir=fig_dir, identity=identity,
                           publisher=args.publisher,
                           delivery_mode=args.delivery, source_role=args.source_role,
                           original_file=args.original_file, original_url=args.original_url,
                           scope_selector=args.scope_selector,
                           original_scope_selector=args.original_scope_selector,
                           fetch_meta=args.fetch_meta,
                           original_fetch_meta=args.original_fetch_meta)
        out = write_record(rec, _p.Path(args.records))
        print(f"记录：{out}")
        print(f"  题干 {len(rec['problem']['stem'])} 字 / 小问 {len(rec['problem']['subquestions'])} / "
              f"选项 {len(rec['problem']['options'])} / 图 {len(rec['problem']['figures'])} / "
              f"答案小问 {len(rec['answer']['items'])} / 映射 {rec['answer']['mapping_status']} / "
              f"待核验字段 {rec['problem']['unresolved_chars']}")
        if rec["problem"]["figure_failures"]:
            print(f"  图失败 {len(rec['problem']['figure_failures'])} 个，见记录 problem.figure_failures")
        return 0
    # scan profile：--source 指向 JSON manifest，而不是写死苏州的旧脚本。
    from . import pdf_import

    rec, info = pdf_import.import_manifest(src, _p.Path(args.records))
    print(f"记录：{info['record']}")
    print(f"  来源 {info['sha256'][:16]}…  跨页 {info['cross_page']}  映射 {info['mapping_status']}")
    print(f"  题干 {len(rec['problem']['stem'])} 字 / 小问 {len(rec['problem']['subquestions'])} / "
          f"选项 {len(rec['problem']['options'])} / 图 {len(rec['problem']['figures'])} / "
          f"答案条目 {len(rec['answer']['items'])}")
    print(f"  提取/裁剪证据：{info['work']}")
    return 0
