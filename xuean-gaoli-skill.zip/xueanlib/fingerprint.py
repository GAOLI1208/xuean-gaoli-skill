"""内容指纹与“审核跟随内容变化”。

指纹只用于判断内容是否变化，不证明内容正确。审核记录绑定当时指纹；
文件或字段变化后，旧审核自动失效，必须重检。
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import models, paths

CST = timezone(timedelta(hours=8))


def _now() -> str:
    return datetime.now(CST).isoformat(timespec="seconds")


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _figure_paths(rec: dict) -> list[Path]:
    out = []
    for fig in models.figures(rec):
        for key in ("svg_path", "evidence_path", "asset_path"):
            val = fig.get(key)
            if val:
                p = Path(val)
                if not p.is_absolute():
                    p = paths.LAB_ROOT / p
                out.append(p)
    return out


def _source_files(rec: dict) -> list[Path]:
    out = []
    for ev in models.get(rec, "source.evidence", []) or []:
        val = ev.get("path")
        if val:
            p = Path(val)
            if not p.is_absolute():
                p = paths.LAB_ROOT / p
            out.append(p)
    return out


def components(rec: dict) -> dict:
    """按审核项拆分指纹输入。"""
    identity = models.get(rec, "identity", {}) or {}
    src = models.get(rec, "source", {}) or {}
    prob = models.get(rec, "problem", {}) or {}
    fig = models.figure(rec) or {}
    sol = models.get(rec, "solution", {}) or {}

    source_payload = {
        "identity": identity,
        "urls": src.get("urls"),
        "publisher": src.get("publisher"),
        "publication_type": src.get("publication_type"),
        "status": src.get("status"),
        "retrieved_at": src.get("retrieved_at"),
        "upstream": src.get("upstream"),
        "open_questions": src.get("open_questions"),
        "evidence": [
            {"path": ev.get("path"), "page": ev.get("page"), "selector": ev.get("selector")}
            for ev in (src.get("evidence") or [])
        ],
        "local_files": src.get("local_files"),
        **({"origin_role": src["origin_role"]} if "origin_role" in src else {}),
        **({"material_type": src["material_type"]} if "material_type" in src else {}),
        **({"dom": src["dom"]} if "dom" in src else {}),
        **({"original": src["original"]} if "original" in src else {}),
        **({"derived": src["derived"]} if "derived" in src else {}),
        **({"fetch": src["fetch"]} if "fetch" in src else {}),
        "file_hashes": {
            str(p): (sha256_file(p) if p.exists() else "missing") for p in _source_files(rec)
        },
    }
    text_payload = {
        "stem": prob.get("stem"),
        "options": prob.get("options"),
        "subquestions": prob.get("subquestions"),
        "blocks": prob.get("blocks"),
        "answer_slots": prob.get("answer_slots"),
        "expected": prob.get("expected"),
        **({"figure_expected": prob["figure_expected"], "figure_claims": prob["figure_claims"]}
           if "figure_claims" in prob else {}),
        "figure_failures": prob.get("figure_failures"),
    }
    ans = models.answer_block(rec)
    answer_paths = []
    for ev in (ans.get("evidence") or []):
        if isinstance(ev, dict) and ev.get("path"):
            answer_paths.append(ev["path"])
    for f in (ans.get("figures") or []):
        if isinstance(f, dict):
            answer_paths.extend([f.get("path"), f.get("asset_path"), f.get("evidence_path")])
    if isinstance(ans.get("figure"), dict):
        answer_paths.extend([ans["figure"].get("path"), ans["figure"].get("asset_path")])
    for m in (ans.get("mapping") or []):
        if isinstance(m, dict):
            answer_paths.extend([m.get("figure_path"), m.get("path")])
    resolved = []
    for val in answer_paths:
        if not val:
            continue
        q = Path(str(val))
        if not q.is_absolute():
            q = paths.LAB_ROOT / q
        resolved.append(q)
    answer_payload = {
        "solution": sol,
        "answer": ans,
        **({"delivery": models.get(rec, "delivery")} if "display_answers" in (models.get(rec, "delivery") or {}) else {}),
        "answer_slots": prob.get("answer_slots"),
        "answer_files": {
            str(q): (sha256_file(q) if q.exists() else "missing")
            for q in resolved
        },
    }
    figs = models.figures(rec)
    redraw_payload = {
        "figures": [
            {
                "figure_no": f.get("figure_no"),
                "role": f.get("role"),
                "after": f.get("after"),
                "asset_path": f.get("asset_path"),
                "asset_sha256": f.get("asset_sha256"),
                "asset_crop": f.get("asset_crop"),
                "svg_path": f.get("svg_path"),
                "relations": f.get("relations"),
            }
            for f in figs
        ],
        "file_hashes": {str(p): (sha256_file(p) if p.exists() else "missing") for p in _figure_paths(rec)},
    }
    physics_payload = {
        "initial_positions": sol.get("initial_positions"),
        "objects": (fig.get("relations") or {}).get("objects"),
        "constraints": (fig.get("relations") or {}).get("constraints"),
        "checks": sol.get("checks"),
        "sub_answers": sol.get("sub_answers"),
    }
    out = {}
    for name, payload in (
        ("source", source_payload),
        ("text", text_payload),
        ("answer", answer_payload),
        ("redraw", redraw_payload),
        ("physics", physics_payload),
    ):
        out[name] = sha256_text(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    out["combined"] = sha256_text("|".join(out[k] for k in models.REVIEW_CHECKS))
    return out


def record_review(args) -> int:
    """保存一次真实检查：说明、证据位置、当前指纹。不批量通过。"""
    rec_path = Path(args.record)
    rec = json.loads(rec_path.read_text(encoding="utf-8"))
    check = args.check
    new_status = getattr(args, "status", None) or models.REVIEW_PASS
    # 来源身份审核通过才把 source.status 从“待核实”改为“通过”；
    # 这是显式审核动作，不是导入器自动填。
    if check == "source" and new_status == models.REVIEW_PASS:
        rec.setdefault("source", {})["status"] = models.SOURCE_STATUS_PASS
    comps = components(rec)
    entry = rec.setdefault("review", {}).setdefault(check, {})
    entry.update(
        {
            "status": new_status,
            "note": args.note,
            "evidence": args.evidence or [],
            "actor": getattr(args, "actor", None) or "DSH",
            "method": getattr(args, "method", None) or "DSH 回源/目视核对（模型辅助，非教师本人复核）",
            "at": _now(),
            "fingerprint": comps[check],
        }
    )
    # 原子写入：先写临时文件再替换，避免编码/中断把题目记录截断成空文件。
    payload = json.dumps(rec, ensure_ascii=False, indent=2) + "\n"
    payload.encode("utf-8")  # 提前暴露编码问题，不要先截断目标文件
    tmp = rec_path.with_suffix(rec_path.suffix + ".tmp")
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(rec_path)
    print(f"已记录 {check} 审核：{args.note}")
    print(f"  指纹 {comps[check][:16]}…  证据 {len(args.evidence)} 项")
    return 0


def review_state(rec: dict) -> dict:
    """返回每个审核项：ok / missing / rejected / pending / unknown / stale。

    只有 state == "ok"（status 显式为“通过”且指纹与当前内容一致）才允许正式编排；
    “未通过/失败/待审/未知/空值”都不得当作通过，也不能靠改状态绕过指纹。
    """
    comps = components(rec)
    state = {}
    for check in models.REVIEW_CHECKS:
        entry = models.review(rec, check) or {}
        fp = entry.get("fingerprint")
        raw = entry.get("status")
        status = str(raw).strip() if raw is not None else ""
        if status in models.REVIEW_REJECT:
            state[check] = {"state": "rejected", "detail": f"审核状态为“{status}”", "status": status}
        elif status in models.REVIEW_PENDING:
            state[check] = {"state": "pending", "detail": f"审核状态为“{status}”", "status": status}
        elif status in models.REVIEW_UNCHECKED:
            state[check] = {"state": "missing", "detail": "未记录审核", "status": status}
        elif status != models.REVIEW_PASS:
            state[check] = {"state": "unknown", "detail": f"审核状态 {status!r} 不在白名单", "status": status}
        elif not fp:
            state[check] = {"state": "missing", "detail": "无指纹记录，视为未审核", "status": status}
        elif fp != comps[check]:
            state[check] = {"state": "stale", "detail": "内容已变化，审核失效", "status": status}
        else:
            state[check] = {"state": "ok", "detail": entry.get("note") or "已检查", "status": status}
    return state
