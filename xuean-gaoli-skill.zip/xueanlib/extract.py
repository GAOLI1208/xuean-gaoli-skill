"""PDF / 图片定向提取：文本层、目标页渲染、扫描判断、缓存。

原则：
  * 文本型 PDF 先抽文本，但“有文本”不等于“抽全”，需再渲染目标页看公式与图；
  * 扫描/图片型只渲染需要页，按需 OCR；
  * 证据原文件不覆盖，渲染/裁切都写到 runs 或 cache。
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from . import paths


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_dir() -> Path:
    d = paths.LAB_ROOT / ".cache" / "extract"
    d.mkdir(parents=True, exist_ok=True)
    return d


def pdf_page_text(pdf: Path, page_no: int) -> dict:
    """page_no 从 1 开始。返回文本、字符数、是否有图片。"""
    import pdfplumber

    with pdfplumber.open(str(pdf)) as doc:
        if page_no < 1 or page_no > len(doc.pages):
            raise ValueError(f"页码 {page_no} 超出 1..{len(doc.pages)}")
        page = doc.pages[page_no - 1]
        text = page.extract_text() or ""
        images = len(page.images)
        size = (round(float(page.width), 1), round(float(page.height), 1))
        chars = len(page.chars)
    return {"text": text, "chars": chars, "images": images, "size_pt": size}


def render_page(pdf: Path, page_no: int, out_png: Path, scale: float = 2.5) -> dict:
    import pypdfium2 as pdfium

    doc = pdfium.PdfDocument(str(pdf))
    try:
        page = doc[page_no - 1]
        bitmap = page.render(scale=scale)
        image = bitmap.to_pil()
        out_png.parent.mkdir(parents=True, exist_ok=True)
        image.save(out_png)
        return {"png": str(out_png), "width": image.width, "height": image.height, "scale": scale}
    finally:
        doc.close()


def pdf_info(pdf: Path) -> dict:
    from pypdf import PdfReader

    reader = PdfReader(str(pdf))
    return {
        "pages": len(reader.pages),
        "encrypted": bool(reader.is_encrypted),
        "size_pt": [
            (round(float(p.mediabox.width), 1), round(float(p.mediabox.height), 1))
            for p in reader.pages[:3]
        ],
    }


def extract(input_path, page_no=None, render_out=None, out_json=None) -> dict:
    src = Path(input_path)
    if not src.exists():
        raise FileNotFoundError(src)
    sha = _sha256(src)
    result = {"input": paths.rel(src), "sha256": sha, "kind": None}
    if src.suffix.lower() == ".pdf":
        result["kind"] = "pdf"
        result["info"] = pdf_info(src)
        total = result["info"]["pages"]
        page_no = page_no or 1
        if page_no > total:
            raise ValueError(f"页码 {page_no} 超出 1..{total}")
        text_info = pdf_page_text(src, page_no)
        result["page"] = page_no
        result["text_layer"] = {
            "chars": text_info["chars"],
            "text": text_info["text"],
            "images_on_page": text_info["images"],
            "size_pt": text_info["size_pt"],
            "likely_scanned": text_info["chars"] < 20,
        }
        render_path = Path(render_out) if render_out else (
            _cache_dir() / f"{sha[:16]}-p{page_no}.png"
        )
        if not render_path.exists() or render_out:
            result["render"] = render_page(src, page_no, render_path)
        else:
            from PIL import Image

            with Image.open(render_path) as im:
                result["render"] = {"png": str(render_path), "width": im.width, "height": im.height, "cached": True}
    elif src.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"):
        from PIL import Image

        result["kind"] = "image"
        with Image.open(src) as im:
            result["size"] = {"width": im.width, "height": im.height, "mode": im.mode}
        if render_out:
            import shutil

            Path(render_out).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, render_out)
            result["copy"] = str(render_out)
    else:
        raise ValueError(f"不支持的文件类型：{src.suffix}")

    if out_json:
        Path(out_json).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def main(args) -> int:
    try:
        data = extract(
            args.input,
            page_no=args.page,
            render_out=args.render_out,
            out_json=str(paths.run_dir(args.run) / "extract.json") if args.run else None,
        )
    except Exception as exc:
        print(f"提取失败：{exc}", file=sys.stderr)
        return 2
    if data["kind"] == "pdf":
        info = data["info"]
        print(f"PDF {data['input']}  {info['pages']} 页  加密={info['encrypted']}")
        tl = data["text_layer"]
        print(f"  第 {data['page']} 页：文本层 {tl['chars']} 字符，图片 {tl['images_on_page']} 个，"
              f"{'疑似扫描页' if tl['likely_scanned'] else '有文本层'}")
        print(f"  渲染：{data['render']['png']}  {data['render']['width']}x{data['render']['height']}")
        preview = tl["text"][:300].replace("\n", " / ")
        if preview:
            print(f"  文本前 300 字：{preview}")
        if tl["likely_scanned"]:
            print("  提示：文本层很少，公式/图必须看渲染页，按需 OCR")
    else:
        print(f"图片 {data['input']}  {data['size']['width']}x{data['size']['height']}  sha256={data['sha256'][:16]}…")
    return 0


def crop_region(src: Path, box: tuple[float, float, float, float], out_png: Path, page_no: int | None = None,
                scale: float = 3.0, preprocess: str = "raw") -> dict:
    """按归一化区域（x0,y0,x1,y1 ∈ [0,1]）从页面图或 PDF 页精确裁出题图区域。

    题图必须是“原图/原卷图形区域”，不接受整页扫描拼贴；裁切结果写 sidecar 记录
    来源哈希、区域、缩放与预处理，便于复核与缓存失效。
    """
    from PIL import Image

    x0, y0, x1, y1 = box
    if not all(0.0 <= v <= 1.0 for v in box) or not (x1 > x0 and y1 > y0):
        raise ValueError(f"区域必须满足 0≤x0<x1≤1、0≤y0<y1≤1，当前 {box}")
    work_png = out_png.parent / f".src-{out_png.stem}.png"
    if src.suffix.lower() == ".pdf":
        if page_no is None:
            raise ValueError("PDF 裁切需要 --page")
        render_page(src, page_no, work_png, scale=scale)
        base = work_png
    else:
        base = src
    with Image.open(base) as im:
        w, h = im.size
        px = (int(round(x0 * w)), int(round(y0 * h)), int(round(x1 * w)), int(round(y1 * h)))
        crop = im.crop(px)
        if preprocess == "gray":
            crop = crop.convert("L")
        out_png.parent.mkdir(parents=True, exist_ok=True)
        crop.save(out_png)
        size = crop.size
    meta = {
        "source": str(src),
        "source_sha256": _sha256(src),
        "page": page_no,
        "box_normalized": list(box),
        "crop_px": list(px),
        "crop_size": list(size),
        "page_size": [w, h],
        "scale": scale,
        "preprocess": preprocess,
        "out": str(out_png),
        "out_sha256": _sha256(out_png),
        "out_bytes": out_png.stat().st_size,
        "crop_cache_key": hashlib.sha256(
            json.dumps({"s": _sha256(src), "p": page_no, "b": box, "sc": scale, "pre": preprocess}, sort_keys=True).encode()
        ).hexdigest()[:32],
    }
    out_png.with_suffix(out_png.suffix + ".meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return meta
