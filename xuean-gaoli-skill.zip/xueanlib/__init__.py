"""学案制作能力开发实验室核心库。

模块划分：
  paths     固定路径与实验室根目录
  doctor    环境自检（只读）
  models    题目记录结构
  validate  题源/题图/答案/审核准入校验
  fingerprint  内容指纹与审核跟随
  evidence  证据缓存
  extract   PDF/图片定向提取
  ocr       Apple Vision 本地 OCR
  svgcheck  SVG 标签与几何约束检查
  physics   物理一致性检查（初始位置、守恒阶段）
  layout    Typst 排版
  audit     PDF 输出检查
  deliver   版本化交付
"""

__all__ = [
    "paths",
    "doctor",
    "models",
    "validate",
    "fingerprint",
    "evidence",
    "extract",
    "ocr",
    "svgcheck",
    "physics",
    "layout",
    "audit",
    "deliver",
]
