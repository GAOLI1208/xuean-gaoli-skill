"""逐页目视记录：把“我确实看过这一页”落到可核对的证据上。

机器审计（audit.py）只证明页面尺寸/字体/字号；本模块记录人工全页目视，
记录绑定被看 PDF 的 SHA256，文件一改，旧记录立即失效（不再覆盖同一路径）。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

from . import fingerprint, paths

CST = timezone(timedelta(hours=8))


def _path(run_id: str) -> Path:
    return paths.run_dir(run_id) / "visual-review.json"


def load(run_id: str) -> dict:
    p = _path(run_id)
    if not p.exists():
        return {"pdf": None, "sha256": None, "pages": {}}
    return json.loads(p.read_text(encoding="utf-8"))


def record(pdf: Path, run_id: str, page: int, note: str, viewer: str = "") -> dict:
    from pypdf import PdfReader

    pdf = Path(pdf)
    sha = fingerprint.sha256_file(pdf)
    total = len(PdfReader(str(pdf)).pages)
    data = load(run_id)
    if data.get("sha256") not in (None, sha):
        # 换了文件（含同路径重导出）：旧逐页记录作废，不沿用。
        data = {"pdf": str(pdf), "sha256": sha, "pages": {}, "invalidated": data.get("sha256")}
    data["pdf"] = str(pdf)
    data["sha256"] = sha
    data["page_count"] = total
    data["pages"][str(page)] = {
        "note": note,
        "viewer": viewer or "full-page-png@2x",
        "at": datetime.now(CST).isoformat(timespec="seconds"),
    }
    _path(run_id).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return data


def status(pdf: Path, run_id: str, total_pages: int) -> dict:
    """返回逐页目视是否覆盖全部页且绑定同一 PDF 哈希。"""
    pdf = Path(pdf)
    sha = fingerprint.sha256_file(pdf)
    data = load(run_id)
    seen = data.get("pages", {}) if data.get("sha256") == sha else {}
    missing = [i for i in range(1, total_pages + 1) if str(i) not in seen]
    return {
        "sha256": sha,
        "recorded_sha256": data.get("sha256"),
        "bound": data.get("sha256") == sha,
        "covered": len(seen),
        "page_count": total_pages,
        "missing_pages": missing,
        "ok": data.get("sha256") == sha and not missing and total_pages > 0,
    }


def main(args) -> int:
    pdf = Path(args.pdf)
    if not pdf.exists():
        print(f"文件不存在：{pdf}")
        return 2
    if args.action == "record":
        if not args.page or not args.note:
            print("record 需要 --page 与 --note")
            return 2
        data = record(pdf, args.run, args.page, args.note, viewer=args.viewer)
        print(f"已记录第 {args.page} 页目视：{args.note}")
        print(f"  PDF {fingerprint.sha256_file(pdf)[:16]}…  已覆盖 {len(data['pages'])}/{data['page_count']} 页")
        return 0
    st = status(pdf, args.run, len(__import__("pypdf").PdfReader(str(pdf)).pages))
    print(json.dumps(st, ensure_ascii=False, indent=2))
    return 0 if st["ok"] else 1
