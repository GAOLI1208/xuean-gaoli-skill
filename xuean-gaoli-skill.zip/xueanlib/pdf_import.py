"""第7轮：参数化 PDF/扫描材料导入。

manifest 指定来源文件、题目页/区域/续页、答案页/区域、身份与输出；
不再写死苏州、第10页、第30题或默认初中/2024。原生 PDF 先抽文本层/bbox；
扫描页只渲染目标区域并 OCR，结果缓存。模型可以辅助给边界/文本，但
manifest 与记录必须如实标注人工选框、转录与映射量。
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
import re

from . import answers, extract, ocr, paths, provenance

CST = timezone(timedelta(hours=8))


PUA_MAP = {
    "\uf03d": "=", "\uf057": "Ω", "\uf0b4": "×", "\uf02d": "-",
    "\uf02b": "+", "\uf03c": "<", "\uf03e": ">", "\uf0a3": "≤",
    "\uf0b3": "≥", "\uf0b1": "±", "\uf0b0": "°", "\uf0b7": "·",
    "\uf0d7": "·", "\uf0b8": "÷", "\uf02f": "/", "\uf05e": "^",
}


def normalize_pdf_text(text: str) -> tuple[str, list[str]]:
    """把 PDF 字体私用区(PUA)符号还原成可读字符；未知 PUA 不静默删除。"""
    unknown = []
    out = []
    for ch in str(text or ""):
        if ch in PUA_MAP:
            out.append(PUA_MAP[ch])
        elif 0xE000 <= ord(ch) <= 0xF8FF:
            unknown.append(f"U+{ord(ch):04X}")
            out.append(f"[?U+{ord(ch):04X}]")
        else:
            out.append(ch)
    s = "".join(out)
    # 单换行是 PDF 版面折行，不是内容分隔；保留双换行作为段落。
    s = re.sub(r"(?<!\n)\n(?!\n)", " ", s)
    s = re.sub(r"[ \t]+", " ", s)
    # PDF 文本层的连续下划线是填空位；转成可见的 Typst 下划线，避免排版时消失。
    s = re.sub(r"_{3,}", "#underline[　　　]", s)
    return s.strip(), unknown



def _now() -> str:
    return datetime.now(CST).isoformat(timespec="seconds")


def _resolve(p) -> Path:
    q = Path(str(p))
    return q if q.is_absolute() else paths.LAB_ROOT / q


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _pagespecs(raw) -> list[dict]:
    out = []
    for i, x in enumerate(raw or [], 1):
        if isinstance(x, int):
            out.append({"page": x, "bbox": None})
        elif isinstance(x, dict):
            out.append({"page": int(x.get("page") or i), "bbox": x.get("bbox")})
        else:
            raise SystemExit(f"pages[{i}] 必须是页码或 {{page,bbox}}")
    if not out:
        raise SystemExit("题目/答案必须至少给出一个页区域")
    return out


def _page_size(src: Path, page_no: int) -> tuple[float, float]:
    if src.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"):
        if page_no != 1:
            raise SystemExit("单张扫描图只有第 1 页")
        from PIL import Image
        with Image.open(src) as im:
            return float(im.width), float(im.height)
    import pdfplumber
    with pdfplumber.open(str(src)) as doc:
        page = doc.pages[page_no - 1]
        return float(page.width), float(page.height)


def _bbox_norm(src: Path, page_no: int, bbox) -> list[float] | None:
    if not bbox:
        return None
    w, h = _page_size(src, page_no)
    x0, y0, x1, y1 = [float(v) for v in bbox]
    if not (0 <= x0 < x1 <= w and 0 <= y0 < y1 <= h):
        raise SystemExit(f"bbox 超出页面范围：{bbox}（页 {page_no} 为 {w:.1f}x{h:.1f}）")
    return [round(x0 / w, 6), round(y0 / h, 6), round(x1 / w, 6), round(y1 / h, 6)]


def _extract_region_text(pdf: Path, spec: dict, profile: str, work: Path, tag: str) -> dict:
    page_no = spec["page"]
    bbox = spec.get("bbox")
    result = {"page": page_no, "bbox_pt": bbox, "profile": profile, "text": "", "method": None,
              "ocr": None, "render": None}
    is_image = pdf.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff")
    # 原生文本优先；扫描图/扫描页/文本为空时再 OCR 目标区域。
    if profile != "scan" and not is_image:
        import pdfplumber
        with pdfplumber.open(str(pdf)) as doc:
            page = doc.pages[page_no - 1]
            target = page.crop(tuple(float(v) for v in bbox)) if bbox else page
            text = target.extract_text() or ""
        result["text"] = text
        result["method"] = "pdf_text"
    if profile == "scan" or is_image or len(result["text"].strip()) < 8:
        box = _bbox_norm(pdf, page_no, bbox) or [0.0, 0.0, 1.0, 1.0]
        crop = work / f"{tag}-p{page_no}.png"
        meta = extract.crop_region(pdf, tuple(box), crop, page_no=page_no, scale=3.0)
        data = ocr.run(crop)
        result["ocr"] = {k: data.get(k) for k in ("engine", "languages", "width", "height",
                                                   "cache_hit", "uncertain_lines", "image_sha256")}
        result["render"] = meta
        result["text"] = "\n".join(ln.get("text", "") for ln in data.get("lines", []))
        result["method"] = "ocr_crop"
    return result


def _crop_figure(pdf: Path, spec: dict, work: Path, rec_id: str, idx: int) -> tuple[dict | None, dict | None]:
    page_no = int(spec.get("page") or 1)
    bbox = spec.get("bbox")
    if not bbox:
        return None, {"reason": "figure 缺 bbox", "page": page_no}
    box = _bbox_norm(pdf, page_no, bbox)
    out = work / "figs" / f"{rec_id}-fig{idx}.png"
    meta = extract.crop_region(pdf, tuple(box), out, page_no=page_no, scale=3.0)
    fig = {
        "figure_no": spec.get("figure_no") or f"题图{idx}",
        "role": spec.get("role") or "原题图",
        "after": spec.get("after") or "stem",
        "evidence_path": str(out), "asset_path": str(out),
        "asset_sha256": meta["out_sha256"],
        "asset_crop": {"source_sha256": meta["source_sha256"], "page": page_no,
                       "box_normalized": box, "bbox_pt": bbox, "scale": 3.0, "preprocess": "raw"},
        "source_note": spec.get("source_note") or (
            f"原卷 PDF 第 {page_no} 页定向裁切" if pdf.suffix.lower() == ".pdf"
            else f"原卷图第 {page_no} 页定向裁切"),
        "display_width": spec.get("display_width") or "62%",
        "relations": {"layout": spec.get("layout") or "按原卷位置裁切",
                      "objects": [], "labels": [], "open_issues": spec.get("open_issues") or []},
    }
    return fig, None


def _structured_blocks(rec_id: str, src: Path, q_parts: list[dict], stem: str, options: list,
                       subs: list, figs: list[dict], answer_text: str, answer_figs: list[dict]) -> list[dict]:
    """把 manifest/PDF 结果整理成与菁优相同的题干/选项/小问/图/答案有序块。"""
    page0 = q_parts[0]["page"] if q_parts else None
    bbox0 = q_parts[0].get("bbox_pt") if q_parts else None
    blocks = [{"order": 1, "id": "stem", "kind": "stem", "text": stem,
               "source": {"path": str(src), "page": page0, "bbox": bbox0, "method": "manifest/extract"}}]
    order = 2
    for i, opt in enumerate(options):
        label = opt.get("label") if isinstance(opt, dict) else chr(65 + i)
        text = opt.get("text") if isinstance(opt, dict) else str(opt)
        blocks.append({"order": order, "id": f"option:{label}", "kind": "option",
                       "label": label, "text": text,
                       "source": {"path": str(src), "page": page0, "bbox": bbox0}})
        order += 1
    for sub in subs:
        blocks.append({"order": order, "id": f"sub:{sub.get('label')}", "kind": "subquestion",
                       "label": str(sub.get("label")), "text": str(sub.get("text") or ""),
                       "source": {"path": str(src), "page": page0, "bbox": bbox0}})
        order += 1
    for fig in figs:
        blocks.append({"order": order, "id": f"figure:{fig.get('figure_no')}", "kind": "figure",
                       "figure_no": fig.get("figure_no"), "role": fig.get("role"),
                       "after": fig.get("after"), "source": {"path": str(src),
                       "page": (fig.get("asset_crop") or {}).get("page"),
                       "bbox": (fig.get("asset_crop") or {}).get("bbox_pt")}})
        order += 1
    for fig in answer_figs:
        blocks.append({"order": order, "id": f"answer-figure:{fig.get('figure_no')}", "kind": "figure",
                       "figure_no": fig.get("figure_no"), "role": "答案图", "after": "answer",
                       "source": {"path": str(src), "page": (fig.get("asset_crop") or {}).get("page"),
                                  "bbox": (fig.get("asset_crop") or {}).get("bbox_pt")}})
        order += 1
    if answer_text.strip():
        blocks.append({"order": order, "id": "answer", "kind": "answer", "text": answer_text,
                       "source": {"path": str(src), "page": None, "bbox": None}})
    return blocks


def _make_mapping(answer_spec: dict, labels: list[str]) -> tuple[list[dict], str]:
    raw_map = answer_spec.get("mapping")
    if isinstance(raw_map, list) and raw_map:
        out = []
        for m in raw_map:
            if not isinstance(m, dict):
                continue
            out.append({
                "source_locator": str(m.get("source_locator") or ""),
                "source_quote": str(m.get("source_quote") or ""),
                "answer": str(m.get("answer") or m.get("source_quote") or ""),
                "targets": [str(t) for t in (m.get("targets") or [])],
                "status": m.get("status") or "mapped",
                "method": m.get("method") or "manifest",
                "note": m.get("note") or "manifest 显式映射，需人工回源核对",
            })
        covered = {t for m in out for t in m["targets"] if m.get("status") != "unmapped"}
        complete = bool(out) and all(t in covered for t in labels) and all(m.get("source_quote") for m in out)
        return out, "complete" if complete else "partial"
    text = str(answer_spec.get("text") or "")
    return answers.mapping_from_labeled(text, labels, "答案页区域")


def import_manifest(manifest_path, records_dir: Path, work_dir: Path | None = None) -> tuple[dict, dict]:
    mp = Path(manifest_path)
    if not mp.is_absolute():
        mp = paths.LAB_ROOT / mp
    manifest = json.loads(mp.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise SystemExit("manifest 必须是 JSON object")
    rec_id = str(manifest.get("id") or "").strip()
    if not rec_id:
        raise SystemExit("manifest 缺 id")
    source = manifest.get("source") or {}
    src_file = _resolve(source.get("file") or "")
    if not src_file.exists():
        raise SystemExit(f"来源文件不存在：{src_file}")
    actual_sha = _sha(src_file)
    claimed = str(source.get("sha256") or "").strip()
    if claimed and claimed != actual_sha:
        raise SystemExit(f"来源文件哈希不符：manifest {claimed[:12]}… 实际 {actual_sha[:12]}…")
    profile = str(manifest.get("profile") or "pdf_text")
    if profile not in ("pdf_text", "scan"):
        raise SystemExit("pdf/scan manifest 的 profile 必须是 pdf_text 或 scan")

    work = work_dir or (paths.DIRS["runs"] / "materials" / rec_id)
    work.mkdir(parents=True, exist_ok=True)
    (work / "manifest.snapshot.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
                                                 encoding="utf-8")
    question = manifest.get("question") or {}
    q_specs = _pagespecs(question.get("pages") or [{"page": 1}])
    q_parts = [_extract_region_text(src_file, s, profile, work, "q") for s in q_specs]
    q_unknown: list[str] = []
    for p in q_parts:
        p["text"], u = normalize_pdf_text(p["text"])
        q_unknown.extend(u)
    q_text = "\n\n".join(p["text"] for p in q_parts if p["text"].strip())
    stem = str(question.get("stem") or q_text).strip()
    stem, u = normalize_pdf_text(stem)
    q_unknown.extend(u)
    subs = question.get("subquestions") or []
    if not isinstance(subs, list):
        raise SystemExit("question.subquestions 必须是数组")
    if not subs and q_text:
        # 原生文本里若出现完整小问标签，先切成小问；仍不猜嵌套编号。
        from .import_question import split_subquestions
        import re
        parsed = split_subquestions(q_text)
        if parsed:
            m = re.search(r"[（(]1[）)]|①", q_text)
            if m:
                stem = q_text[:m.start()].strip()
            subs = parsed
    options = question.get("options") or []
    figs = []
    fig_errors = []
    for i, spec in enumerate(question.get("figures") or [], 1):
        if not isinstance(spec, dict):
            raise SystemExit(f"question.figures[{i}] 必须是对象")
        fig, err = _crop_figure(src_file, spec, work, rec_id, i)
        if fig:
            figs.append(fig)
        if err:
            fig_errors.append(err)

    claim_text = stem + "\n" + "\n".join(str(x.get("text") or "") for x in subs if isinstance(x, dict))
    claims = provenance.figure_claims(claim_text)
    if claims and not figs:
        fig_errors.append({"figure_no": "声明图", "role": "原题图", "after": "stem",
                           "src": "", "claim": claims[0],
                           "reason": "题干声明图/图线/坐标系，但 manifest 未提供题图"})

    answer = manifest.get("answer") or {}
    ans_file = _resolve(answer.get("file") or source.get("file"))
    ans_specs = _pagespecs(answer.get("pages") or []) if answer.get("pages") else []
    a_parts = [_extract_region_text(ans_file, s, profile, work, "a") for s in ans_specs]
    a_unknown: list[str] = []
    for p in a_parts:
        p["text"], u = normalize_pdf_text(p["text"])
        a_unknown.extend(u)
    a_text = "\n\n".join(p["text"] for p in a_parts if p["text"].strip())
    if answer.get("text"):
        a_text, u = normalize_pdf_text(str(answer["text"]))
        a_unknown.extend(u)
    labels = [str(s.get("label")) for s in subs if isinstance(s, dict)] or (["答案"] if options else [])
    answer_available = bool(a_text.strip() or answer.get("items") or answer.get("figures"))
    if answer_available:
        mapping, mapping_status = _make_mapping({**answer, "text": a_text}, labels)
        if answer.get("items"):
            items = [dict(x) for x in answer["items"] if isinstance(x, dict)]
        else:
            by = {t: str(m.get("answer") or m.get("source_quote") or "") for m in mapping for t in m.get("targets") or []}
            items = [{"label": lab, "answer": by.get(lab, "").strip()} for lab in labels]
    else:
        mapping, mapping_status, items = [], "unmapped", []
    answer_figs = []
    for i, spec in enumerate(answer.get("figures") or [], 1):
        fig, err = _crop_figure(ans_file, spec, work, rec_id + "-answer", i)
        if fig:
            fig["role"] = "答案图"
            fig["after"] = "answer"
            answer_figs.append(fig)
        if err:
            fig_errors.append(err)

    cross_page = len(q_specs) > 1
    source_evidence = [{
        "path": str(src_file), "sha256": actual_sha, "page": q_specs[0]["page"],
        "selector": "；".join(f"p{s['page']}" + (f" bbox={s['bbox']}" if s.get("bbox") else "") for s in q_specs),
        "independence": source.get("independence") or "third_party_repost",
    }]
    for p in a_parts:
        if ans_file == src_file:
            continue
        source_evidence.append({
            "path": str(ans_file), "sha256": _sha(ans_file), "page": p["page"],
            "selector": f"答案 p{p['page']}" + (f" bbox={p['bbox_pt']}" if p.get("bbox_pt") else ""),
            "independence": "third_party_repost",
        })
    open_questions = []
    if cross_page:
        open_questions.append(f"题目跨 {len(q_specs)} 个原卷页区域；跨页连接已按 manifest 顺序，需目视确认是同一题")
    if question.get("stem") or question.get("subquestions"):
        open_questions.append("题干/小问使用了 manifest/模型辅助文本，manual 字段记录人工量")
    if fig_errors:
        open_questions.append(f"有 {len(fig_errors)} 个图裁切失败，见 figure_failures")
    if mapping_status != "complete":
        open_questions.append(f"答案映射状态 {mapping_status}；未映射内容保留在 answer.text")

    requested_mode = str(manifest.get("delivery") or "questions_only")
    delivery_mode = requested_mode
    downgrade_reason = ""
    if requested_mode == "with_sourced_answers" and mapping_status != "complete":
        delivery_mode = "questions_only"
        downgrade_reason = f"来源答案映射状态 {mapping_status}，未达到 complete；用户请求的来源答案版未完成，已降级为题目版并保留缺口"
    rec = {
        "id": rec_id, "status": "待核实", "stage": (manifest.get("identity") or {}).get("stage"),
        "identity": {k: (manifest.get("identity") or {}).get(k) for k in
                     ("exam_year", "exam_year_label", "year_evidence", "region", "school",
                      "exam_name", "exam_type", "original_number", "bank_id", "booklet_number")},
        "source": {
            "urls": [source["url"]] if source.get("url") else [],
            "local_files": [{"path": str(src_file), "sha256": actual_sha}],
            "original_files": [{"path": str(src_file), "sha256": actual_sha}],
            "origin_role": "local_pdf",
            "derived": None,
            "original": {"path": str(src_file), "exists": True, "sha256": actual_sha,
                         "url": source.get("url") or "", "selector": source.get("selector") or ""},
            "dom": {"kind": "pdf" if str(src_file).lower().endswith(".pdf") else "scan",
                    "scope_count": 1, "declared_images": len(question.get("figures") or []) + len(answer.get("figures") or []),
                    "usable_images": len(figs), "missing_src": 0,
                    "selector": source.get("selector") or "", "text_chars": len(stem)},
            "material_type": provenance.material_type(
                (manifest.get("identity") or {}).get("exam_type"),
                (manifest.get("identity") or {}).get("material_type")),
            "publisher": source.get("publisher") or "本地/公开 PDF",
            "publication_type": source.get("publication_type") or "完整转载",
            "retrieved_at": source.get("retrieved_at") or _now(),
            "upstream": source.get("upstream") or "",
            "evidence": source_evidence,
            "open_questions": open_questions,
            # 导入器不冒充核实；只有显式 source review 才改“通过”。
            "status": "待核实",
        },
        "problem": {
            "stem": stem, "options": options,
            "subquestions": [{"label": str(s.get("label")), "text": str(s.get("text") or "")}
                             for s in subs],
            "figures": figs, "figure_failures": fig_errors,
            "blocks": _structured_blocks(rec_id, src_file, q_parts, stem, options, subs, figs, a_text, answer_figs),
            "answer_slots": [{"id": str(s.get("label")), "label": str(s.get("label")),
                              "kind": "text", "required": True} for s in subs] or
                            ([{"id": "答案", "label": "答案", "kind": "choice", "required": True}] if options else []),
            "figure_expected": bool(question.get("figures")) or bool(claims),
            "figure_claims": claims,
            "expected": {"figure": bool(question.get("figures")) or bool(claims), "option_count": len(options),
                         "subquestion_count": len(subs), "figure_count": len(question.get("figures") or [])},
            "unresolved_chars": q_unknown + a_unknown,
            "needs_review": bool(q_unknown or a_unknown),
            "cross_page": cross_page,
            "source_pages": [s["page"] for s in q_specs],
            "manual": manifest.get("manual") or {},
            "extracted_text": q_text,
        },
        "teaching": {"stage": (manifest.get("identity") or {}).get("stage"),
                     "topic": (manifest.get("identity") or {}).get("topic") or "",
                     "knowledge_points": [], "prerequisites": [], "difficulty_reason": "",
                     "est_minutes": 8, "use": "课后练习", "textbook": ""},
        "solution": {"independent": False, "saw_reference": True, "system": "typst", "reference_frame": "",
                     "stages": [], "sub_answers": [{"label": i["label"], "answer": i["answer"]} for i in items],
                     "initial_positions": {}, "checks": [],
                     "comparison": {"status": "partial" if mapping_status == "complete" else "missing",
                                    "source": source.get("url") or str(src_file),
                                    "note": "manifest/程序建议映射，未逐项人工复核"}},
        "answer": {"nature": answer.get("nature") or ("转载参考答案" if a_text or answer.get("items") else "未取得"),
                   "source_url": source.get("url") or str(ans_file),
                   "locator": answer.get("locator") or (
                       f"第 {a_parts[0]['page']} 页答案区域" if a_parts else "manifest answer"),
                   "evidence": [{"path": str(ans_file), "sha256": _sha(ans_file),
                                 "page": a_parts[0]["page"] if a_parts else None,
                                 "region": "答案区域"}],
                   "items": items, "text": a_text, "mapping": mapping,
                   "mapping_status": mapping_status, "figures": answer_figs,
                   "figure": answer_figs[0] if answer_figs else None},
        "delivery": {"mode": delivery_mode, "requested_mode": requested_mode,
                     "effective_mode": delivery_mode, "downgrade_reason": downgrade_reason,
                     "display_answers": delivery_mode != "questions_only",
                     "explanations_requested": False, "claims_answers_verified": False,
                     "note": "PDF/扫描 manifest 导入；人工选框/转录/映射量见 problem.manual"},
        "review": {},
    }
    (work / "extract.json").write_text(json.dumps(
        {"source": str(src_file), "sha256": actual_sha, "question": q_parts, "answer": a_parts,
         "figure_errors": fig_errors, "cross_page": cross_page,
         "mapping_status": mapping_status, "at": _now()},
        ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    records_dir.mkdir(parents=True, exist_ok=True)
    provenance.first_snapshot(records_dir, rec_id, rec)
    out = records_dir / f"{rec_id}.json"
    out.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return rec, {"work": str(work), "record": str(out), "sha256": actual_sha,
                 "cross_page": cross_page, "mapping_status": mapping_status}
