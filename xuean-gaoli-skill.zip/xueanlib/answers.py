"""来源答案到题面空位的显式映射（第7轮检查点修复）。

规则：
- 每个必答空位必须有精确 target；父小问 label 不能自动覆盖子空。
- 一个来源块可合并映射多个空位，但 targets 必须逐一声明；排版只输出一次。
- 答案图是答案的一部分：mapping 可带 figure_path，必须存在且哈希一致；
  “作图未列文字/见解答/如图”没有真实图时一律阻断。
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from . import models, paths

# 强占位短语 + 整段就是“略/如图/见图”的短答案。
PLACEHOLDER_RE = re.compile(
    r"见解析|见解答|答案见|未单列文字|作图未列文字|未取得|待补|待定|略解|如图|见图|"
    r"^\s*[（(]?\s*略\s*[)）]?\s*$"
)


def _slot_id(label: str, blank=None) -> str:
    label = str(label or "").strip()
    if blank is None:
        return label
    return f"{label}-{blank}"


def canon_label(s) -> str:
    return str(s or "").strip().replace("(", "（").replace(")", "）")


def _resolve(p) -> Path | None:
    if not p:
        return None
    q = Path(str(p))
    return q if q.is_absolute() else paths.LAB_ROOT / q


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def derive_slots(rec: dict) -> list[dict]:
    """返回需要被来源答案覆盖的空位。

    未声明 answer_slots 时，每个小问只算一个空位；多空题必须显式声明
    `(1)-1`、`(1)-2` 等，否则不能声称“逐空完整”。
    """
    explicit = models.get(rec, "problem.answer_slots")
    if isinstance(explicit, list) and explicit:
        out = []
        for i, s in enumerate(explicit, 1):
            if not isinstance(s, dict):
                continue
            sid = str(s.get("id") or s.get("label") or f"slot-{i}")
            out.append({
                "id": sid, "label": canon_label(s.get("label") or sid),
                "blank": s.get("blank"), "kind": s.get("kind") or "text",
                "required": bool(s.get("required", True)),
            })
        return out
    subs = models.subquestions(rec)
    if subs:
        out = []
        for sub in subs:
            label = canon_label(sub.get("label") or "")
            slots = sub.get("answer_slots")
            if isinstance(slots, list) and slots:
                for j, s in enumerate(slots, 1):
                    if isinstance(s, dict):
                        out.append({
                            "id": str(s.get("id") or _slot_id(label, s.get("blank") or j)),
                            "label": label, "blank": s.get("blank") or j,
                            "kind": s.get("kind") or "text",
                            "required": bool(s.get("required", True)),
                        })
            else:
                out.append({"id": label, "label": label, "blank": None,
                            "kind": "text", "required": True})
        return out
    if models.is_choice(rec) or models.get(rec, "problem.options"):
        return [{"id": "答案", "label": "答案", "blank": None,
                 "kind": "choice", "required": True}]
    return []


def is_placeholder(text) -> bool:
    s = str(text or "").strip()
    if not s:
        return True
    return bool(PLACEHOLDER_RE.search(s))


def _mapping_entries(rec: dict) -> list[dict]:
    raw = models.get(rec, "answer.mapping")
    return [x for x in raw if isinstance(x, dict)] if isinstance(raw, list) else []


def _mapping_keys(m: dict) -> set[str]:
    return {str(t) for t in (m.get("targets") or [])} | {canon_label(t) for t in (m.get("targets") or [])}


def _mapping_figure_path(m: dict) -> Path | None:
    for key in ("figure_path", "path", "figure"):
        val = m.get(key)
        if isinstance(val, dict):
            val = val.get("path") or val.get("asset_path")
        if val:
            return _resolve(val)
    return None


def _global_answer_figures(rec: dict) -> list[dict]:
    ans = models.answer_block(rec)
    out = []
    for key in ("figures",):
        for f in ans.get(key) or []:
            if isinstance(f, dict):
                out.append(f)
    if isinstance(ans.get("figure"), dict):
        out.append(ans["figure"])
    return out


def _figure_for_slot(rec: dict, slot: dict) -> Path | None:
    sid = str(slot.get("id"))
    label = str(slot.get("label") or sid)
    keys = {sid, canon_label(sid)}
    if slot.get("blank") is None:
        keys.update({label, canon_label(label)})
    for m in _mapping_entries(rec):
        if m.get("status") not in (None, "mapped", "not_applicable"):
            continue
        if keys & _mapping_keys(m):
            p = _mapping_figure_path(m)
            if p:
                return p
    return None


def slot_text(rec: dict, slot: dict) -> str:
    """按精确空位取答案；父 label 不能自动覆盖子空。"""
    sid = str(slot.get("id"))
    label = str(slot.get("label") or sid)
    keys = {sid, canon_label(sid)}
    if slot.get("blank") is None:
        keys.update({label, canon_label(label)})
    items = models.answer_items(rec)
    # 有 mapping 时，先按精确 target 找；合并映射可命中多个 target，但只返回本条的 answer。
    for m in _mapping_entries(rec):
        if m.get("status") not in (None, "mapped", "not_applicable"):
            continue
        if keys & _mapping_keys(m):
            txt = str(m.get("answer") or m.get("source_quote") or "").strip()
            if txt:
                return txt
            if _mapping_figure_path(m):
                return "（答案图）"
    for key in (sid, label):
        if (items.get(key) or {}).get("answer"):
            return str(items[key]["answer"]).strip()
    return ""


def mapping_state(rec: dict) -> dict:
    slots = [s for s in derive_slots(rec) if s.get("required", True)]
    entries = _mapping_entries(rec)
    targets = set()
    for m in entries:
        if m.get("status") in (None, "mapped"):
            targets.update(str(t) for t in (m.get("targets") or []))
            targets.update(canon_label(t) for t in (m.get("targets") or []))
    # 子空只认精确 id；父 label 不再覆盖子空。
    missing = []
    for s in slots:
        sid = str(s["id"])
        keys = {sid, canon_label(sid)}
        if not (keys & targets):
            missing.append(sid)
    placeholders = []
    for s in slots:
        txt = slot_text(rec, s)
        if is_placeholder(txt) and not _figure_for_slot(rec, s):
            placeholders.append(s["id"])
    figure_missing = []
    for m in entries:
        p = _mapping_figure_path(m)
        if not p:
            continue
        if not p.exists():
            figure_missing.append(str(p))
            continue
        want = str(m.get("figure_sha256") or "").strip()
        if want and _sha(p) != want:
            figure_missing.append(str(p))
    raw_status = str(models.get(rec, "answer.mapping_status") or "").strip()
    if not entries:
        derived = "unmapped"
    elif missing or placeholders or figure_missing:
        derived = "partial"
    else:
        derived = "complete"
    return {
        "status": raw_status or derived,
        "derived": derived,
        "slots": slots,
        "missing": missing,
        "placeholders": placeholders,
        "figure_missing": figure_missing,
        "entries": entries,
        "targets": sorted(targets),
    }


def display_blocks(rec: dict) -> list[dict]:
    """排版用：mapping 优先，且每个合并映射只输出一次；无 mapping 才退回 items。"""
    entries = [m for m in _mapping_entries(rec) if m.get("status") in (None, "mapped")]
    slots = {str(s["id"]): s for s in derive_slots(rec)}
    out = []
    if entries:
        for m in entries:
            targets = [str(t) for t in (m.get("targets") or [])]
            labels = []
            for t in targets:
                s = slots.get(t)
                if s and s.get("blank") is not None:
                    labels.append(f"{s['label']}第{s['blank']}空")
                elif s:
                    labels.append(s["label"])
                else:
                    labels.append(t)
            text = str(m.get("answer") or m.get("source_quote") or "").strip()
            fig = _mapping_figure_path(m)
            if not text and fig:
                text = "（答案图）"
            out.append({
                "label": "、".join(labels) or "、".join(targets),
                "text": text,
                "figure": str(fig) if fig else None,
                "source_locator": m.get("source_locator") or "",
            })
        return out
    # 旧记录兼容：没有 mapping 时仍显示 items；来源答案版会在 validate 阻断。
    for it in models.get(rec, "answer.items", []) or []:
        if not isinstance(it, dict):
            continue
        out.append({"label": str(it.get("label") or ""), "text": str(it.get("answer") or ""),
                    "figure": None, "source_locator": ""})
    return out


def issues(rec: dict) -> list[dict]:
    """返回 answer mapping 的阻断问题；只在来源答案/自写讲解模式调用。"""
    mode = models.get(rec, "delivery.mode")
    if mode not in ("with_sourced_answers", "optional_explanations"):
        return []
    out = []
    st = mapping_state(rec)
    if not st["entries"]:
        out.append({"code": "ANS_MAPPING_MISSING", "level": "block",
                    "message": "来源答案没有逐空映射（answer.mapping 为空）；只有答案文本不算完整",
                    "field": "answer.mapping"})
        return out
    for i, m in enumerate(st["entries"]):
        if m.get("status") == "unmapped":
            out.append({"code": "ANS_MAPPING_INCOMPLETE", "level": "block",
                        "message": f"第 {i+1} 条答案映射仍为 unmapped，不能算完整",
                        "field": f"answer.mapping[{i}]"})
            continue
        if m.get("status") not in (None, "mapped"):
            out.append({"code": "ANS_MAPPING_INCOMPLETE", "level": "block",
                        "message": f"第 {i+1} 条答案映射状态非法：{m.get('status')!r}",
                        "field": f"answer.mapping[{i}]"})
            continue
        if not (m.get("targets") or []):
            out.append({"code": "ANS_MAPPING_INCOMPLETE", "level": "block",
                        "message": f"第 {i+1} 条答案映射没有目标空位",
                        "field": f"answer.mapping[{i}].targets"})
        if not str(m.get("source_locator") or "").strip():
            out.append({"code": "ANS_MAPPING_NO_LOCATOR", "level": "block",
                        "message": f"第 {i+1} 条答案映射没有来源位置（页码/区域/selector）",
                        "field": f"answer.mapping[{i}].source_locator"})
        if not str(m.get("source_quote") or "").strip():
            out.append({"code": "ANS_MAPPING_NO_QUOTE", "level": "block",
                        "message": f"第 {i+1} 条答案映射没有原文片段",
                        "field": f"answer.mapping[{i}].source_quote"})
        p = _mapping_figure_path(m)
        if p and not p.exists():
            out.append({"code": "ANS_FIGURE_MISSING", "level": "block",
                        "message": f"第 {i+1} 条映射的答案图不存在：{p}",
                        "field": f"answer.mapping[{i}].figure_path"})
        want = str(m.get("figure_sha256") or "").strip()
        if p and p.exists() and want and _sha(p) != want:
            out.append({"code": "ANS_FIGURE_HASH", "level": "block",
                        "message": f"第 {i+1} 条映射的答案图哈希不符",
                        "field": f"answer.mapping[{i}].figure_sha256"})
    if st["missing"]:
        out.append({"code": "ANS_MAPPING_INCOMPLETE", "level": "block",
                    "message": f"答案映射未覆盖精确空位（父 label 不能覆盖子空）：{st['missing']}",
                    "field": "answer.mapping"})
    if st["placeholders"]:
        out.append({"code": "ANS_PLACEHOLDER", "level": "block",
                    "message": f"答案为空或占位（见解答/作图未列文字/如图无真图等），不能算真实答案：{st['placeholders']}",
                    "field": "answer.mapping"})
    if st["figure_missing"]:
        out.append({"code": "ANS_FIGURE_MISSING", "level": "block",
                    "message": f"答案图缺失或哈希不符：{st['figure_missing']}",
                    "field": "answer.figure"})
    if st["status"] != "complete":
        out.append({"code": "ANS_MAPPING_INCOMPLETE", "level": "block",
                    "message": f"answer.mapping_status={st['status']!r}，必须为 complete",
                    "field": "answer.mapping_status"})
    ans_text = str(models.get(rec, "answer.text") or "")
    if ans_text:
        for i, m in enumerate(st["entries"]):
            quote = str(m.get("source_quote") or "").strip()
            if quote and quote not in ans_text:
                out.append({"code": "ANS_MAPPING_QUOTE_NOT_IN_SOURCE", "level": "block",
                            "message": f"第 {i+1} 条映射的 source_quote 未在 answer.text 中逐字出现",
                            "field": f"answer.mapping[{i}].source_quote"})
    return out


def parse_labeled_answer(text: str, labels: list[str]) -> dict:
    """按完整小问标签切分答案；只做精确标签匹配，不做“分号数量相等”猜配。"""
    labels = [canon_label(x) for x in labels if str(x).strip()]
    if not text or not labels:
        return {}
    normalized = str(text).replace("(", "（").replace(")", "）")
    label_set = set(labels)
    pat = re.compile(r"(?=(?:" + "|".join(re.escape(x) for x in sorted(label_set, key=len, reverse=True)) + r")\s*)")
    out = {}
    for part in pat.split(normalized):
        part = part.strip()
        for lab in sorted(label_set, key=len, reverse=True):
            if part.startswith(lab):
                body = part[len(lab):].strip(" ：:；;")
                out[lab] = body
                break
    return out


def mapping_from_labeled(text: str, labels: list[str], locator_prefix: str = "答案区") -> tuple[list[dict], str]:
    """由精确标签生成映射建议；不写 reviewed/compared。"""
    parsed = parse_labeled_answer(text, labels)
    mapping = []
    for i, (lab, body) in enumerate(parsed.items(), 1):
        mapping.append({
            "source_locator": f"{locator_prefix} 第 {i} 段（{lab}）",
            "source_quote": body,
            "answer": body,
            "targets": [lab],
            "status": "mapped",
            "method": "label_exact",
            "note": "程序按完整小问标签切分，待逐项回源核对",
        })
    covered = {t for m in mapping for t in m["targets"]}
    missing = [x for x in labels if x not in covered]
    status = "complete" if not missing and all(not is_placeholder(m["source_quote"]) for m in mapping) else "partial"
    return mapping, status
